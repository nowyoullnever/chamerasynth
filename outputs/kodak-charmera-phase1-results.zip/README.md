# Kodak Charmera Synth Firmware — Phase 1

This repository is an **offline, read-only research foundation**.  It does not
contain a flashable image, startup code, device-control code, or scripts that
send commands to a camera.

## Layout

- `docs/`: Phase 1 evidence, assumptions, risks, and the Phase 2 gate.
- `tools/inspect_firmware.py`: reproducible passive inspection (hashes,
  header bytes, entropy, strings, and simple signature hits).
- `tests/`: offline validation for the inspection tool.
- `references/`: unmodified local clones of third-party repositories. Treat
  them as evidence, not as code to copy into a Charmera firmware.

## Safe use

Run only against a local file; the script opens it read-only:

```powershell
python tools/inspect_firmware.py references/Project-Sirius/Original_Firmware.bin --json work/firmware-inspection.json
python -m unittest discover -s tests -v
```

`--json` writes a report, never modifies its input.  The output directory is
ignored by Git. Do not add a physical camera, serial device, or flash tool to
this Phase 1 project.

