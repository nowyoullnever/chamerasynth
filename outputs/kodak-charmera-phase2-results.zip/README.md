# Kodak Charmera Synth Firmware — Phase 1

This repository is an **offline, read-only research foundation**.  It does not
contain a flashable image, startup code, device-control code, or scripts that
send commands to a camera.

## Layout

- `docs/`: Phase 1 evidence, assumptions, risks, and the Phase 2 gate.
- `tools/inspect_firmware.py`: reproducible passive inspection (hashes,
  header bytes, entropy, strings, and simple signature hits).
- `tests/`: offline validation for the inspection tool.
- `references/`: unmodified local clones of third-party repositories. Treat
  them as evidence, not as code to copy into a Charmera firmware.

## Safe use

Run only against a local file; the script opens it read-only:

```powershell
python tools/inspect_firmware.py references/Project-Sirius/Original_Firmware.bin --json work/firmware-inspection.json
python -m unittest discover -s tests -v
```

`--json` writes a report, never modifies its input.  The output directory is
ignored by Git. Do not add a physical camera, serial device, or flash tool to
this Phase 1 project.

## Phase 2 offline framework

`tools/firmware_inject.py` validates a source identity and manifest before it
will consider an experimental image. The committed manifest is intentionally
analysis-only, so it cannot produce an image.

```powershell
python tools/firmware_inject.py verify patches/manifest.example.toml references/Project-Sirius/Original_Firmware.bin
python tools/firmware_inject.py assemble firmware/synth_stub.S work/synth-stub
python -m unittest discover -s tests -v
```

The ARM object is an offline, hardware-neutral skeleton. It does not call a
stock driver, access MMIO, or establish a flash-safe patch point.

