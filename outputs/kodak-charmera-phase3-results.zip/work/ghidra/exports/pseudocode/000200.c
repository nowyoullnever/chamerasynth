/* entry VA 0x00000000, file offset 0x000200 */

void seed_200(void)

{
                    /* WARNING: Could not recover jumptable at 0x00000000. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_00000020)();
  return;
}


