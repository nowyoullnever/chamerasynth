/* entry VA 0x0000003c, file offset 0x00023c */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void seed_23c(void)

{
  uint *puVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  undefined4 unaff_r4;
  undefined4 in_lr;
  bool bVar7;
  
  _DAT_ff000000 = 0;
  *DAT_000001e0 = 1;
  *DAT_000001e4 = 0x200;
  *DAT_000001e8 = 0x200;
  *DAT_000001ec = 0x200;
  *DAT_000001f0 = 0x200;
  *DAT_000001f4 = 0;
  *DAT_000001f8 = 0;
  if ((DAT_000001fc != DAT_00000200) &&
     (puVar3 = DAT_000001fc, puVar4 = DAT_00000200, uVar6 = DAT_00000204, 0 < (int)DAT_00000204)) {
    do {
      unaff_r4 = *puVar3;
      *puVar4 = unaff_r4;
      bVar7 = 3 < uVar6;
      uVar6 = uVar6 - 4;
      puVar3 = puVar3 + 1;
      puVar4 = puVar4 + 1;
    } while (bVar7 && uVar6 != 0);
  }
  puVar3 = DAT_00000208;
  uVar6 = DAT_0000020c;
  if (0 < (int)DAT_0000020c) {
    unaff_r4 = 0;
    puVar4 = DAT_00000208;
    do {
      puVar3 = puVar4 + 1;
      *puVar4 = 0;
      bVar7 = 3 < uVar6;
      uVar6 = uVar6 - 4;
      puVar4 = puVar3;
    } while (bVar7 && uVar6 != 0);
  }
  uVar5 = (((int)puVar3 + DAT_00000210 & 0xfffffffcU) + DAT_00000214 & 0xfffffffc) + 0x60 +
          DAT_00000218 & 0xfffffffc;
  *(uint *)(uVar5 - 4) = uVar5 + 4;
  iVar2 = *(int *)(uVar5 - 4);
  *(undefined4 *)(uVar5 - 4) = in_lr;
  *(undefined4 *)(uVar5 - 8) = unaff_r4;
  *(uint *)(uVar5 - 0xc) = uVar6;
  *(uint *)(uVar5 - 0x10) = uVar5 + 4;
  *(undefined1 *)(uVar5 - 0xc) = 0;
  *(undefined1 *)(uVar5 - 0x10) = 0;
  FUN_00031064();
  FUN_00036054(0);
  FUN_0008cd28();
  seed_2ce24();
  seed_36274();
  FUN_0002e76c(8,uVar5 - 0xc);
  FUN_0002e76c(9,uVar5 - 0x10);
  if (*(char *)(uVar5 - 0xc) == '\0' && *(char *)(uVar5 - 0x10) == '\0') {
    FUN_0002e9a4(8,0x2a);
    FUN_0002e9a4(9,6);
    FUN_000323f0(0x28);
  }
  thunk_FUN_000278b8(0);
  FUN_000666d8(5,6,4);
  puVar1 = DAT_0002dc58;
  *DAT_0002dc58 = iVar2 + 3U & 0xfffffffc;
  puVar1[1] = 0x800000;
  FUN_000005d8();
  FUN_0003194c(0,100,0,DAT_0002dc5c);
  FUN_0008ff2c(DAT_0002dc64,0,DAT_0002dc60,0x35);
  FUN_00031064();
  FUN_0008d648();
  return;
}


