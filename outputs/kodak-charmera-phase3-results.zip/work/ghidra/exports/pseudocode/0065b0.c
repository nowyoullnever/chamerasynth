/* entry VA 0x000063b0, file offset 0x0065b0 */

undefined8 seed_65b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  char cVar1;
  int *piVar2;
  char *pcVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  int *piVar10;
  code *pcVar11;
  code *pcVar12;
  undefined1 *puVar13;
  bool bVar14;
  bool bVar15;
  undefined4 local_30;
  undefined4 local_28;
  int *local_24;
  
  piVar10 = (int *)0x0;
  iVar9 = 0;
  local_28 = param_3;
  local_24 = param_4;
  thunk_FUN_0000cc2c();
  FUN_0001e234();
  FUN_00006134();
  FUN_0002d31c(0xf8500000);
  piVar6 = DAT_00006528;
  puVar5 = DAT_00006524;
  puVar4 = DAT_00006518;
  pcVar3 = DAT_00006340;
  do {
    iVar7 = FUN_00025a38(*puVar5,&local_24,piVar6,0x28);
    piVar2 = local_24;
    if (iVar7 != -1) {
      bVar15 = SBORROW4((int)local_24,0x7000);
      pcVar11 = (code *)(local_24 + -0x1c00);
      bVar14 = pcVar11 == seed_200;
      pcVar12 = pcVar11;
      if (0x6fff < (int)local_24) {
        bVar15 = SBORROW4((int)pcVar11,0x3e);
        pcVar12 = (code *)((int)local_24 + -0x703e);
        bVar14 = pcVar11 == seed_23c + 2;
      }
      if (bVar14) {
        FUN_00021dc8((char)*piVar6);
      }
      else if ((int)pcVar12 < 0 == bVar15) {
        if (local_24 == (int *)0x703f) {
          uVar8 = 1;
        }
        else {
          if (local_24 != (int *)0x7040) {
            puVar13 = (undefined1 *)((int)local_24 + -0x7042);
            bVar14 = puVar13 == (undefined1 *)0x0;
            if (bVar14) {
              puVar13 = (undefined1 *)(*piVar6 + -0x10000003);
              piVar2 = piVar6;
            }
            if ((bVar14 && puVar13 == (undefined1 *)0x108) && (piVar2[2] != 0)) {
              pcVar3[1] = pcVar3[1] + '\x01';
            }
            goto LAB_00006448;
          }
          uVar8 = 0;
        }
        FUN_00021d20(uVar8);
      }
      else {
        pcVar12 = seed_200;
        if (local_24 != (int *)0x5013) {
          pcVar12 = (code *)(local_24 + -0x1400);
        }
        if (local_24 == (int *)0x5013 || pcVar12 == NotUsed) {
          *pcVar3 = '\x01';
          local_28 = CONCAT31(local_28._1_3_,(char)*piVar6);
          FUN_000220cc();
          piVar10 = piVar2;
        }
        else if (local_24 == (int *)0x5025) {
          FUN_0008f67c(*puVar4,0x108);
          iVar9 = 7;
        }
      }
LAB_00006448:
      cVar1 = '\0';
      if (pcVar3[1] != '\0') {
        cVar1 = *pcVar3;
      }
      if (pcVar3[1] != '\0' && cVar1 != '\0') break;
    }
  } while (iVar9 == 0);
  local_30 = param_1;
  if (piVar10 != (int *)0x0) {
    local_30 = 0;
    FUN_00025984(*puVar5,piVar10,&local_28,1);
  }
  FUN_00007d10();
  seed_6578();
  return CONCAT44(param_2,local_30);
}


