/* entry VA 0x0001c9c4, file offset 0x01cbc4 */

void seed_1cbc4(void)

{
  byte *pbVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint unaff_r4;
  int unaff_r5;
  undefined4 *unaff_r6;
  undefined4 *unaff_r8;
  int unaff_r10;
  undefined1 unaff_r11;
  int iVar6;
  bool bVar7;
  bool bVar8;
  undefined8 uVar9;
  undefined1 uStack00000008;
  undefined4 uStack0000000c;
  undefined4 uStack00000010;
  
code_r0x0001c9c4:
  uVar2 = FUN_0001bea8();
  if ((uVar2 & 8) != 0) goto LAB_0001cd00;
  uVar2 = FUN_0001bea8();
  if ((uVar2 & 2) != 0) {
    FUN_0001bc80(0);
  }
  iVar3 = FUN_00060a04();
  if (iVar3 != 0) {
    FUN_0000cdd0();
    FUN_0000cda0();
    FUN_00060d3c(0);
  }
  FUN_000904e4(1);
  FUN_0001bb70();
  if (uStack00000010 == 0x7006) goto LAB_0001ca2c;
  if (uStack00000010 == 0x700a) {
    uVar4 = 1;
    goto LAB_0001ca30;
  }
LAB_0001cde4:
  while( true ) {
    do {
      unaff_r6 = DAT_0001c988;
      pbVar1 = DAT_0001c984;
      if (unaff_r10 != 0) goto LAB_0001cdec;
      uVar9 = FUN_00025a38(*DAT_0001c988,&uStack00000010,DAT_0001c984,0x28);
    } while ((int)uVar9 == -1);
    bVar8 = SBORROW4(uStack00000010,0x7000);
    iVar6 = uStack00000010 + -0x7000;
    bVar7 = iVar6 == 0;
    iVar3 = iVar6;
    if (0x6fff < uStack00000010) {
      bVar8 = SBORROW4(iVar6,0x10);
      iVar3 = uStack00000010 + -0x7010;
      bVar7 = iVar6 == 0x10;
    }
    if (!bVar7) break;
    uVar2 = FUN_0001bea8();
    if (((uVar2 & 2) != 0) && (uVar2 = FUN_0001bea8(), (uVar2 & 8) == 0)) {
      FUN_0001bc80(0);
      FUN_000904e4(5);
      goto LAB_0001c820;
    }
  }
  if (iVar3 < 0 != bVar8) {
    bVar8 = SBORROW4(uStack00000010,0x7000);
    iVar6 = uStack00000010 + -0x7000;
    bVar7 = iVar6 == 0;
    iVar3 = iVar6;
    if (0x6fff < uStack00000010) {
      bVar8 = SBORROW4(iVar6,4);
      iVar3 = uStack00000010 + -0x7004;
      bVar7 = iVar6 == 4;
    }
    if (bVar7) goto LAB_0001cde4;
    if (iVar3 < 0 == bVar8) {
      switch(uStack00000010) {
      case 0x7005:
        goto LAB_0001cde4;
      case 0x7006:
        goto switchD_0001c5b0_caseD_7006;
      case 0x7007:
        uVar2 = FUN_0001bea8();
        if (((uVar2 & 2) != 0) && (uVar2 = FUN_0001bea8(), (uVar2 & 8) == 0)) {
          FUN_0001c388();
          FUN_00021ba0(0x25,0,0);
        }
        goto LAB_0001cde4;
      case 0x7008:
        uVar2 = FUN_0001bea8();
        if ((uVar2 & 2) == 0) {
          uVar4 = uRam0001ce00;
          goto LAB_0001cafc;
        }
        goto LAB_0001cde4;
      case 0x7009:
        break;
      case 0x700a:
        goto code_r0x0001c9c4;
      case 0x700b:
        break;
      case 0x700c:
        goto LAB_0001cc2c;
      case 0x700d:
        FUN_0001bc80(0);
LAB_0001cc2c:
        FUN_0001bc80(0);
        if (uStack00000010 == 0x700c) {
          FUN_0002186c(0x55,DAT_0001c9b0);
          FUN_0001bb70();
        }
        goto LAB_0001cde4;
      case 0x700e:
        goto LAB_0001cde4;
      case 0x700f:
        uVar2 = FUN_0001bea8();
        if ((uVar2 & 8) != 0) goto LAB_0001cd00;
        uVar2 = FUN_0001bea8();
        if ((uVar2 & 2) != 0) {
          FUN_0001bc80(0);
        }
        iVar3 = FUN_00027040(0);
        if (iVar3 == 0) {
          iVar3 = FUN_0001f2a0();
          if (iVar3 == 0) goto LAB_0001c820;
        }
        else {
          FUN_00025910(*unaff_r6);
          uStack00000008 = 0xff;
          FUN_00025984(*unaff_r6,uRam0001ce0c,&uStack00000008,1);
          iVar3 = iRam0001ce10;
LAB_0001ccd0:
          uVar4 = *puRam0001ce14;
LAB_0001cd1c:
          FUN_00025984(uVar4,iVar3);
        }
        goto LAB_0001cde4;
      }
    }
    else {
      bVar8 = SBORROW4(uStack00000010,0x5000);
      iVar6 = uStack00000010 + -0x5000;
      bVar7 = iVar6 == 0;
      iVar3 = iVar6;
      if (0x4fff < uStack00000010) {
        bVar8 = SBORROW4(iVar6,0x25);
        iVar3 = uStack00000010 + -0x5025;
        bVar7 = iVar6 == 0x25;
      }
      if (bVar7) {
        uVar4 = 0x108;
LAB_0001cafc:
        FUN_0008f67c(*unaff_r8,uVar4);
LAB_0001cdec:
        *(undefined1 *)(DAT_0001c96c + 1) = unaff_r11;
        FUN_0001c428();
        return;
      }
      if (iVar3 < 0 == bVar8) {
        if (uStack00000010 != 0x7000) {
          if (uStack00000010 == 0x7001) {
LAB_0001c950:
            unaff_r4 = unaff_r4 & 0xfffffffe;
            uVar2 = FUN_0001bea8();
            if ((uVar2 & 8) != 0) goto LAB_0001cd00;
            uVar4 = 1;
            goto LAB_0001c964;
          }
          iVar3 = 0;
          if (uStack00000010 != 0x7002) {
            iVar3 = uStack00000010 + -0x7000;
          }
          if (uStack00000010 != 0x7002 && iVar3 != 3) goto switchD_0001c550_default;
          goto LAB_0001cde4;
        }
        uVar2 = FUN_0001bea8(0x7000,(int)((ulonglong)uVar9 >> 0x20));
        if ((uVar2 & 2) != 0) {
          if (*pcRam0001ce08 == '\0') goto LAB_0001cde4;
          FUN_0001bc80(0);
        }
        uVar2 = FUN_0001bea8();
        if ((uVar2 & 8) == 0) {
          uVar2 = FUN_0001bea8();
          if ((uVar2 & 2) != 0) {
            FUN_0001bc80(0);
          }
          FUN_0001e844(0);
          FUN_000904e4(5);
          FUN_0001bb70();
          FUN_000904e4(2);
          iVar3 = FUN_00060a04();
joined_r0x0001cb6c:
          if (iVar3 != 0) {
            FUN_0000cdd0();
            FUN_0000cda0();
            FUN_00060d3c(0);
          }
          uVar4 = 0x104;
          goto LAB_0001cafc;
        }
        goto LAB_0001cd00;
      }
      switch(uStack00000010) {
      case 0x500d:
        if (0 < *(short *)pbVar1) {
          FUN_000e34a4((int)*(short *)pbVar1,unaff_r5,uStack0000000c);
          FUN_000e2c54((int)*(short *)pbVar1);
        }
        if (unaff_r5 != 0) {
LAB_0001ca60:
          FUN_00000560(unaff_r5);
          unaff_r5 = 0;
        }
        goto LAB_0001cde4;
      case 0x500e:
        break;
      case 0x500f:
        break;
      case 0x5010:
        FUN_0001c130(pbVar1);
        goto LAB_0001cde4;
      case 0x5011:
        break;
      case 0x5012:
        FUN_0001beb4(pbVar1);
        goto LAB_0001cde4;
      case 0x5013:
        FUN_000220cc(*pbVar1);
        FUN_00021a1c();
        FUN_00021c14(0x17,0,0);
        FUN_00021ba0(0x18,0,0);
        FUN_0001bb54(0xfffffffe);
        FUN_0001bad8();
        goto joined_r0x0001c8c0;
      case 0x5014:
        uVar2 = FUN_0001bea8();
        if ((uVar2 & 8) != 0) {
          FUN_000904e4(2);
LAB_0001cd14:
          uVar4 = *unaff_r6;
          iVar3 = uStack00000010;
          goto LAB_0001cd1c;
        }
        FUN_000220cc(*pbVar1);
        uVar2 = FUN_0001bea8();
        if ((uVar2 & 2) != 0) {
          FUN_0001bc80(0);
        }
        FUN_0001bb70();
        FUN_00021a1c();
        FUN_00021c14(0x18,0,0);
        FUN_00021ba0(0x17,0,0);
        *DAT_0001c9b4 = unaff_r11;
        *DAT_0001c9b8 = unaff_r11;
        FUN_00021c14(0x25,0,0);
        FUN_0001bb54(1);
joined_r0x0001c8c0:
        unaff_r4 = unaff_r4 | 2;
        if (unaff_r4 == 7) {
          unaff_r4 = 6;
LAB_0001c820:
          uVar4 = 0;
LAB_0001c964:
          FUN_0001bc80(uVar4);
        }
        goto LAB_0001cde4;
      }
    }
switchD_0001c550_default:
    uVar2 = FUN_0001bea8();
    if ((uVar2 & 2) != 0) {
      iVar3 = 0;
      if (uStack00000010 != 0x701a) {
        iVar3 = uStack00000010 + -0x7000;
      }
      if (uStack00000010 != 0x701a && iVar3 != 0x19) goto LAB_0001cde4;
    }
    FUN_0002361c();
    goto LAB_0001cde4;
  }
  bVar8 = SBORROW4(uStack00000010,0x7000);
  iVar6 = uStack00000010 + -0x7000;
  bVar7 = iVar6 == 0;
  iVar3 = iVar6;
  if (0x6fff < uStack00000010) {
    bVar8 = SBORROW4(iVar6,0x41);
    iVar3 = uStack00000010 + -0x7041;
    bVar7 = iVar6 == 0x41;
  }
  if (bVar7) {
    uVar2 = FUN_0001bea8();
    if ((uVar2 & 8) == 0) {
      uVar2 = FUN_0001bea8();
      if ((uVar2 & 2) != 0) {
        FUN_0001bc80(0);
      }
      FUN_000904e4(1);
      iVar3 = FUN_00060a04();
      if (iVar3 != 0) {
        FUN_0000cdd0();
        FUN_0000cda0();
        FUN_00060d3c(0);
        FUN_000904e4(5);
        FUN_00005ff8();
        FUN_000904e4(200);
LAB_0001ca2c:
        uVar4 = 0;
LAB_0001ca30:
        FUN_00022e08(uVar4);
      }
      goto LAB_0001cde4;
    }
  }
  else {
    if (iVar3 < 0 != bVar8) {
      bVar8 = SBORROW4(uStack00000010,0x7000);
      iVar6 = uStack00000010 + -0x7000;
      bVar7 = iVar6 == 0;
      iVar3 = iVar6;
      if (0x6fff < uStack00000010) {
        bVar8 = SBORROW4(iVar6,0x3c);
        iVar3 = uStack00000010 + -0x703c;
        bVar7 = iVar6 == 0x3c;
      }
      if (bVar7) {
        uVar4 = 0;
      }
      else {
        if (iVar3 < 0 != bVar8) {
          bVar8 = SBORROW4(uStack00000010,0x7000);
          iVar6 = uStack00000010 + -0x7000;
          bVar7 = iVar6 == 0;
          iVar3 = iVar6;
          if (0x6fff < uStack00000010) {
            bVar8 = SBORROW4(iVar6,0x17);
            iVar3 = uStack00000010 + -0x7017;
            bVar7 = iVar6 == 0x17;
          }
          if (bVar7) {
            FUN_0001f9c4();
            goto LAB_0001cde4;
          }
          if (iVar3 < 0 != bVar8) {
            if (uStack00000010 == 0x7012) {
              uVar2 = FUN_0001bea8();
              if ((uVar2 & 8) != 0) goto LAB_0001cd00;
              uVar2 = FUN_0001bea8();
              if ((uVar2 & 2) != 0) {
                FUN_0001bc80(0);
              }
              unaff_r4 = unaff_r4 & 0xfffffffe;
              FUN_0000cdd0();
              FUN_0000cda0();
              iVar3 = FUN_00060a04();
              if (iVar3 != 0) {
                FUN_0001e844(0);
                FUN_00060d3c(0);
              }
              FUN_00021a1c();
              FUN_0001bb70();
              FUN_00021a1c();
              FUN_00021ea0();
            }
            else {
              if (uStack00000010 != 0x7013) goto switchD_0001c550_default;
              unaff_r4 = unaff_r4 & 0xfffffffe;
              FUN_00022020();
              FUN_0000cda0();
              FUN_000904e4(10);
              iVar3 = FUN_00021e94();
              if (iVar3 != 0xff) {
                FUN_0001bad8();
              }
              FUN_0000cc80();
              FUN_0000cdb8(*DAT_0001c97c);
            }
            goto LAB_0001cde4;
          }
          if (uStack00000010 == 0x7035) {
            iVar3 = FUN_00007278();
            FUN_00006ca4(iVar3 != 0);
            goto LAB_0001cde4;
          }
          if (uStack00000010 == 0x703a) {
            uVar2 = FUN_0001bea8();
            if ((uVar2 & 2) != 0) {
              uVar2 = FUN_0001ef50();
              if (uVar2 < 2) {
                uVar4 = 0x39800;
              }
              else {
                uVar4 = 0x20800;
              }
              unaff_r5 = FUN_0006391c(DAT_0001c9a8,uVar4,0x20);
              if (unaff_r5 != 0) {
                iVar3 = FUN_0006e4f0(unaff_r5,&uStack0000000c);
                if (iVar3 != -1) {
                  iVar3 = DAT_0001c9ac;
                  goto LAB_0001ccd0;
                }
                goto LAB_0001ca60;
              }
            }
            goto LAB_0001cde4;
          }
          goto switchD_0001c550_default;
        }
        if (uStack00000010 != 0x703d) {
          if (uStack00000010 == 0x703e) {
            FUN_00021dc8(*pbVar1);
          }
          else {
            if (uStack00000010 == 0x703f) {
              uVar4 = 1;
            }
            else {
              if (uStack00000010 != 0x7040) goto switchD_0001c550_default;
              uVar4 = 0;
            }
            FUN_00021d20(uVar4);
          }
          goto LAB_0001cde4;
        }
        uVar4 = 1;
      }
      FUN_00023148(uVar4);
      goto LAB_0001cde4;
    }
    bVar8 = SBORROW4(uStack00000010,0x7000);
    iVar6 = uStack00000010 + -0x7000;
    bVar7 = iVar6 == 0;
    iVar3 = iVar6;
    if (0x6fff < uStack00000010) {
      bVar8 = SBORROW4(iVar6,0x4b);
      iVar3 = uStack00000010 + -0x704b;
      bVar7 = iVar6 == 0x4b;
    }
    if (bVar7) goto LAB_0001cde4;
    if (iVar3 < 0 != bVar8) {
      if (uStack00000010 != 0x7042) {
        if (uStack00000010 == 0x7046) {
          uVar2 = FUN_0001bea8();
          if ((uVar2 & 8) != 0) goto LAB_0001cd00;
          uVar2 = FUN_0001bea8();
          if ((uVar2 & 2) != 0) {
            FUN_0001bc80(0);
            FUN_000904e4(2);
          }
          uVar2 = FUN_000257f0();
          uVar5 = (uint)*pbVar1;
          if (uVar2 == uVar5) goto LAB_0001cde4;
          if (uVar5 == 0) {
            FUN_0000cc80();
            FUN_0000cdb8(0);
            FUN_00025800(0);
            goto LAB_0001cde4;
          }
          if (uVar5 == 1) {
            FUN_00025800(1);
            uVar4 = DAT_0001c9bc;
            goto LAB_0001cafc;
          }
          if (uVar5 != 2) goto LAB_0001cde4;
        }
        else {
          if (uStack00000010 == 0x7049) goto LAB_0001c950;
          if (uStack00000010 != 0x704a) goto switchD_0001c550_default;
          uVar2 = FUN_0001bea8();
          if ((uVar2 & 10) != 0) goto LAB_0001cde4;
        }
        uVar4 = DAT_0001c9c0;
        goto LAB_0001cafc;
      }
      uVar2 = *(uint *)(pbVar1 + 8);
      bVar7 = uVar2 == 5;
      if (bVar7) {
        uVar2 = (uint)pbVar1[4];
      }
      if (!bVar7 || uVar2 != 7) {
        FUN_0001ebd4(pbVar1);
      }
      goto LAB_0001cde4;
    }
    if (uStack00000010 == 0x704d) goto LAB_0001cde4;
    if (uStack00000010 == 0x7061) {
      uVar2 = FUN_0001bea8();
      if ((uVar2 & 8) == 0) {
        uVar2 = FUN_0001bea8();
        if ((uVar2 & 2) != 0) {
          FUN_0001bc80(0);
        }
        FUN_0001e844(0);
        FUN_000904e4(5);
        FUN_0001bb70();
        FUN_000904e4(2);
        iVar3 = FUN_00060a04();
        goto joined_r0x0001cb6c;
      }
      goto LAB_0001cd00;
    }
    if (uStack00000010 != 0x7063) {
      if (uStack00000010 != 0x7066) goto switchD_0001c550_default;
      FUN_00021a1c();
      FUN_000904e4(2);
      FUN_0002186c(0x84,DAT_0001c9b0);
      goto LAB_0001cde4;
    }
    uVar2 = FUN_0001bea8();
    if ((uVar2 & 8) == 0) {
      uVar2 = FUN_0001bea8();
      if ((uVar2 & 2) != 0) {
        FUN_0001bc80(0);
      }
      FUN_0001bb70();
      FUN_000904e4(5);
      uVar4 = uRam0001ce04;
      goto LAB_0001cafc;
    }
  }
LAB_0001cd00:
  FUN_000904e4(2);
  goto LAB_0001cd14;
switchD_0001c5b0_caseD_7006:
  goto code_r0x0001c9c4;
}


