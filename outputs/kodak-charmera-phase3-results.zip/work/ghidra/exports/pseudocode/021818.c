/* entry VA 0x00021618, file offset 0x021818 */

undefined4 seed_21818(void)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined1 auStack_34 [44];
  
  uVar1 = FUN_000906b8();
  if (uVar1 < 0x1f5) {
    FUN_000db3f0(auStack_34,DAT_000216a8,0x29);
    FUN_00000270(auStack_34,s_C__JH__000216ac);
    FUN_0000031c(auStack_34,&DAT_000216b4);
    FUN_0000031c(auStack_34,s___bin_000216bc);
    iVar3 = DAT_00021534;
    iVar2 = FUN_000e2cf0(auStack_34,DAT_00021534,0x77);
    if (-1 < iVar2) {
      FUN_000e2c54();
      iVar3 = FUN_000002b4(iVar3 + 0x19,s_202505201029_000216c4,0xc);
      if (iVar3 != 0) {
        return 1;
      }
    }
  }
  return 0;
}


