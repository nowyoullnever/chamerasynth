/* entry VA 0x00021a2c, file offset 0x021c2c */

undefined4 seed_21c2c(uint param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint local_1c;
  uint local_18;
  uint local_14;
  
  if (*(int *)(param_1 + 8) != 0) {
    FUN_00000560();
  }
  uVar4 = (*(ushort *)(param_1 + 4) + 2) * (*(ushort *)(param_1 + 2) + 2);
  iVar1 = FUN_000637ac(DAT_00021a10,uVar4 * 2,s_ap_state_handling_ASCII_str_draw_00021b18);
  *(int *)(param_1 + 8) = iVar1;
  if (iVar1 == 0) {
    uVar2 = 0xffffffff;
  }
  else {
    iVar1 = FUN_000f0e10(iVar1);
    uVar2 = DAT_00021a14;
    if (iVar1 == 0) {
      FUN_000f0138(DAT_00021a14,&local_14,&local_18,&local_1c);
      FUN_000f04f4(*(ushort *)(param_1 + 2),*(ushort *)(param_1 + 2) >> 1,
                   *(undefined2 *)(param_1 + 4),local_14 & 0xff,local_18 & 0xff,local_1c & 0xff,
                   *(undefined4 *)(param_1 + 8));
    }
    else {
      for (uVar3 = 0; uVar3 < uVar4; uVar3 = uVar3 + 1) {
        *(short *)(*(int *)(param_1 + 8) + uVar3 * 2) = (short)uVar2;
      }
    }
    FUN_00024c9c(*(undefined4 *)(param_1 + 8),param_2,2);
    FUN_0008f67c(*DAT_00021a18,param_1 | 0xc000000);
    uVar2 = 0;
  }
  return uVar2;
}


