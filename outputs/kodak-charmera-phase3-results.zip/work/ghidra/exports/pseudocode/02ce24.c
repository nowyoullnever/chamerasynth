/* entry VA 0x0002cc24, file offset 0x02ce24 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 seed_2ce24(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0002cb88(1,0,param_3,param_4,param_4);
  FUN_0002c718(2,0);
  FUN_0002c80c(0);
  FUN_0002c884(2);
  FUN_0002c5d0();
  _DAT_d0000010 = DAT_0002cc5c;
  _DAT_d0000014 = DAT_0002cc60;
  _DAT_d00000e0 = DAT_0002cc64;
  _DAT_d000000c = _DAT_d000000c & 0xffffefff;
  _DAT_d000005c = _DAT_d000005c | 0x100;
  return 0;
}


