/* entry VA 0x0002db48, file offset 0x02dd48 */

void seed_2dd48(int param_1,undefined4 param_2,uint param_3,uint param_4)

{
  uint *puVar1;
  uint local_10;
  uint local_c;
  
  local_c = param_4 & 0xffffff00;
  local_10 = param_3 & 0xffffff00;
  FUN_00031064();
  FUN_00036054(0);
  FUN_0008cd28();
  seed_2ce24();
  seed_36274();
  FUN_0002e76c(8,&local_c);
  FUN_0002e76c(9,&local_10);
  if ((char)local_c == '\0' && (char)local_10 == '\0') {
    FUN_0002e9a4(8,0x2a);
    FUN_0002e9a4(9,6);
    FUN_000323f0(0x28);
  }
  thunk_FUN_000278b8(0);
  FUN_000666d8(5,6,4);
  puVar1 = DAT_0002dc58;
  *DAT_0002dc58 = param_1 + 3U & 0xfffffffc;
  puVar1[1] = 0x800000;
  FUN_000005d8();
  FUN_0003194c(0,100,0,DAT_0002dc5c);
  FUN_0008ff2c(DAT_0002dc64,0,DAT_0002dc60,0x35);
  FUN_00031064();
  FUN_0008d648();
  return;
}


