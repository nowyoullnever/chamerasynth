/* entry VA 0x00036074, file offset 0x036274 */

/* WARNING: Removing unreachable block (ram,0x00030ee0) */
/* WARNING: Removing unreachable block (ram,0x00030ee4) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 seed_36274(void)

{
  FUN_000310fc();
  FUN_000324f8();
  FUN_0003641c();
  FUN_000343d4();
  FUN_00033868();
  FUN_00033a40();
  FUN_0002e204(0);
  FUN_00031504();
  FUN_00031a98();
  FUN_000329f8();
  FUN_0002edec();
  FUN_00031094(1);
  FUN_00030df4(0,0);
  FUN_00030dd4(0,2);
  _DAT_d0000064 = _DAT_d0000064 & 0xfffff8ff | 0x100;
  return 0;
}


