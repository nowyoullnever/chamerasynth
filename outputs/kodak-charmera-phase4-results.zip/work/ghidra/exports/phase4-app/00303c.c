/* target VA 0x00002e3c, target file 0x00303c */
/* containing entry VA 0x00002e3c, file 0x00303c */

undefined8 FUN_00002e3c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  char *pcVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  uint extraout_r1;
  int iVar9;
  undefined4 *puVar10;
  undefined4 uVar11;
  int iVar12;
  int in_r12;
  int iVar13;
  int iVar14;
  bool bVar15;
  bool bVar16;
  undefined8 uVar17;
  undefined4 local_28;
  
  puVar10 = DAT_000031ac;
  iVar9 = DAT_000031a8;
  puVar4 = DAT_000031a4;
  puVar3 = DAT_000021a8;
  iVar1 = DAT_00002170;
  if (*(char *)(DAT_00002170 + 0xc) == -1) {
    uVar5 = 0xffffffff;
    goto LAB_0000318c;
  }
  local_28 = param_4;
  if (*(char *)(DAT_00002170 + 2) == '\0') {
    FUN_00002e08();
    FUN_000e3690();
    iVar6 = FUN_00026788(0);
    FUN_000e36b8();
    if (iVar6 == 0) {
      iVar12 = 0;
      do {
        iVar7 = FUN_000e2c88(2);
        iVar14 = 0;
        if (iVar7 != 0) {
          iVar14 = iVar12 + -2;
          iVar12 = iVar12 + 1;
        }
        *(short *)(iVar1 + 0x18) = (short)iVar7;
      } while (iVar14 < 0 != (iVar7 != 0 && SBORROW4(iVar12,3)));
    }
LAB_00002ee8:
    if (iVar6 < 0) goto LAB_00002ef0;
LAB_00002fb8:
    pcVar2 = DAT_00002174;
    *(undefined1 *)(iVar1 + 2) = 1;
    if (pcVar2[2] != '\0') {
      if (pcVar2[2] == '\x01') {
        local_28 = 0x79;
      }
      else {
        iVar6 = FUN_00007f88();
        if (iVar6 != 2) {
          in_r12 = *DAT_000031b8 - 0x100;
        }
        if (iVar6 != 2 && in_r12 != 2) {
          local_28 = 0x6a;
        }
        else {
          local_28 = 0x6f;
        }
      }
      pcVar2[2] = '\0';
      param_2 = 0;
      FUN_00025984(*puVar4,iVar9,&local_28,4,0,param_3);
    }
    if (*(char *)(iVar1 + 0xb) != '\x02') {
      if (*DAT_000031b0 != '\0') {
        *DAT_000031b0 = '\0';
        FUN_00023148(1);
      }
      iVar9 = DAT_000031bc;
      if (*(short *)(iVar1 + 0x18) == 0) {
        FUN_000e2e5c();
        *(undefined1 *)(iVar1 + 0xb) = 2;
        uVar17 = seed_21818(2,extraout_r1 >> 0x14);
        if ((int)uVar17 == 0) {
          FUN_000e3160(s_C__DCIM_000031c0,(int)((ulonglong)uVar17 >> 0x20));
          FUN_000e3160(s_C__SPIDCIM_000031c8);
          FUN_000e2b40(s_C__DCIM_000031c0);
          FUN_000e2740(2);
          *(undefined2 *)(iVar1 + 0x1e) = 0;
          iVar14 = DAT_0000262c;
          iVar12 = DAT_0000240c;
          iVar6 = DAT_00002190;
          *(undefined2 *)(iVar1 + 0x1c) = 0;
          iVar7 = 0;
          do {
            *(undefined2 *)(iVar12 + iVar7 * 2) = 0;
            *(undefined2 *)(iVar14 + iVar7 * 2) = 0;
            *(undefined2 *)(iVar6 + iVar7 * 2) = 0;
            iVar8 = iVar7 + 1;
            bVar15 = SBORROW4(iVar8,0x200);
            iVar13 = iVar7 + -0x1ff;
            if (0x1ff < iVar8) {
              bVar15 = SBORROW4(iVar13,0x71);
              iVar13 = iVar7 + -0x270;
            }
            iVar7 = iVar8;
          } while (iVar13 < 0 != bVar15);
          FUN_00002634();
          FUN_00002410();
          FUN_00002224();
          if (*pcVar2 != '\0') {
            FUN_0000922c();
            *pcVar2 = '\0';
          }
          FUN_000021ac();
          if (*(char *)(iVar1 + 8) == '\0') {
            iVar12 = (int)*(short *)(pcVar2 + 4);
            bVar16 = SBORROW4(iVar12,0x2700);
            iVar14 = iVar12 + -0x2700;
            bVar15 = iVar14 == 0;
            iVar6 = iVar14;
            if (0x26ff < iVar12) {
              bVar16 = SBORROW4(iVar14,0xf);
              iVar6 = iVar12 + -9999;
              bVar15 = iVar14 == 0xf;
            }
            *(short *)(iVar1 + 0xe) = *(short *)(pcVar2 + 4);
            if (!bVar15 && iVar6 < 0 == bVar16) {
              *(undefined2 *)(iVar1 + 0xe) = 0;
            }
          }
        }
        else {
          iVar9 = iVar9 + 0x12;
        }
        param_2 = 0;
        FUN_00025984(*puVar3,iVar9);
        goto LAB_00003184;
      }
      *(undefined1 *)(iVar1 + 0xb) = 2;
      uVar5 = *puVar3;
      uVar11 = 1;
      goto LAB_0000316c;
    }
    FUN_000e2b40(*(undefined4 *)(pcVar2 + 0x14));
  }
  else {
    iVar6 = FUN_000e0648();
    if (iVar6 == 0) {
      iVar6 = FUN_00027040(0);
      if (iVar6 != 0) {
        FUN_00002e08();
        iVar6 = FUN_000e2c88(2);
        *(undefined2 *)(iVar1 + 0x18) = 0;
        goto LAB_00002ee8;
      }
      goto LAB_00002fb8;
    }
LAB_00002ef0:
    pcVar2 = DAT_00002174;
    *(undefined1 *)(iVar1 + 2) = 0;
    pcVar2[2] = '\x02';
    if (*(char *)(iVar1 + 0xb) != -1) {
      if (*DAT_000031b0 != '\0') {
        *DAT_000031b0 = '\0';
        FUN_00023148(1);
      }
      *(undefined4 *)(iVar1 + 0x5c) = 0;
      *(undefined2 *)(iVar1 + 0x1a) = 0xffff;
      *(undefined2 *)(iVar1 + 0x1e) = 0;
      iVar14 = DAT_0000262c;
      iVar12 = DAT_0000240c;
      iVar6 = DAT_00002190;
      *(undefined2 *)(iVar1 + 0x1c) = 0;
      iVar7 = 0;
      do {
        *(undefined2 *)(iVar12 + iVar7 * 2) = 0;
        *(undefined2 *)(iVar14 + iVar7 * 2) = 0;
        *(undefined2 *)(iVar6 + iVar7 * 2) = 0;
        iVar8 = iVar7 + 1;
        bVar15 = SBORROW4(iVar8,0x200);
        iVar13 = iVar7 + -0x1ff;
        if (0x1ff < iVar8) {
          bVar15 = SBORROW4(iVar13,0x71);
          iVar13 = iVar7 + -0x270;
        }
        iVar7 = iVar8;
      } while (iVar13 < 0 != bVar15);
      *(undefined1 *)(iVar1 + 0xb) = 0xff;
      FUN_00025984(*puVar3,DAT_000031b4,puVar10,1,0,param_3);
      local_28 = 0x76;
      uVar5 = *puVar4;
      uVar11 = 4;
      puVar10 = &local_28;
LAB_0000316c:
      param_2 = 0;
      FUN_00025984(uVar5,iVar9,puVar10,uVar11);
      FUN_00072584(2);
    }
  }
LAB_00003184:
  FUN_00002dc8();
  uVar5 = 0;
LAB_0000318c:
  return CONCAT44(param_2,uVar5);
}


