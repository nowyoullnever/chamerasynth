/* target VA 0x000220cc, target file 0x0222cc */
/* containing entry VA 0x000220cc, file 0x0222cc */

void FUN_000220cc(undefined1 param_1)

{
  *(undefined1 *)(DAT_00021fcc + 4) = param_1;
  return;
}


