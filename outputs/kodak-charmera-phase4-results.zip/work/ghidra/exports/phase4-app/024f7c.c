/* target VA 0x00024d7c, target file 0x024f7c */
/* containing entry VA 0x00024d7c, file 0x024f7c */

void FUN_00024d7c(void)

{
  int iVar1;
  undefined4 uVar2;
  
  FUN_0001b868();
  uVar2 = FUN_0008f310(DAT_00025024,5);
  iVar1 = DAT_00025028;
  *(undefined4 *)(DAT_00025028 + 0x10) = uVar2;
  uVar2 = FUN_0002584c(0x80,0x80,0x28);
  *(undefined4 *)(iVar1 + 8) = uVar2;
  uVar2 = FUN_0002584c(0x40,0x40,0x28);
  *(undefined4 *)(iVar1 + 0xc) = uVar2;
  FUN_0000198c();
  uVar2 = FUN_0001fb24();
  FUN_00023cd0();
  FUN_0001f8a8(uVar2);
  FUN_00008b1c(uVar2);
  FUN_000236a4();
  *(undefined1 *)(DAT_00021fcc + 4) = 0xff;
  return;
}


