/* target VA 0x00025a38, target file 0x025c38 */
/* containing entry VA 0x00025a38, file 0x025c38 */

undefined4 FUN_00025a38(int param_1,undefined4 *param_2,int param_3,uint param_4)

{
  undefined4 *puVar1;
  uint local_1c;
  
  local_1c = param_4;
  puVar1 = (undefined4 *)FUN_0008f560(*(undefined4 *)(param_1 + 8),0,&local_1c,param_4,param_3);
  if (((char)local_1c == '\0') && (puVar1 != (undefined4 *)0x0)) {
    FUN_0002582c(param_1);
    if (param_4 <= *(uint *)(param_1 + 4)) {
      *param_2 = *puVar1;
      if (param_4 != 0 && param_3 != 0) {
        FUN_00000340(param_3,puVar1 + 1);
      }
      *puVar1 = 0;
      FUN_0008fc50(*(undefined4 *)(param_1 + 0x14));
      return 0;
    }
    FUN_0008fc50(*(undefined4 *)(param_1 + 0x14));
  }
  return 0xffffffff;
}


