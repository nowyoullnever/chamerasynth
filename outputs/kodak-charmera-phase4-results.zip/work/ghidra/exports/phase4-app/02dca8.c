/* target VA 0x0002daa8, target file 0x02dca8 */
/* containing entry VA 0x0002daa8, file 0x02dca8 */

undefined8 thunk_FUN_000278b8(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  char *pcVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 unaff_r4;
  undefined4 unaff_r5;
  undefined4 uVar7;
  undefined4 uVar8;
  uint uVar9;
  
  iVar6 = 0;
  FUN_00000488(DAT_00027d18,0,0x8c,param_4,param_4);
  iVar5 = DAT_00027d1c;
  do {
    *(undefined4 *)(iVar5 + iVar6 * 4) = 0;
    puVar1 = DAT_00027d14;
    iVar6 = iVar6 + 1;
  } while (iVar6 < 5);
  DAT_00027d14[1] = 0;
  uVar4 = FUN_0008f310(DAT_00027d20,0x40);
  *puVar1 = uVar4;
  uVar2 = DAT_00027d28;
  uVar4 = DAT_00027d24;
  uVar7 = 0;
  if (param_1 < 0x40) {
    uVar8 = DAT_00027d24;
    uVar9 = param_1;
    FUN_000efd84(DAT_00027d28);
    iVar6 = DAT_0009071c;
    pcVar3 = DAT_00090718;
    if (*DAT_00090718 == '\0') {
      if (*(int *)(DAT_0009071c + param_1 * 4) == 0) {
        *(undefined4 *)(DAT_0009071c + param_1 * 4) = 1;
        FUN_000efda4();
        uVar4 = FUN_0008cc88(uVar2,0,uVar4,0,uVar7,uVar8,uVar9,unaff_r4,unaff_r5);
        uVar7 = 0;
        iVar5 = FUN_0008cfcc(param_1,uVar4);
        if (iVar5 == 0) {
          if (pcVar3[5] == '\x01') {
            FUN_0008cf60();
          }
        }
        else {
          FUN_000efd84();
          *(undefined4 *)(iVar6 + param_1 * 4) = 0;
          FUN_000efda4();
        }
      }
      else {
        FUN_000efda4();
        iVar5 = 0x28;
      }
    }
    else {
      FUN_000efda4();
      iVar5 = 0x10;
    }
  }
  else {
    iVar5 = 0x2a;
  }
  return CONCAT44(uVar7,iVar5);
}


