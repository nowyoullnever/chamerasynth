/* target VA 0x0002db34, target file 0x02dd34 */
/* containing entry VA 0x0002daac, file 0x02dcac */

/* WARNING: Removing unreachable block (ram,0x00090014) */
/* WARNING: Removing unreachable block (ram,0x00090024) */

undefined4 FUN_0002daac(void)

{
  byte bVar1;
  char *pcVar2;
  int iVar3;
  byte bVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  undefined4 in_r3;
  int iVar8;
  
  FUN_0008ff2c(DAT_0002dc24,0,DAT_0002dc20,0x11,in_r3);
  FUN_0008ff2c(DAT_0002dc2c,0,DAT_0002dc28,7);
  FUN_0008ff2c(DAT_0002dc34,0,DAT_0002dc30,1);
  FUN_0008ff2c(DAT_0002dc3c,0,DAT_0002dc38,0x34);
  FUN_0008ff2c(DAT_0002dc44,0,DAT_0002dc40,0x30);
  FUN_0008ff2c(DAT_0002dc4c,0,DAT_0002dc48,0x32);
  FUN_0008ff2c(DAT_0002dc54,0,DAT_0002dc50,0x2d);
  pcVar2 = DAT_00090718;
  if (*DAT_00090718 == '\0') {
    uVar5 = FUN_000efd84(0);
    iVar3 = DAT_0009071c;
    bVar1 = *(byte *)(*(int *)(pcVar2 + 0x18) + 0x2e);
    iVar8 = *(int *)(DAT_0009071c + (uint)bVar1 * 4);
    if (iVar8 == 0) {
      FUN_000efda4(uVar5);
      uVar5 = 0x3c;
    }
    else if (iVar8 == 1) {
      FUN_000efda4(uVar5);
      uVar5 = 0xb;
    }
    else {
      uVar7 = (uint)*(byte *)(iVar8 + 0x30);
      bVar4 = *(byte *)(DAT_0008f738 + uVar7) & ~*(byte *)(iVar8 + 0x31);
      *(byte *)(DAT_0008f738 + uVar7) = bVar4;
      if (bVar4 == 0) {
        pcVar2[4] = pcVar2[4] & ~*(byte *)(iVar8 + 0x32);
      }
      iVar6 = *(int *)(iVar8 + 0x1c);
      if ((iVar6 != 0) &&
         (bVar4 = *(byte *)(iVar6 + uVar7 + 0xb) & ~*(byte *)(iVar8 + 0x31),
         *(byte *)(iVar6 + uVar7 + 0xb) = bVar4, bVar4 == 0)) {
        *(byte *)(iVar6 + 10) = *(byte *)(iVar6 + 10) & ~*(byte *)(iVar8 + 0x32);
      }
      if (*(int *)(iVar8 + 0x24) != 0) {
        FUN_0008dbec();
      }
      *(undefined2 *)(iVar8 + 0x2a) = 0;
      *(undefined1 *)(iVar8 + 0x2c) = 0;
      *(undefined1 *)(iVar8 + 0x2d) = 0;
      if (pcVar2[1] != -1) {
        pcVar2[1] = pcVar2[1] + '\x01';
      }
      FUN_000efda4(uVar5);
      uVar5 = FUN_000efd84();
      if (pcVar2[1] != '\0') {
        pcVar2[1] = pcVar2[1] + -1;
      }
      FUN_0008cc7c(iVar8);
      pcVar2[6] = pcVar2[6] + -1;
      *(undefined4 *)(iVar3 + (uint)bVar1 * 4) = 0;
      if (*(int *)(iVar8 + 0x18) == 0) {
        *(undefined4 *)(*(int *)(iVar8 + 0x14) + 0x18) = 0;
        *(undefined4 *)(pcVar2 + 0x24) = *(undefined4 *)(iVar8 + 0x14);
      }
      else {
        *(undefined4 *)(*(int *)(iVar8 + 0x18) + 0x14) = *(undefined4 *)(iVar8 + 0x14);
        *(undefined4 *)(*(int *)(iVar8 + 0x14) + 0x18) = *(undefined4 *)(iVar8 + 0x18);
      }
      *(undefined4 *)(iVar8 + 0x14) = *(undefined4 *)(pcVar2 + 0x1c);
      *(int *)(pcVar2 + 0x1c) = iVar8;
      *(undefined1 *)(iVar8 + 0x48) = 0x3f;
      *(undefined1 *)(iVar8 + 0x49) = 0;
      FUN_000efda4(uVar5);
      FUN_0008cf60();
      uVar5 = 0;
    }
  }
  else {
    uVar5 = 0x3f;
  }
  return uVar5;
}


