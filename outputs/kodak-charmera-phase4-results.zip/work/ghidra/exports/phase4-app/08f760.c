/* target VA 0x0008f560, target file 0x08f760 */
/* containing entry VA 0x0008f560, file 0x08f760 */

undefined4 FUN_0008f560(char *param_1,undefined2 param_2,undefined1 *param_3)

{
  char *pcVar1;
  undefined1 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  
  pcVar1 = DAT_0008ee4c;
  if (param_3 != (undefined1 *)0x0) {
    if (param_1 == (char *)0x0) {
      uVar2 = 4;
    }
    else if (*param_1 == '\x02') {
      if (*DAT_0008ee4c == '\0') {
        uVar3 = FUN_000efd84();
        iVar4 = *(int *)(param_1 + 4);
        if (*(short *)(iVar4 + 0x16) != 0) {
          puVar5 = *(undefined4 **)(iVar4 + 0x10);
          puVar6 = puVar5 + 1;
          *(undefined4 **)(iVar4 + 0x10) = puVar6;
          uVar7 = *puVar5;
          *(short *)(iVar4 + 0x16) = *(short *)(iVar4 + 0x16) + -1;
          if (puVar6 == *(undefined4 **)(iVar4 + 8)) {
            *(undefined4 *)(iVar4 + 0x10) = *(undefined4 *)(iVar4 + 4);
          }
LAB_0008f5f8:
          FUN_000efda4(uVar3);
          *param_3 = 0;
          return uVar7;
        }
        iVar4 = *(int *)(pcVar1 + 0x18);
        *(byte *)(iVar4 + 0x2c) = *(byte *)(iVar4 + 0x2c) | 4;
        *(undefined1 *)(iVar4 + 0x2d) = 0;
        *(undefined2 *)(iVar4 + 0x2a) = param_2;
        FUN_0008d818(param_1);
        FUN_000efda4(uVar3);
        FUN_0008cf60();
        uVar3 = FUN_000efd84();
        iVar4 = *(int *)(pcVar1 + 0x18);
        if (*(char *)(iVar4 + 0x2d) != '\x01') {
          uVar7 = *(undefined4 *)(iVar4 + 0x20);
          *(undefined4 *)(iVar4 + 0x20) = 0;
          *(undefined1 *)(iVar4 + 0x2c) = 0;
          *(undefined4 *)(iVar4 + 0x1c) = 0;
          goto LAB_0008f5f8;
        }
        FUN_0008d87c(param_1);
        FUN_000efda4(uVar3);
        uVar2 = 10;
      }
      else {
        uVar2 = 2;
      }
    }
    else {
      uVar2 = 1;
    }
    *param_3 = uVar2;
  }
  return 0;
}


