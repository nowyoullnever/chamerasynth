/* seed 0x000004cc, entry 0x000004cc, file 0x0006cc */

undefined4 FUN_000004cc(int param_1,int param_2,uint param_3)

{
  undefined4 uVar1;
  uint uVar2;
  
  uVar2 = 0;
  while( true ) {
    if (param_3 <= uVar2) {
      return 0;
    }
    if (*(char *)(param_1 + uVar2) != *(char *)(param_2 + uVar2)) break;
    uVar2 = uVar2 + 1;
  }
  if (*(char *)(param_2 + uVar2) < *(char *)(param_1 + uVar2)) {
    uVar1 = 1;
  }
  else {
    uVar1 = 0xffffffff;
  }
  return uVar1;
}


