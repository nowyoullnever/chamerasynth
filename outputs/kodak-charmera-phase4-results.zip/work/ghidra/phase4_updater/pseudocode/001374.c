/* seed 0x00001174, entry 0x00001174, file 0x001374 */

undefined4 FUN_00001174(void)

{
  ushort uVar1;
  char *pcVar2;
  undefined4 uVar3;
  
  pcVar2 = *(char **)(DAT_000014a0 + 0x10);
  if (pcVar2 == (char *)0x0) {
    uVar3 = 4;
  }
  else if (*pcVar2 == '\x03') {
    uVar3 = FUN_000efd84(3);
    if (pcVar2[10] == '\0') {
      uVar1 = *(ushort *)(pcVar2 + 8);
      if (0xfeff < uVar1 && 0xfe < uVar1 - 0xff00) {
        FUN_000efda4(uVar3);
        return 0x32;
      }
      *(ushort *)(pcVar2 + 8) = uVar1 + 1;
      FUN_000efda4(uVar3);
    }
    else {
      FUN_0008d774(pcVar2,0,1);
      FUN_000efda4(uVar3);
      FUN_0008cf60();
    }
    uVar3 = 0;
  }
  else {
    uVar3 = 1;
  }
  return uVar3;
}


