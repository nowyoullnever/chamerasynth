/* seed 0x00001180, entry 0x00001180, file 0x001380 */

void FUN_00001180(void)

{
  undefined4 in_r3;
  undefined4 auStack_8 [2];
  
  auStack_8[0] = in_r3;
  FUN_0008fb78(*(undefined4 *)(DAT_000014a0 + 0x10),0,auStack_8);
  return;
}


