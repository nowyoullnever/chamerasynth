/* seed 0x0000119c, entry 0x0000119c, file 0x00139c */

undefined4 FUN_0000119c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  
  FUN_00001180();
  uVar1 = FUN_000306b4(0,param_1,param_2,0x100,param_4);
  FUN_00001174();
  return uVar1;
}


