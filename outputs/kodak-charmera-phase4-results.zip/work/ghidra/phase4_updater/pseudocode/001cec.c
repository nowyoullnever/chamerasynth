/* seed 0x00001aec, entry 0x00001aec, file 0x001cec */

undefined4 FUN_00001aec(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  
  FUN_00001180();
  uVar1 = FUN_00030800(0,param_1,param_2,0x100,param_4);
  FUN_00001174();
  return uVar1;
}


