/* seed 0x00001b20, entry 0x00001b20, file 0x001d20 */

undefined4 seed_1d20(undefined4 param_1)

{
  undefined4 uVar1;
  
  FUN_00001180();
  uVar1 = FUN_0003060c(param_1);
  FUN_00001174();
  return uVar1;
}


