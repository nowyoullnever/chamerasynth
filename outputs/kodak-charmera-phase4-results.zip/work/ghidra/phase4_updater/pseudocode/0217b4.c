/* seed 0x000215b4, entry 0x000215b4, file 0x0217b4 */

void seed_217b4(void)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int unaff_r7;
  undefined1 unaff_r9;
  int unaff_r10;
  
  seed_1d20(unaff_r10 + 0x10000);
  FUN_000904e4(5);
  if (unaff_r7 == 0x14) {
    uVar1 = 2;
  }
  else {
    uVar1 = 1;
  }
  FUN_000208e4(uVar1,unaff_r9);
  uVar3 = 0;
  do {
    iVar2 = FUN_00030efc(0);
    if (iVar2 == 0) {
      uVar3 = 0;
    }
    else {
      uVar3 = uVar3 + 1;
      if (0x13 < uVar3) {
        FUN_000284a8(0);
        FUN_00030ce8(0);
      }
    }
    FUN_000904e4(5);
  } while( true );
}


