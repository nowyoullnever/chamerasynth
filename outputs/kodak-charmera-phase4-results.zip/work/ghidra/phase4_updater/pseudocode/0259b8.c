/* seed 0x000257b8, entry 0x000257b8, file 0x0259b8 */

void phase4_seed_257b8(void)

{
  uint unaff_r4;
  int unaff_r5;
  undefined4 unaff_r6;
  undefined4 unaff_r7;
  undefined4 unaff_r8;
  undefined4 unaff_r9;
  undefined4 unaff_r10;
  undefined4 unaff_r11;
  undefined4 uStack00000004;
  undefined1 uStack00000008;
  
code_r0x000257b8:
  seed_21370();
switchD_000256dc_default:
  do {
    do {
      uStack00000004 = unaff_r4;
      unaff_r4 = FUN_0008f560(*(undefined4 *)(unaff_r5 + 0x10),0,&uStack00000008);
    } while (unaff_r4 == 0);
  } while (uStack00000008 != '\0');
  *DAT_00025824 = (short)(unaff_r4 & 0x1ff);
  switch(unaff_r4 & 0x1ff) {
  case 0x100:
    *(undefined4 *)(unaff_r5 + 0x14) = 0x100;
    *(undefined4 *)(unaff_r5 + 4) = unaff_r7;
    seed_65b0(&uStack00000004);
    goto switchD_000256dc_default;
  case 0x101:
    *(undefined4 *)(unaff_r5 + 0x14) = DAT_00025638;
    *(undefined4 *)(unaff_r5 + 4) = unaff_r7;
    FUN_0001c444(&uStack00000004);
    goto switchD_000256dc_default;
  case 0x102:
    *(undefined4 *)(unaff_r5 + 0x14) = DAT_00025634;
    *(undefined4 *)(unaff_r5 + 4) = 2;
    FUN_0001d4fc(&uStack00000004);
    goto switchD_000256dc_default;
  case 0x103:
    goto switchD_000256dc_default;
  case 0x104:
    *(undefined4 *)(unaff_r5 + 0x14) = 0x104;
    *(undefined4 *)(unaff_r5 + 4) = unaff_r6;
    FUN_0000ad80(&uStack00000004,unaff_r4 >> 0x10);
    unaff_r4 = unaff_r4 & 0xffff;
    goto switchD_000256dc_default;
  case 0x105:
    *(undefined4 *)(unaff_r5 + 0x14) = DAT_0002563c;
    (*(code *)(*(uint *)(DAT_00025828 + 4) & 0xfffffffc))(&uStack00000004);
    break;
  case 0x106:
    goto switchD_000256dc_default;
  case 0x107:
    goto switchD_000256dc_default;
  case 0x108:
    goto LAB_000257ac;
  case 0x109:
    *(undefined4 *)(unaff_r5 + 0x14) = unaff_r9;
    break;
  case 0x10a:
    *(undefined4 *)(unaff_r5 + 0x14) = unaff_r10;
    break;
  case 0x10b:
    *(char *)(unaff_r5 + 1) = (char)unaff_r7;
    goto switchD_000256dc_default;
  case 0x10c:
    goto switchD_000256dc_default;
  case 0x10d:
    *(undefined4 *)(unaff_r5 + 4) = unaff_r6;
    *(undefined4 *)(unaff_r5 + 0x14) = unaff_r11;
    FUN_0002506c(&uStack00000004);
  default:
    goto switchD_000256dc_default;
  }
  *(undefined4 *)(unaff_r5 + 4) = unaff_r6;
  goto switchD_000256dc_default;
LAB_000257ac:
  *(undefined4 *)(unaff_r5 + 4) = 3;
  *(undefined4 *)(unaff_r5 + 0x14) = unaff_r8;
  goto code_r0x000257b8;
}


