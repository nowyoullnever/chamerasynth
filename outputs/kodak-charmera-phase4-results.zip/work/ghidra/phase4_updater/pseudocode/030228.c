/* seed 0x00030028, entry 0x00030028, file 0x030228 */

undefined4 FUN_00030028(uint *param_1)

{
  char cVar1;
  uint *puVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  byte *unaff_r6;
  uint uVar12;
  
  puVar2 = DAT_000307ec;
  iVar4 = FUN_00030ab8(1);
  if (iVar4 < 0) {
    return 0xffffffff;
  }
  uVar5 = *puVar2;
  uVar9 = (*(byte *)((int)param_1 + 5) & 3) << 6 | (*(byte *)((int)param_1 + 6) & 3) << 4 |
          (*(byte *)((int)param_1 + 7) & 3) << 2;
  uVar6 = puVar2[1];
  uVar10 = (uint)*(byte *)((int)param_1 + 2);
  uVar7 = puVar2[2];
  uVar11 = (uint)*(byte *)((int)param_1 + 3) | ((byte)param_1[1] & 0xf) << 8;
  uVar8 = uVar11 | uVar7 & 0xfffff000;
  if ((param_1[2] & 0xff000000) == 0) {
    uVar12 = puVar2[0xb] & 0xffff00ff;
  }
  else {
    uVar12 = puVar2[0xb] | 0xff00;
  }
  cVar1 = *(char *)((int)param_1 + 1);
  switch(cVar1) {
  case '\0':
    uVar10 = uVar10 | uVar6 & 0xffffde00 | 0x200;
    break;
  case '\x01':
    uVar8 = uVar11 | uVar7 & 0xffffe000 | 0x2000;
    uVar10 = uVar10 | uVar6 & 0xffffdc00;
    break;
  case '\x02':
    goto LAB_00030120;
  case '\x03':
LAB_00030120:
    uVar8 = uVar11 | uVar7 & 0xffffc000 | 0x4000;
    uVar10 = uVar10 | uVar6 & 0xffffdc00;
    if (cVar1 != '\x02') {
LAB_00030178:
      param_1[4] = 0;
      goto LAB_0003017c;
    }
    goto LAB_00030170;
  case '\x04':
    if (*(byte *)((int)param_1 + 3) == 0xaa) {
      uVar10 = uVar10 | uVar6 & 0xffffdc00;
    }
    else {
      uVar10 = uVar10 | uVar6 & 0xfffffc00 | 0x2000;
    }
    uVar8 = uVar11 | uVar7 & 0xffff8000;
    goto LAB_00030178;
  case '\x05':
    goto LAB_00030158;
  case '\x06':
LAB_00030158:
    uVar8 = uVar11 | uVar7 & 0xffffd000 | 0x5000;
    uVar10 = uVar10 | uVar6 & 0xffffdc00;
    if (cVar1 != '\x05') goto LAB_00030178;
    goto LAB_00030170;
  default:
    return 0xffffffff;
  }
  param_1[4] = 0;
LAB_00030170:
  param_1[6] = 0;
LAB_0003017c:
  uVar6 = uVar9 | uVar5 & 0xfffffb03 | 0x100;
  if ((char)*param_1 != '\0') {
    uVar6 = uVar9 | uVar5 & 0xfffffa03;
  }
  *puVar2 = *puVar2 | 0x8000;
  puVar2[3] = param_1[2] & 0xffff;
  puVar2[4] = param_1[2] >> 0x10;
  puVar2[0xc] = param_1[3];
  puVar2[0xb] = uVar12;
  puVar2[7] = param_1[4];
  puVar2[8] = param_1[6];
  puVar2[2] = uVar8;
  *puVar2 = uVar6;
  puVar2[1] = uVar10;
  uVar3 = DAT_000307f4;
  uVar5 = param_1[4];
  if (uVar5 != 0) {
    unaff_r6 = (byte *)param_1[3];
  }
  if (uVar5 != 0 && unaff_r6 != (byte *)0x0) {
    while (0 < (int)uVar5) {
      puVar2[5] = (uint)*unaff_r6;
      unaff_r6 = unaff_r6 + 1;
      uVar5 = uVar5 - 1;
      iVar4 = FUN_00030ab8(uVar3);
      if (iVar4 < 0) {
        return 0xffffffff;
      }
      *puVar2 = *puVar2 | 0x8000;
    }
  }
  uVar5 = param_1[6];
  if (uVar5 != 0) {
    param_1 = (uint *)param_1[5];
  }
  if (uVar5 != 0 && param_1 != (uint *)0x0) {
    for (uVar5 = uVar5 + 3 >> 2; 0 < (int)uVar5; uVar5 = uVar5 - 1) {
      iVar4 = FUN_00030ab8(1);
      if (iVar4 < 0) {
        return 0xffffffff;
      }
      do {
      } while ((*puVar2 & 0x4000) != 0);
      puVar2[6] = 0;
      *param_1 = puVar2[6];
      param_1 = param_1 + 1;
    }
  }
  return 0;
}


