/* seed 0x0003028c, entry 0x0003028c, file 0x03048c */

void FUN_0003028c(void)

{
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  local_1c = 0;
  local_18 = 0;
  local_14 = 0;
  local_10 = 0;
  local_c = 0;
  local_8 = 0;
  local_20 = 0x60000;
  FUN_00030028(&local_20);
  return;
}


