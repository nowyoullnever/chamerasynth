/* seed 0x000303a4, entry 0x000303a4, file 0x0305a4 */

undefined1 FUN_000303a4(void)

{
  int iVar1;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  undefined1 *local_10;
  undefined4 local_c;
  undefined1 local_8 [8];
  
  local_20 = 0;
  local_1c = 0;
  local_18 = 0;
  local_14 = 0;
  local_24 = 0x50600;
  local_10 = local_8;
  local_c = 4;
  iVar1 = FUN_00030028(&local_24);
  if (iVar1 < 0) {
    local_8[0] = 0;
  }
  return local_8[0];
}


