/* seed 0x00030400, entry 0x00030400, file 0x030600 */

undefined4 FUN_00030400(void)

{
  uint uVar1;
  
  while (uVar1 = FUN_000303a4(), (uVar1 & 1) != 0) {
    FUN_00030a8c(1);
  }
  return 0;
}


