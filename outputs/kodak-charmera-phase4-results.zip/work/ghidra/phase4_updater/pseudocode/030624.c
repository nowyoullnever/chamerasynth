/* seed 0x00030424, entry 0x00030424, file 0x030624 */

int FUN_00030424(int param_1,uint param_2)

{
  int iVar1;
  code *local_2c;
  undefined4 local_28;
  undefined4 local_24;
  uint *local_20;
  undefined4 uStack_1c;
  undefined4 local_18;
  undefined4 local_14;
  uint local_10;
  
  local_10 = FUN_000303a4();
  if ((param_1 == 0 || (local_10 & param_2) == 0) && ((local_10 & param_2) != 0 || param_1 != 0)) {
    if (param_1 == 0) {
      local_10 = local_10 & ~param_2;
    }
    else {
      local_10 = local_10 | param_2;
    }
    iVar1 = FUN_0003028c();
    if (-1 < iVar1) {
      local_28 = 0;
      local_24 = 0;
      local_18 = 0;
      local_14 = 0;
      local_2c = FUN_00010500;
      local_20 = &local_10;
      uStack_1c = 1;
      iVar1 = FUN_00030028(&local_2c);
      if (-1 < iVar1) {
        iVar1 = FUN_00030400(DAT_000307f8);
      }
    }
  }
  else {
    iVar1 = 0;
  }
  return iVar1;
}


