/* seed 0x0003060c, entry 0x0003060c, file 0x03080c */

int FUN_0003060c(uint param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined1 auStack_3c [16];
  undefined4 local_2c;
  undefined4 local_28;
  uint local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  
  FUN_00030aec(auStack_3c);
  uVar1 = DAT_000307f8;
  iVar2 = FUN_00030400(DAT_000307f8);
  if ((-1 < iVar2) && (iVar2 = FUN_0003028c(), -1 < iVar2)) {
    local_28 = 0;
    local_20 = 0;
    local_1c = 0;
    local_18 = 0;
    local_14 = 0;
    local_2c = 0xd80100;
    local_24 = param_1 & 0xffff0000;
    iVar2 = FUN_00030028(&local_2c);
    if (-1 < iVar2) {
      iVar2 = FUN_00030400(uVar1);
    }
  }
  FUN_00030b14(auStack_3c);
  return iVar2;
}


