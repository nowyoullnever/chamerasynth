/* seed 0x000306b4, entry 0x000306b4, file 0x0308b4 */

int FUN_000306b4(int param_1,uint param_2,int param_3,uint param_4)

{
  undefined1 uVar1;
  uint uVar2;
  undefined1 auStack_48 [16];
  undefined4 local_38;
  undefined4 local_34;
  uint local_30;
  undefined4 local_2c;
  undefined4 local_28;
  int local_24;
  undefined4 local_20;
  
  FUN_00030aec(auStack_48);
  local_38 = 0;
  local_34 = 0;
  local_30 = 0;
  local_2c = 0;
  local_28 = 0;
  local_24 = 0;
  local_20 = 0;
  if (param_1 == 0) {
    local_38 = 0x30300;
  }
  else {
    if (param_1 == 1) {
      local_38 = 0xbb0300;
      uVar1 = 1;
    }
    else {
      if (param_1 != 2) {
        param_1 = -1;
        goto LAB_000307d8;
      }
      param_1 = FUN_00030424(1,0x40);
      if (param_1 < 0) goto LAB_000307d8;
      local_38 = CONCAT13(0xaa,CONCAT12(0xeb,CONCAT11(4,(undefined1)local_38)));
      uVar1 = 2;
    }
    local_34 = CONCAT13(uVar1,CONCAT12(uVar1,4));
  }
  local_30 = param_2 & 0xffffff00;
  param_4 = param_4 >> 8;
  if (param_4 == 0) {
    param_4 = 1;
  }
  local_20 = 0x100;
  uVar2 = 0;
  local_24 = param_3;
  while ((uVar2 < param_4 && (param_1 = FUN_00030028(&local_38), -1 < param_1))) {
    uVar2 = uVar2 + 1;
    local_30 = local_30 + 0x100;
    local_24 = local_24 + 0x100;
  }
LAB_000307d8:
  FUN_00030b14(auStack_48);
  return param_1;
}


