/* seed 0x00030800, entry 0x00030800, file 0x030a00 */

int FUN_00030800(int param_1,uint param_2,int param_3,uint param_4)

{
  ushort uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  undefined1 auStack_4c [16];
  undefined4 local_3c;
  undefined4 local_38;
  uint local_34;
  int local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  
  FUN_00030aec(auStack_4c);
  uVar2 = DAT_000307f8;
  iVar4 = FUN_00030400(DAT_000307f8);
  if (iVar4 < 0) goto LAB_0003092c;
  local_3c = 0;
  local_38 = 0;
  local_34 = 0;
  local_30 = 0;
  local_2c = 0;
  local_28 = 0;
  local_24 = 0;
  if (param_1 == 0) {
    local_3c = 0x20200;
  }
  else {
    if (param_1 != 2) {
      iVar4 = -1;
      goto LAB_0003092c;
    }
    iVar4 = FUN_00030424(1,0x40);
    uVar3 = local_3c;
    if (iVar4 < 0) goto LAB_0003092c;
    local_3c._3_1_ = SUB41(uVar3,3);
    local_3c._0_3_ = CONCAT12(0x38,CONCAT11(2,(undefined1)local_3c));
    uVar1 = (ushort)local_38;
    local_38 = CONCAT13(2,CONCAT12(2,uVar1 & 0xff));
  }
  local_34 = param_2 & 0xffffff00;
  param_4 = param_4 >> 8;
  if (param_4 == 0) {
    param_4 = 1;
  }
  local_2c = 0x100;
  uVar5 = 0;
  local_30 = param_3;
  while (((uVar5 < param_4 && (iVar4 = FUN_0003028c(), -1 < iVar4)) &&
         (iVar4 = FUN_00030028(&local_3c), -1 < iVar4))) {
    local_34 = local_34 + 0x100;
    local_30 = local_30 + 0x100;
    iVar4 = FUN_00030400(uVar2);
    if (iVar4 < 0) break;
    uVar5 = uVar5 + 1;
  }
LAB_0003092c:
  FUN_00030b14(auStack_4c);
  return iVar4;
}


