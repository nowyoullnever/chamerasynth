/* seed 0x00030a8c, entry 0x00030a8c, file 0x030c8c */

void FUN_00030a8c(int param_1)

{
  int iVar1;
  
  iVar1 = DAT_00030b4c;
  for (param_1 = param_1 * (*DAT_000307f0 >> 0xd); param_1 != 0; param_1 = param_1 + -1) {
    *(int *)(iVar1 + 0x380) = param_1;
  }
  return;
}


