/* seed 0x00030aec, entry 0x00030aec, file 0x030cec */

void FUN_00030aec(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = DAT_000307ec;
  *param_1 = *DAT_000307ec;
  param_1[1] = puVar1[1];
  param_1[2] = puVar1[2];
  param_1[3] = puVar1[0xb];
  return;
}


