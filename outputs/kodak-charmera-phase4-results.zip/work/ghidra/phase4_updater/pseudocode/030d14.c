/* seed 0x00030b14, entry 0x00030b14, file 0x030d14 */

void FUN_00030b14(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = DAT_000307ec;
  *DAT_000307ec = *param_1;
  puVar1[2] = param_1[2];
  puVar1[7] = 0;
  puVar1[8] = 0x20;
  puVar1[0xb] = param_1[3];
  puVar1[1] = param_1[1];
  return;
}


