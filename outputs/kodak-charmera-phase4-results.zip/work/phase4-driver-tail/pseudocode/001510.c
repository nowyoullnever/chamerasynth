/* Ghidra inferred pseudocode; file offset=0x001510 */

int FUN_00001310(void)

{
  int iVar1;
  
  iVar1 = FUN_00001298();
  if (iVar1 == 0xffff) {
    iVar1 = DAT_000014a4;
  }
  else {
    *(undefined4 *)(*(int *)(DAT_000014a0 + 4) + iVar1 * 0x20 + 0x18) = 0;
  }
  return iVar1;
}


