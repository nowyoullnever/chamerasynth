/* Ghidra inferred pseudocode; file offset=0x009a5c */

void FUN_0000985c(int param_1)

{
  int iVar1;
  undefined2 local_1c;
  undefined2 local_1a;
  undefined2 local_18;
  undefined2 local_16;
  undefined2 local_14;
  undefined2 local_12;
  undefined *local_10;
  
  iVar1 = DAT_00009940;
  FUN_00021b3c(DAT_00009940,1);
  if (param_1 == 0) {
    return;
  }
  local_1c = 0xffff;
  local_1a = 0;
  local_18 = 0;
  local_16 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 100;
  *(undefined2 *)(iVar1 + 0xe) = 0xd2;
  *(undefined2 *)(iVar1 + 4) = 0x15;
  local_12 = 0x15;
  if (param_1 < 1) {
    if (param_1 == -1) {
      local_10 = &DAT_00009950;
    }
    else if (param_1 == -2) {
      local_10 = &DAT_00009954;
    }
    else if (param_1 == -3) {
      local_10 = &DAT_00009958;
    }
    local_14 = 0x24;
  }
  else {
    if (param_1 == 3) {
      local_10 = &DAT_00009944;
    }
    else if (param_1 == 2) {
      local_10 = &DAT_00009948;
    }
    else if (param_1 == 1) {
      local_10 = &DAT_0000994c;
    }
    local_14 = 0x18;
  }
  *(undefined2 *)(iVar1 + 2) = local_14;
  seed_21c2c(iVar1,&local_1c);
  return;
}


