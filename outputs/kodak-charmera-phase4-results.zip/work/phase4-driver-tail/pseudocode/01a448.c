/* Ghidra inferred pseudocode; file offset=0x01a448 */

undefined4 FUN_0001a248(byte *param_1,byte *param_2,undefined4 param_3,undefined4 param_4)

{
  byte bVar1;
  short sVar2;
  undefined1 *puVar3;
  byte *pbVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined8 uVar9;
  undefined1 local_38 [4];
  ushort local_34 [7];
  ushort local_26;
  
  pbVar4 = DAT_0001a548;
  puVar3 = DAT_0001a540;
  sVar2 = *(short *)(DAT_0001a548 + 4);
  if (sVar2 == 0x55aa) {
    return 0x55aa;
  }
  if (*(short *)(DAT_0001a540 + 0x12) == 4) {
    bVar1 = *param_1;
    iVar6 = DAT_0001a554;
  }
  else {
    bVar1 = *param_1;
    if (*(short *)(DAT_0001a540 + 0x12) != 3) {
      local_26 = (ushort)bVar1 + (ushort)*DAT_0001a548;
      goto LAB_0001a2a8;
    }
    iVar6 = DAT_0001a558;
  }
  local_26 = (ushort)*(byte *)(iVar6 + (uint)bVar1);
LAB_0001a2a8:
  if (*param_2 == 0xff) {
    *DAT_0001a540 = 1;
    FUN_00019f14(param_3,param_4,param_1,0);
    iVar6 = FUN_00019258(local_34,1,0);
    piVar5 = DAT_0001a55c;
    *param_2 = (byte)iVar6;
    if (*piVar5 != 0x10d || iVar6 != 0xff) {
      return 0;
    }
  }
  else {
    *DAT_0001a540 = 0;
    local_34[0] = (ushort)*param_2;
    if (sVar2 == 0x31 || sVar2 == 0x30) {
      uVar7 = FUN_00019258(local_34,4,param_2);
      *param_2 = 0;
      return uVar7;
    }
    FUN_00019258(local_34,2,param_2);
    sVar2 = *(short *)(pbVar4 + 4);
    if (sVar2 == 0xf) {
      puVar3[8] = 2;
      FUN_00019f14(param_3,param_4,param_1,0);
      return 0;
    }
    if (sVar2 == 0x42) {
      pbVar4[4] = 0;
      pbVar4[5] = 0;
    }
    else {
      if (sVar2 == 0x55aa) {
        FUN_00019f14(param_3,param_4,param_1,0);
        local_38[0] = 0;
        FUN_00025984(*DAT_0001a564,DAT_0001a560,local_38,1,0);
        FUN_00008bb0();
        uVar9 = FUN_00021e94();
        if ((int)uVar9 == 0xff) {
          puVar8 = DAT_0001a56c;
          uVar7 = DAT_0001a568;
        }
        else {
          FUN_000191a4((int)uVar9,(int)((ulonglong)uVar9 >> 0x20));
          puVar8 = DAT_0001a574;
          uVar7 = DAT_0001a570;
        }
        uVar7 = FUN_00025984(*puVar8,uVar7);
        *param_2 = 0xff;
        return uVar7;
      }
      if (sVar2 == -0x55ab) {
        *(short *)(pbVar4 + 4) = (short)DAT_00019f0c;
      }
    }
    *param_2 = 0xff;
  }
  FUN_000178e8(param_3,param_4,param_1);
  return 0;
}


