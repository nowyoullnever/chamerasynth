/* Ghidra inferred pseudocode; file offset=0x01ac38 */

void FUN_0001aa38(byte *param_1,byte *param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  byte bVar1;
  undefined4 uVar2;
  int iVar3;
  ushort local_20 [7];
  ushort local_12;
  
  if (*(short *)(DAT_0001a548 + 4) != 0xf) {
    return;
  }
  if (*(short *)(DAT_0001a540 + 0x12) == 4) {
    bVar1 = *param_1;
    iVar3 = DAT_0001a554;
  }
  else {
    bVar1 = *param_1;
    if (*(short *)(DAT_0001a540 + 0x12) != 3) {
      local_12 = (ushort)bVar1 + (ushort)*DAT_0001a548;
      goto LAB_0001aa94;
    }
    iVar3 = DAT_0001a558;
  }
  local_12 = (ushort)*(byte *)(iVar3 + (uint)bVar1);
LAB_0001aa94:
  local_20[0] = (ushort)*param_2;
  FUN_00019f14(param_4,param_5,param_1,0);
  if (param_3 == 0x7004) {
    uVar2 = 5;
  }
  else {
    if (param_3 != 0x7005) {
      return;
    }
    uVar2 = 6;
  }
  FUN_00019258(local_20,uVar2);
  return;
}


