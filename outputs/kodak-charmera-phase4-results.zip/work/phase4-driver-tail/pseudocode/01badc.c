/* Ghidra inferred pseudocode; file offset=0x01badc */

undefined8 FUN_0001b8dc(undefined4 param_1,undefined4 param_2,undefined2 param_3)

{
  int iVar1;
  short sVar2;
  undefined2 local_18;
  undefined2 local_16;
  undefined2 local_14;
  undefined2 local_12;
  short local_10;
  undefined2 local_e;
  undefined *local_c;
  
  iVar1 = DAT_0001b94c;
  local_18 = 0x1f;
  local_16 = 0;
  local_14 = 0;
  local_12 = 0;
  local_c = &DAT_0001b948;
  *(undefined2 *)(DAT_0001b94c + 4) = 0x15;
  local_e = 0x15;
  local_10 = param_3;
  sVar2 = FUN_00000298(&DAT_0001b948);
  *(short *)(iVar1 + 2) = sVar2 * 0xc;
  _local_10 = CONCAT22(local_e,sVar2 * 0xc);
  *(undefined2 *)(iVar1 + 0xc) = 0xa0;
  *(undefined2 *)(iVar1 + 0xe) = 2;
  seed_21c2c(iVar1,&local_18);
  return CONCAT26(local_12,CONCAT24(local_14,CONCAT22(local_16,local_18)));
}


