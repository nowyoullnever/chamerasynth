/* Ghidra inferred pseudocode; file offset=0x01bb68 */

void FUN_0001b968(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined2 local_1c;
  undefined2 local_1a;
  undefined2 local_18;
  undefined2 local_16;
  undefined2 local_14;
  undefined2 local_12;
  undefined *local_10;
  
  iVar2 = FUN_000f0d98();
  iVar3 = FUN_000f0dd4();
  iVar1 = DAT_0001ba64;
  if (param_1 == 10) {
    local_10 = &DAT_0001ba68;
  }
  else if (param_1 == 9) {
    local_10 = &DAT_0001ba6c;
  }
  else if (param_1 == 8) {
    local_10 = &DAT_0001ba70;
  }
  else if (param_1 == 7) {
    local_10 = &DAT_0001ba74;
  }
  else if (param_1 == 6) {
    local_10 = &DAT_0001ba78;
  }
  else if (param_1 == 5) {
    local_10 = &DAT_0001ba7c;
  }
  else if (param_1 == 4) {
    local_10 = &DAT_0001ba80;
  }
  else if (param_1 == 3) {
    local_10 = &DAT_0001ba84;
  }
  else if (param_1 == 2) {
    local_10 = &DAT_0001ba88;
  }
  else if (param_1 == 1) {
    local_10 = &LAB_0001ba8c;
  }
  local_1c = 0xf800;
  local_1a = 0;
  local_18 = 0;
  local_16 = 0;
  local_14 = 0x18;
  local_12 = 0x2a;
  *(undefined2 *)(DAT_0001ba64 + 2) = 0x18;
  *(undefined2 *)(iVar1 + 4) = 0x2a;
  *(short *)(iVar1 + 0xc) = (short)(iVar2 + -0xc >> 1);
  *(short *)(iVar1 + 0xe) = (short)(iVar3 + -0x15 >> 1);
  seed_21c2c(iVar1,&local_1c);
  return;
}


