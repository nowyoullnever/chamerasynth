/* Ghidra inferred pseudocode; file offset=0x01d580 */

void FUN_0001d380(void)

{
  int iVar1;
  short sVar2;
  short sVar3;
  ushort uVar4;
  uint uVar5;
  undefined2 local_38;
  undefined2 local_36;
  undefined2 local_34;
  undefined2 local_32;
  ushort local_30;
  undefined2 local_2e;
  undefined4 local_2c;
  undefined4 auStack_28 [8];
  
  FUN_000db4a8(auStack_28,DAT_0001d444,0x20);
  sVar2 = FUN_000f0d98();
  FUN_000f0dd4();
  uVar5 = FUN_0001f2f0();
  if (7 < uVar5) {
    uVar5 = 7;
  }
  local_2c = auStack_28[uVar5];
  local_38 = 0xffff;
  local_36 = 0;
  local_34 = 0;
  local_32 = 0;
  sVar3 = FUN_00000298();
  iVar1 = DAT_0001d130;
  local_30 = sVar3 * 0xc + 2;
  local_2e = 0x17;
  uVar4 = sVar2 - 10;
  if (local_30 <= uVar4) {
    uVar4 = uVar4 - local_30;
  }
  *(ushort *)(DAT_0001d130 + 2) = local_30;
  *(undefined2 *)(iVar1 + 4) = 0x17;
  *(ushort *)(iVar1 + 0xc) = uVar4 & 0xfffe;
  *(undefined2 *)(iVar1 + 0xe) = 0x24;
  seed_21c2c(iVar1,&local_38);
  return;
}


