/* Ghidra inferred pseudocode; file offset=0x01e434 */

void FUN_0001e234(void)

{
  int iVar1;
  undefined2 uVar2;
  
  uVar2 = FUN_00001310(s_CLICK_WAV_0001e294);
  iVar1 = DAT_0001e290;
  *(undefined2 *)(DAT_0001e290 + 4) = uVar2;
  uVar2 = FUN_00001310(s_POWERON_AUDIO_WAV_0001e2a0);
  *(undefined2 *)(iVar1 + 6) = uVar2;
  uVar2 = FUN_00001310(s_POWEROFF_AUDIO_WAV_0001e2b4);
  *(undefined2 *)(iVar1 + 8) = uVar2;
  uVar2 = FUN_00001310(s_BEEP_WAV_0001e2c8);
  *(undefined2 *)(iVar1 + 0xc) = uVar2;
  uVar2 = FUN_00001310(s_IMG_WAV_0001e2d4);
  *(undefined2 *)(iVar1 + 0xe) = uVar2;
  return;
}


