/* Ghidra inferred pseudocode; file offset=0x021f20 */

/* WARNING: Removing unreachable block (ram,0x00021bd0) */
/* WARNING: Removing unreachable block (ram,0x00021be0) */

void FUN_00021d20(int param_1)

{
  undefined1 *puVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  do {
    FUN_00021c14(1,2,0);
    FUN_00021c14(3,4,0xe);
    FUN_00021c14(10,0xb,0xc);
    FUN_00021c14(0xd,0,0);
    puVar1 = DAT_00021fcc;
    if (param_1 != 0) {
      *DAT_00021fcc = 1;
      if (*(short *)(puVar1 + 0x1a) == 0x10a) {
        uVar3 = 0xe;
      }
      else {
        uVar3 = 5;
      }
FUN_00021ba0:
      if ((0x1c < uVar3) && (uVar3 < 0x25)) {
        uVar2 = (uint)*(ushort *)(DAT_00021fcc + 0x1a);
        iVar5 = 0;
        if (uVar2 != 0x102) {
          iVar5 = uVar2 - 0x100;
        }
        if (uVar2 != 0x102 && iVar5 != 1) {
          return;
        }
      }
      FUN_0008f67c(*DAT_00021a18,uVar3 | 0x6000000);
      return;
    }
    *DAT_00021fcc = 0;
    FUN_00021c14(5,0xe,0);
    iVar4 = 0;
    FUN_00021c14(1,2,0);
    FUN_00021c14(3,4,0xe);
    FUN_00021c14(10,0xb,0xc);
    FUN_00021c14(0xd,0,0);
    iVar5 = FUN_00006d5c();
    if (iVar5 == 0) {
      if (*(short *)(DAT_00021fcc + 0x1a) == 0x10a) {
        iVar4 = 8;
      }
      uVar3 = (uint)*DAT_00021fdc + iVar4 + 1 & 0xff;
      goto FUN_00021ba0;
    }
    param_1 = 1;
  } while( true );
}


