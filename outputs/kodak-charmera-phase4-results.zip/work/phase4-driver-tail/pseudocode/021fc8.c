/* Ghidra inferred pseudocode; file offset=0x021fc8 */

/* WARNING: Removing unreachable block (ram,0x00021bd0) */
/* WARNING: Removing unreachable block (ram,0x00021da0) */
/* WARNING: Removing unreachable block (ram,0x00021be0) */

void FUN_00021dc8(void)

{
  undefined1 *puVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  
  iVar5 = 0;
  FUN_00021c14(1,2,0);
  FUN_00021c14(3,4,0xe);
  FUN_00021c14(10,0xb,0xc);
  FUN_00021c14(0xd,0,0);
  iVar3 = FUN_00006d5c();
  if (iVar3 == 0) {
    if (*(short *)(DAT_00021fcc + 0x1a) == 0x10a) {
      iVar5 = 8;
    }
    uVar4 = (uint)*DAT_00021fdc + iVar5 + 1 & 0xff;
  }
  else {
    FUN_00021c14(1,2,0);
    FUN_00021c14(3,4,0xe);
    FUN_00021c14(10,0xb,0xc);
    FUN_00021c14(0xd,0,0);
    puVar1 = DAT_00021fcc;
    *DAT_00021fcc = 1;
    if (*(short *)(puVar1 + 0x1a) == 0x10a) {
      uVar4 = 0xe;
    }
    else {
      uVar4 = 5;
    }
  }
  if ((0x1c < uVar4) && (uVar4 < 0x25)) {
    uVar2 = (uint)*(ushort *)(DAT_00021fcc + 0x1a);
    iVar3 = 0;
    if (uVar2 != 0x102) {
      iVar3 = uVar2 - 0x100;
    }
    if (uVar2 != 0x102 && iVar3 != 1) {
      return;
    }
  }
  FUN_0008f67c(*DAT_00021a18,uVar4 | 0x6000000);
  return;
}


