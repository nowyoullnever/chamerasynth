/* Ghidra inferred pseudocode; file offset=0x0378ec */

undefined4 FUN_000376ec(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char *pcVar1;
  ushort uVar2;
  ushort uVar3;
  short sVar4;
  char *pcVar5;
  undefined4 *puVar6;
  char cVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  bool bVar11;
  bool bVar12;
  
  puVar6 = DAT_000372b4;
  iVar8 = DAT_000372b0;
  pcVar5 = DAT_000372a8;
  uVar2 = *(ushort *)(param_1 + 4);
  uVar3 = *(ushort *)(param_1 + 2) >> 8;
  if ((uVar2 & 0xff) != 0) {
    if ((uVar2 & 0xff) != 1) {
      cVar7 = -1;
      goto LAB_00037880;
    }
    if (uVar3 == 1 || uVar3 == 2) {
      FUN_000db4a8(DAT_000372b0,DAT_000372b8,0x1c,DAT_000372b8,param_4);
      *pcVar5 = '\0';
      cVar7 = *(char *)(iVar8 + 2);
      bVar11 = cVar7 == '\x01';
      if (bVar11) {
        cVar7 = *(char *)(iVar8 + 3);
      }
      bVar12 = bVar11 && cVar7 == '\x01';
      if (bVar11 && cVar7 == '\x01') {
        bVar12 = *(int *)(iVar8 + 4) == DAT_00037d40;
      }
      if (!bVar12) {
        *pcVar5 = '\x06';
      }
      FUN_000dba18(DAT_00037d44,iVar8 + 0x12);
      iVar8 = FUN_0008a550();
      if (iVar8 == 1) {
        uVar9 = 0x200;
      }
      else {
        uVar9 = 0x400;
      }
      FUN_000dba18(uVar9,DAT_00037d48);
      if (*pcVar5 == '\0') {
        return 1;
      }
      return 0;
    }
    if (uVar3 == 3 || uVar3 == 4) {
      uVar9 = DAT_000372b8[1];
      uVar10 = DAT_000372b8[2];
      *DAT_000372b4 = *DAT_000372b8;
      puVar6[1] = uVar9;
      puVar6[2] = uVar10;
      *(undefined1 *)((int)puVar6 + 2) = 0;
      *(undefined1 *)((int)puVar6 + 3) = 0;
      *(undefined1 *)(puVar6 + 1) = 0x20;
      *(undefined1 *)((int)puVar6 + 5) = 0x1c;
      *(undefined1 *)((int)puVar6 + 6) = 0;
      *(undefined1 *)((int)puVar6 + 7) = 0x40;
      *(undefined1 *)(puVar6 + 2) = 0;
      *(undefined1 *)((int)puVar6 + 9) = 0;
      *(undefined1 *)((int)puVar6 + 10) = 0;
      goto LAB_0003786c;
    }
    goto LAB_000378f8;
  }
  switch(uVar2 >> 8) {
  case 0:
    if (uVar3 == 1) {
      *DAT_000372bc = *(undefined1 *)DAT_000372b8;
      goto LAB_0003786c;
    }
    break;
  case 1:
    break;
  case 2:
    break;
  case 3:
    break;
  case 4:
    if (uVar3 == 1) {
      *DAT_000372c8 = *(undefined1 *)DAT_000372b8;
    }
    else if (uVar3 == 2) {
      pcVar1 = DAT_000372a8 + 0x68;
      *(undefined4 *)(DAT_000372a8 + 0x20) = *(undefined4 *)(DAT_000372a8 + 100);
      *(undefined4 *)(pcVar5 + 0x24) = *(undefined4 *)pcVar1;
    }
    else {
      if (uVar3 != 3) break;
      *(undefined4 *)(DAT_000372a8 + 4) = *(undefined4 *)(DAT_000372a8 + 100);
    }
    goto LAB_0003786c;
  case 5:
    sVar4 = CONCAT11(*(undefined1 *)DAT_000372b8,*(undefined1 *)((int)DAT_000372b8 + 1));
    if (uVar3 == 2) {
      if ((sVar4 < *(short *)(DAT_000372bc + 6)) || (*(short *)(DAT_000372bc + 8) < sVar4)) {
LAB_00037874:
        *DAT_000372a8 = '\x04';
        return 0;
      }
      *(short *)(DAT_000372bc + 2) = sVar4;
    }
    else {
      if (uVar3 != 3) break;
      if ((sVar4 < *(short *)(DAT_000372bc + 0x10)) || (*(short *)(DAT_000372bc + 0x12) < sVar4))
      goto LAB_00037874;
      *(short *)(DAT_000372bc + 0xc) = sVar4;
    }
LAB_0003786c:
    *pcVar5 = '\0';
    return 1;
  default:
    cVar7 = '\x05';
LAB_00037880:
    *DAT_000372a8 = cVar7;
    return 0;
  }
LAB_000378f8:
  *DAT_000372a8 = '\x06';
  return 0;
}


