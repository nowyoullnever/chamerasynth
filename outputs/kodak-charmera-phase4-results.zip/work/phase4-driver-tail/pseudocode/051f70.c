/* Ghidra inferred pseudocode; file offset=0x051f70 */

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_00051d70(void)

{
  char cVar1;
  ushort uVar2;
  bool bVar3;
  uint *puVar4;
  uint uVar5;
  int *piVar6;
  char *pcVar7;
  byte bVar8;
  char *pcVar9;
  uint uVar10;
  byte bVar11;
  undefined1 uVar12;
  int iVar13;
  uint uVar14;
  int iVar15;
  int iVar16;
  int iVar17;
  int iVar18;
  undefined4 uVar19;
  code *UNRECOVERED_JUMPTABLE;
  bool bVar20;
  
  FUN_00051c88();
  bVar8 = *(char *)(DAT_00051d50 + 1) + 1;
  *(byte *)(DAT_00051d50 + 1) = bVar8;
  pcVar7 = DAT_00050824;
  piVar6 = DAT_00050648;
  if ((bVar8 & 1) == 0) {
    return;
  }
  *(int *)(DAT_00050824 + 4) = *(int *)(DAT_00050824 + 4) + 1;
  uVar5 = DAT_00050644;
  puVar4 = DAT_00050640;
  pcVar7[2] = pcVar7[2] + '\x01';
LAB_00050730:
  do {
    iVar13 = *(int *)(pcVar7 + 0x10);
    iVar15 = 0;
LAB_00051020:
    while( true ) {
      iVar17 = iVar13;
      iVar13 = DAT_00051178;
      if (iVar17 == 0) {
        iVar18 = DAT_00051178 + 4;
        iVar15 = 0;
        iVar17 = *(int *)(pcVar7 + 0x14);
        while (iVar17 != 0) {
          if (*(char *)(iVar17 + 0x18) != '\v') {
            switchD_000be904::default
                      (DAT_00051120,s_tcp_slowtmr__TIME_WAIT_pcb_>stat_00051180,DAT_0005117c,
                       DAT_000510f0);
            FUN_000abfd8();
          }
          if ((uint)(*(int *)(pcVar7 + 4) - *(int *)(iVar17 + 0x24)) < 0xf1) {
            iVar15 = iVar17;
            iVar17 = *(int *)(iVar17 + 0xc);
          }
          else {
            FUN_00050510(iVar17);
            if (iVar15 == 0) {
              if (*(int *)(pcVar7 + 0x14) != iVar17) {
                switchD_000be904::default
                          (DAT_00051120,s_tcp_slowtmr__first_pcb____tcp_tw_00051220,iVar18,
                           DAT_000510f0);
                FUN_000abfd8();
              }
              *(undefined4 *)(pcVar7 + 0x14) = *(undefined4 *)(iVar17 + 0xc);
            }
            else {
              if (iVar17 == *(int *)(pcVar7 + 0x14)) {
                switchD_000be904::default
                          (DAT_00051120,s_tcp_slowtmr__middle_tcp____tcp_t_000511b0,iVar13,
                           DAT_000510f0);
                FUN_000abfd8();
              }
              *(undefined4 *)(iVar15 + 0xc) = *(undefined4 *)(iVar17 + 0xc);
            }
            iVar16 = *(int *)(iVar17 + 0xc);
            FUN_0004e9f8(2,iVar17);
            iVar17 = iVar16;
          }
        }
                    /* WARNING: Could not recover jumptable at 0x0005121c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE)();
        return;
      }
      if (((*puVar4 & uVar5) != 0) && (*piVar6 * 0x10000 < 1)) {
        switchD_000be904::default(s_tcp_slowtmr__processing_active_p_00050828);
      }
      if (*(char *)(iVar17 + 0x18) == '\0') {
        switchD_000be904::default
                  (s_Assertion___s__failed_at_line__d_000508b8,
                   s_tcp_slowtmr__active_pcb_>state___0005088c,0x374);
        FUN_000abfd8();
      }
      if (*(char *)(iVar17 + 0x18) == '\x01') {
        switchD_000be904::default
                  (s_Assertion___s__failed_at_line__d_000508b8,
                   s_tcp_slowtmr__active_pcb_>state___000508e8,DAT_000508e4);
        FUN_000abfd8();
      }
      if (*(char *)(iVar17 + 0x18) == '\v') {
        switchD_000be904::default
                  (s_Assertion___s__failed_at_line__d_000508b8,
                   s_tcp_slowtmr__active_pcb_>state___00050918,DAT_00050914);
        FUN_000abfd8();
      }
      if (*(char *)(iVar17 + 0x21) != pcVar7[2]) break;
      iVar13 = *(int *)(iVar17 + 0xc);
    }
    *(char *)(iVar17 + 0x21) = pcVar7[2];
    iVar13 = DAT_00050d68;
    cVar1 = *(char *)(iVar17 + 0x18);
    iVar18 = 0;
    bVar3 = false;
    bVar20 = cVar1 != '\x02';
    if (!bVar20) {
      cVar1 = *(char *)(iVar17 + 0x4a);
    }
    if (bVar20 || cVar1 != '\x04') {
      if (*(char *)(iVar17 + 0x4a) == '\f') {
        iVar18 = 1;
        if (((*puVar4 & uVar5) != 0) && (*piVar6 * 0x10000 < 1)) {
          pcVar9 = s_tcp_slowtmr__max_DATA_retries_re_00050d40;
          goto LAB_000509a0;
        }
      }
      else {
        bVar8 = *(byte *)(iVar17 + 0xa1);
        uVar10 = (uint)bVar8;
        if (uVar10 == 0) {
          if (-1 < *(short *)(iVar17 + 0x34)) {
            iVar13 = (*(short *)(iVar17 + 0x34) + 1) * 0x10000;
            iVar16 = iVar13 >> 0x10;
            *(short *)(iVar17 + 0x34) = (short)((uint)iVar13 >> 0x10);
            if ((*(int *)(iVar17 + 0x74) != 0) && ((int)*(short *)(iVar17 + 0x48) <= iVar16 * 500))
            {
              if (((*puVar4 & DAT_00050d6c) != 0) && (*piVar6 * 0x10000 < 0x10001)) {
                switchD_000be904::default(s_tcp_slowtmr__rtime__hd_pcb_>rto___00050d70,iVar16 * 500)
                ;
              }
              if (*(char *)(iVar17 + 0x18) != '\x02') {
                *(short *)(iVar17 + 0x48) =
                     (short)((int)*(short *)(iVar17 + 0x46) + ((int)*(short *)(iVar17 + 0x44) >> 3)
                            << *(sbyte *)(DAT_00050d98 + (uint)*(byte *)(iVar17 + 0x4a)));
              }
              *(undefined2 *)(iVar17 + 0x34) = 0;
              uVar10 = (uint)*(ushort *)(iVar17 + 0x50);
              if ((uint)*(ushort *)(iVar17 + 100) <= (uint)*(ushort *)(iVar17 + 0x50)) {
                uVar10 = (uint)*(ushort *)(iVar17 + 100);
              }
              *(short *)(iVar17 + 0x52) = (short)(uVar10 >> 1);
              uVar2 = *(ushort *)(iVar17 + 0x36);
              if (uVar10 >> 1 < (uint)uVar2 << 1) {
                *(ushort *)(iVar17 + 0x52) = uVar2 << 1;
              }
              *(ushort *)(iVar17 + 0x50) = uVar2;
              if (((*puVar4 & uVar5) != 0) && (*piVar6 * 0x10000 < 1)) {
                switchD_000be904::default(s_tcp_slowtmr__cwnd__hu_ssthresh___00050d9c);
              }
              FUN_00058e24(iVar17);
            }
          }
        }
        else {
          bVar11 = *(char *)(iVar17 + 0xa0) + 1;
          *(byte *)(iVar17 + 0xa0) = bVar11;
          if (*(byte *)(uVar10 + iVar13 + -1) <= bVar11) {
            if (uVar10 < 7) {
              bVar8 = bVar8 + 1;
            }
            *(undefined1 *)(iVar17 + 0xa0) = 0;
            if (uVar10 < 7) {
              *(byte *)(iVar17 + 0xa1) = bVar8;
            }
            FUN_00059384(iVar17);
          }
        }
      }
LAB_00050af4:
      if (*(char *)(iVar17 + 0x18) == '\a') {
        uVar10 = *(byte *)(iVar17 + 0x1e) & 0x10;
        bVar20 = (*(byte *)(iVar17 + 0x1e) & 0x10) != 0;
        if (bVar20) {
          uVar10 = *(int *)(pcVar7 + 4) - *(int *)(iVar17 + 0x24);
        }
        if (((bVar20 && 0x28 < uVar10) && (iVar18 = iVar18 + 1, (*puVar4 & uVar5) != 0)) &&
           (*piVar6 * 0x10000 < 1)) {
          switchD_000be904::default(s_tcp_slowtmr__removing_pcb_stuck_i_00050dc4);
        }
      }
    }
    else {
      iVar18 = 1;
      if (((*puVar4 & uVar5) != 0) && (*piVar6 * 0x10000 < 1)) {
        pcVar9 = s_tcp_slowtmr__max_SYN_retries_rea_00050948;
LAB_000509a0:
        iVar18 = 1;
        switchD_000be904::default(pcVar9);
        goto LAB_00050af4;
      }
    }
    if (((*(byte *)(iVar17 + 8) & 8) != 0) &&
       (*(char *)(iVar17 + 0x18) == '\x05' || *(char *)(iVar17 + 0x18) == '\b')) {
      iVar13 = *(int *)(iVar17 + 0x94);
      iVar16 = *(int *)(iVar17 + 0x98);
      uVar10 = FUN_000db608(500,iVar16 * *(int *)(iVar17 + 0x9c) + iVar13);
      uVar14 = *(int *)(pcVar7 + 4) - *(int *)(iVar17 + 0x24);
      if (uVar10 < uVar14) {
        if ((((*puVar4 & uVar5) != 0) && (*piVar6 * 0x10000 < 1)) &&
           ((switchD_000be904::default(s_tcp_slowtmr__KEEPALIVE_timeout__A_00050df4),
            (*puVar4 & uVar5) != 0 && (*piVar6 * 0x10000 < 1)))) {
          if (iVar17 == -4) {
            uVar12 = 0;
          }
          else {
            uVar12 = *(undefined1 *)(iVar17 + 4);
          }
          switchD_000be904::default(s__hu__hu__hu__hu_00050e2c,uVar12);
          if (((*puVar4 & uVar5) != 0) && (*piVar6 * 0x10000 < 1)) {
            switchD_000be904::default(s_tcp_slowtmr__active_pcb_>state___0005088c + 0x28);
          }
        }
        iVar18 = iVar18 + 1;
        bVar3 = true;
      }
      else {
        uVar10 = FUN_000db608(500,iVar16 * (uint)*(byte *)(iVar17 + 0xa2) + iVar13);
        if (uVar10 < uVar14) {
          FUN_00059110(iVar17);
          *(char *)(iVar17 + 0xa2) = *(char *)(iVar17 + 0xa2) + '\x01';
        }
      }
    }
    if ((*(int *)(iVar17 + 0x78) != 0) &&
       ((uint)(*(short *)(iVar17 + 0x48) * 6) <=
        (uint)(*(int *)(pcVar7 + 4) - *(int *)(iVar17 + 0x24)))) {
      FUN_000504f0();
      *(undefined4 *)(iVar17 + 0x78) = 0;
      if (((*puVar4 & uVar5) != 0) && (*piVar6 * 0x10000 < 1)) {
        switchD_000be904::default(s_tcp_slowtmr__dropping_OOSEQ_queu_00050e3c);
      }
    }
    if (*(char *)(iVar17 + 0x18) == '\x04') {
      if (((0x28 < (uint)(*(int *)(pcVar7 + 4) - *(int *)(iVar17 + 0x24))) &&
          (iVar18 = iVar18 + 1, (*puVar4 & uVar5) != 0)) && (*piVar6 * 0x10000 < 1)) {
        switchD_000be904::default(s_tcp_slowtmr__removing_pcb_stuck_i_00050e68);
        goto LAB_00050d14;
      }
    }
    else {
LAB_00050d14:
      if (((*(char *)(iVar17 + 0x18) == '\n') &&
          (0xf0 < (uint)(*(int *)(pcVar7 + 4) - *(int *)(iVar17 + 0x24)))) &&
         ((iVar18 = iVar18 + 1, (*puVar4 & uVar5) != 0 && (*piVar6 * 0x10000 < 1)))) {
        switchD_000be904::default(s_tcp_slowtmr__removing_pcb_stuck_i_000510c0);
      }
    }
    if (iVar18 == 0) {
      iVar13 = *(int *)(iVar17 + 0xc);
      bVar8 = *(char *)(iVar17 + 0x1f) + 1;
      *(byte *)(iVar17 + 0x1f) = bVar8;
      iVar15 = iVar17;
      if (bVar8 < *(byte *)(iVar17 + 0x20)) goto LAB_00051020;
      *(undefined1 *)(iVar17 + 0x1f) = 0;
      if (((*puVar4 & uVar5) != 0) && (*piVar6 * 0x10000 < 1)) {
        switchD_000be904::default(s_tcp_slowtmr__polling_application_00051154);
      }
      *pcVar7 = '\0';
      if (*(uint *)(iVar17 + 0x8c) != 0) {
        iVar18 = (*(code *)(*(uint *)(iVar17 + 0x8c) & 0xfffffffc))
                           (*(undefined4 *)(iVar17 + 0x10),iVar17);
        if (*pcVar7 != '\0') goto LAB_00050730;
        if (iVar18 != 0) goto LAB_00051020;
      }
      FUN_000586cc(iVar17);
      goto LAB_00051020;
    }
    FUN_00050510(iVar17);
    if (iVar15 == 0) {
      if (*(int *)(pcVar7 + 0x10) != iVar17) {
        switchD_000be904::default
                  (DAT_00051120,s_tcp_slowtmr__first_pcb____tcp_ac_00051128,DAT_00051124);
        FUN_000abfd8();
      }
      *(undefined4 *)(pcVar7 + 0x10) = *(undefined4 *)(iVar17 + 0xc);
    }
    else {
      if (iVar17 == *(int *)(pcVar7 + 0x10)) {
        switchD_000be904::default(DAT_00051120,s_tcp_slowtmr__middle_tcp____tcp_a_000510f4,0x410);
        FUN_000abfd8();
      }
      *(undefined4 *)(iVar15 + 0xc) = *(undefined4 *)(iVar17 + 0xc);
    }
    if (bVar3) {
      FUN_00058c08(*(undefined4 *)(iVar17 + 0x54),*(undefined4 *)(iVar17 + 0x28),iVar17);
    }
    uVar10 = *(uint *)(iVar17 + 0x90);
    uVar19 = *(undefined4 *)(iVar17 + 0x10);
    iVar13 = *(int *)(iVar17 + 0xc);
    FUN_0004e9f8(2,iVar17);
    *pcVar7 = '\0';
    if ((uVar10 == 0) || ((*(code *)(uVar10 & 0xfffffffc))(uVar19,0xfffffff6), *pcVar7 == '\0'))
    goto LAB_00051020;
  } while( true );
}


