/* Ghidra inferred pseudocode; file offset=0x052594 */

void FUN_00052394(void)

{
  *(int *)(DAT_00052178 + 4) = *(int *)(DAT_00052178 + 4) + *(int *)(DAT_00051d50 + 4);
  return;
}


