/* Ghidra inferred pseudocode; file offset=0x05fd5c */

undefined8 FUN_0005fb5c(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char *pcVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  undefined4 uStack_28;
  
  iVar3 = DAT_0005fe98;
  pcVar1 = DAT_0005fe94;
  piVar4 = (int *)(DAT_0005fe88 + param_1 * 0x30);
  iVar5 = DAT_0005fe8c + param_1 * 0x48;
  if (*DAT_0005fe94 == '\0') {
    uStack_28 = param_4;
    if (*(int *)(DAT_0005fe98 + param_1 * 4) == 0) {
      uVar2 = FUN_0008f9e4(1);
      *(undefined4 *)(iVar3 + param_1 * 4) = uVar2;
    }
    FUN_000db394(piVar4,0x30);
    FUN_000db394(iVar5,0x1c);
    FUN_000db394(iVar5 + 0x1c,0x20);
    *piVar4 = param_1;
    FUN_0002b2a4(param_1);
    FUN_0002b334(param_1);
    FUN_0002b61c(param_1);
    param_2 = 0;
    iVar3 = FUN_0005f5b0(param_1,0,0,0,0,0);
    if (-1 < iVar3) {
      FUN_000323f0(1);
      uVar6 = 0;
      do {
        param_2 = 0;
        iVar3 = FUN_0005f5b0(param_1,5,0,4,0,0);
        if (iVar3 < 0) goto LAB_0005fe58;
        if (*(int *)(iVar5 + 8) != 0) break;
        FUN_000323f0(1);
        uVar6 = uVar6 + 1;
      } while (uVar6 < 200);
      if ((*(uint *)(iVar5 + 8) & 0x1c0000) != 0) {
        FUN_000323f0(1);
        uVar6 = 0;
        do {
          param_2 = 0;
          iVar3 = FUN_0005f5b0(param_1,5,0x1c0000,4,0,0);
          if (iVar3 < 0) goto LAB_0005fe58;
          if ((*(uint *)(iVar5 + 8) & 0x80000000) != 0) goto LAB_0005fce4;
          FUN_000323f0(1);
          uVar6 = uVar6 + 1;
        } while (uVar6 < 200);
        if ((*(uint *)(iVar5 + 8) & 0x80000000) != 0) {
LAB_0005fce4:
          FUN_000323f0(1);
          param_2 = 0;
          iVar3 = FUN_0005f5b0(param_1,3,0,6,0,0);
          if (-1 < iVar3) {
            uVar6 = *(uint *)(iVar5 + 8) & 0xffff0000;
            piVar4[1] = uVar6;
            param_2 = 0;
            iVar3 = FUN_0005f5b0(param_1,7,uVar6,8,0,0);
            if (-1 < iVar3) {
              piVar4[2] = 1;
              FUN_000323f0(1);
              iVar3 = FUN_0005f878(piVar4);
              if (-1 < iVar3) {
                FUN_000323f0(1);
                iVar3 = FUN_000605b8(piVar4);
                if (-1 < iVar3) {
                  FUN_000323f0(1);
                  iVar3 = FUN_0005f9bc(piVar4);
                  if (iVar3 != 0) {
                    FUN_0002b4ec(param_1,piVar4[8]);
                  }
                  FUN_000323f0(2);
                  param_2 = 0;
                  iVar3 = FUN_0005f5ec(piVar4,0,0,7,0,&uStack_28);
                  if (-1 < iVar3) {
                    iVar3 = FUN_0002c464(param_1);
                    if (iVar3 == 1) {
                      FUN_00035e4c();
                      FUN_00035dec();
                      FUN_0002b590(param_1,1);
                      FUN_000323f0(2);
                      FUN_0002c414(param_1,param_1,param_1,DAT_0005fe9c);
                    }
                    else {
                      iVar3 = FUN_0005fa38(piVar4);
                      if (iVar3 < 0) goto LAB_0005fe58;
                    }
                    if (*(int *)(DAT_0005fe90 + param_1 * 4) != 0) {
                      if (param_1 == 0) {
                        uVar2 = 0x33;
                      }
                      else {
                        uVar2 = 0x2b;
                      }
                      FUN_00036124();
                      FUN_0003618c(uVar2);
                    }
                    *pcVar1 = '\x01';
                    goto LAB_0005fb94;
                  }
                }
              }
            }
          }
        }
      }
    }
LAB_0005fe58:
    FUN_0008f3d4(*(undefined4 *)(iVar5 + 0x44),1,&uStack_28);
    FUN_0008f3d4(*(undefined4 *)(iVar5 + 0x38),1,&uStack_28);
    piVar4[2] = 0;
    uVar2 = 0xffffffff;
  }
  else {
LAB_0005fb94:
    uVar2 = 0;
  }
  return CONCAT44(param_2,uVar2);
}


