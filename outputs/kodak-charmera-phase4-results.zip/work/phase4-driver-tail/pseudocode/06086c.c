/* Ghidra inferred pseudocode; file offset=0x06086c */

undefined4 FUN_0006066c(int *param_1,char *param_2,uint param_3)

{
  ushort *puVar1;
  uint uVar2;
  int iVar3;
  bool bVar4;
  
  uVar2 = 0;
  do {
    if (*(char *)(DAT_000606f0 + uVar2) == *param_2) {
      return 0xfffffffe;
    }
    bVar4 = 0xfffffffe < uVar2;
    uVar2 = uVar2 + 1;
  } while (bVar4);
  iVar3 = *(int *)(*param_1 + 0xc);
  if (iVar3 == 0) {
    uVar2 = 0x1c;
  }
  else {
    uVar2 = 0x2a;
  }
  bVar4 = param_3 == uVar2;
  if (uVar2 <= param_3) {
    bVar4 = *param_2 == '\x01';
  }
  if (bVar4) {
    puVar1 = (ushort *)(param_2 + 0xc);
    if (iVar3 == 0) {
      param_2 = "\b";
    }
    param_1[4] = (uint)*puVar1;
    if (iVar3 != 0) {
      param_2 = (char *)((uint)*(ushort *)(param_2 + 0x1c) * 10);
    }
    param_1[6] = (int)param_2;
    return 0;
  }
  return 0xffffffff;
}


