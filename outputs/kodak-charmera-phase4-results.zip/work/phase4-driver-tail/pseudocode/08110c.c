/* Ghidra inferred pseudocode; file offset=0x08110c */

undefined4 FUN_00080f0c(void)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  bool bVar6;
  
  iVar1 = FUN_0008282c();
  uVar4 = *(uint *)(iVar1 + 0xd4);
  uVar3 = *(uint *)(iVar1 + 0x11bc) & 0x70;
  uVar5 = *(uint *)(iVar1 + 0xdc);
  if ((*(uint *)(iVar1 + 0x11bc) & 8) != 0) {
    if (*(uint *)(iVar1 + 0xd4) < (uint)(*(int *)(iVar1 + 0x118c) + *(int *)(iVar1 + 0x1194))) {
      *(int *)(iVar1 + 0x1194) = *(int *)(iVar1 + 0xd4) - *(int *)(iVar1 + 0x118c);
    }
    if (*(uint *)(iVar1 + 0xdc) < (uint)(*(int *)(iVar1 + 0x1190) + *(int *)(iVar1 + 0x1198))) {
      *(int *)(iVar1 + 0x1198) = *(int *)(iVar1 + 0xdc) - *(int *)(iVar1 + 0x1190);
    }
    uVar4 = *(uint *)(iVar1 + 0x1194);
    uVar5 = *(uint *)(iVar1 + 0x1198);
  }
  uVar5 = uVar5 & 0xffff;
  uVar4 = uVar4 & 0xffff;
  if ((*(uint *)(iVar1 + 0x11bc) & 0x80) == 0) {
    uVar2 = *(uint *)(iVar1 + 0x11bc);
    if (((uVar2 & DAT_00081818) == 0) && (uVar3 != 0x10 && uVar3 != 0x50)) {
      if ((((((uVar3 == 0x20 || uVar3 == 0x120) || uVar3 == 0x220) || uVar3 == 0x30) ||
           uVar3 == 0x60) || uVar3 == 0x130) || uVar3 == 0x260) {
        uVar2 = uVar5 * uVar4;
      }
      if ((((((uVar3 == 0x20 || uVar3 == 0x120) || uVar3 == 0x220) || uVar3 == 0x30) ||
           uVar3 == 0x60) || uVar3 == 0x130) || uVar3 == 0x260) goto LAB_00080fc0;
      if (uVar3 == 0) {
        uVar2 = uVar5 * uVar4 * 3;
      }
      else {
        if (uVar3 != 0x40) goto LAB_00081070;
        uVar2 = uVar5 * uVar4;
      }
    }
    else {
LAB_00081070:
      uVar2 = uVar5 * uVar4 * 2;
    }
  }
  else {
    uVar2 = uVar5 * uVar4;
    if ((*(uint *)(iVar1 + 0x11cc) & 0x30000) != 0) {
      uVar3 = *(uint *)(iVar1 + 0x11cc);
      bVar6 = (uVar3 & 0x20000) != 0;
      if (bVar6) {
        uVar3 = *(uint *)(iVar1 + 0x11cc);
      }
      if (bVar6 && (uVar3 & 0x10000) != 0) {
        if (uVar4 == 0x780) {
          if (uVar5 == 0x440) {
            uVar2 = DAT_00081810;
            goto LAB_00081090;
          }
        }
        else if (uVar4 == 0x5a0 && uVar5 == 0x440) {
          uVar2 = DAT_00081814;
          goto LAB_00081090;
        }
        uVar2 = FUN_000db608(3,uVar2 * 2);
      }
      goto LAB_00081078;
    }
LAB_00080fc0:
    uVar2 = uVar2 + (uVar2 >> 1);
  }
LAB_00081078:
  if ((uVar2 == 0) || (0xfffffff < uVar2)) {
    return 0xffffffff;
  }
LAB_00081090:
  *(uint *)(iVar1 + 0x11d4) = uVar2;
  return 0;
}


