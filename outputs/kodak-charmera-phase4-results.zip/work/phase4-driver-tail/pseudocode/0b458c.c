/* Ghidra inferred pseudocode; file offset=0x0b458c */

int FUN_000b438c(int param_1,int param_2,int param_3)

{
  undefined1 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined *puVar4;
  char *unaff_r4;
  undefined *unaff_r6;
  int iVar5;
  
  if (param_3 == 1) {
    unaff_r6 = (undefined *)0xb44cc;
    unaff_r4 = s_VideoHandler_000b44d4;
  }
  iVar5 = 0x21;
  if (param_3 != 1) {
    if (param_3 == 2) {
      unaff_r6 = &DAT_000b44f8;
      unaff_r4 = s_SoundHandler_000b4500;
    }
    else {
      unaff_r6 = &DAT_000b44e4;
      unaff_r4 = s_DataHandler_000b44ec;
    }
  }
  if (*(int *)(param_1 + 0x528) == 2) {
    iVar5 = thunk_FUN_000db8b0(unaff_r4);
    iVar5 = iVar5 + 0x21;
  }
  iVar2 = FUN_000b75e8(param_2,iVar5,&DAT_000b4510,0,0);
  param_2 = param_2 + iVar2;
  if (*(int *)(param_1 + 0x528) == 2) {
    if (param_3 == 0) {
      puVar4 = &DAT_000b4518;
    }
    else {
      puVar4 = &DAT_000b4520;
    }
    FUN_000db3f0(param_2,puVar4,4);
  }
  else {
    FUN_000d0888(param_2,0,4);
  }
  FUN_000db3f0(param_2 + 4,unaff_r6,4);
  FUN_000d0888(param_2 + 8,0,4);
  FUN_000d0888(param_2 + 0xc,0,4);
  FUN_000d0888(param_2 + 0x10,0,4);
  if (*(int *)(param_1 + 0x528) == 2) {
    uVar1 = thunk_FUN_000db8b0(unaff_r4);
    *(undefined1 *)(param_2 + 0x14) = uVar1;
    uVar3 = thunk_FUN_000db8b0(unaff_r4);
    FUN_000db3f0(param_2 + 0x15,unaff_r4,uVar3);
    thunk_FUN_000db8b0(unaff_r4);
  }
  else {
    *(undefined1 *)(param_2 + 0x14) = 0;
  }
  return iVar5;
}


