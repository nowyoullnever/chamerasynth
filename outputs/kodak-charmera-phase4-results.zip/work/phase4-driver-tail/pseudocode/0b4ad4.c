/* Ghidra inferred pseudocode; file offset=0x0b4ad4 */

int FUN_000b48d4(char *param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined1 *puVar4;
  undefined *puVar5;
  char cVar6;
  int extraout_r1;
  undefined4 uVar7;
  int extraout_r1_00;
  undefined *puVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  undefined *puVar12;
  bool bVar13;
  bool bVar14;
  
  iVar10 = 0;
  if (param_3 != 1) {
    cVar6 = param_1[1];
    if (cVar6 == '\x11') {
      iVar10 = 0x45;
    }
    else if (cVar6 == '\x05') {
      if (*(int *)(param_1 + 0x528) == 2) {
        iVar10 = 99;
      }
      else {
        iVar10 = 0x5b;
      }
    }
    else if (cVar6 == '\x01') {
      if (*(int *)(param_1 + 0x528) == 2) {
        iVar10 = 0x3c;
      }
      else {
        iVar10 = 0x34;
      }
    }
    iVar1 = FUN_000b75e8(param_2,iVar10,&DAT_000b4c8c,0,0,param_4);
    param_2 = param_2 + iVar1;
    if (param_1[1] == '\x11') {
      FUN_000d0888(param_2,1,4);
      iVar1 = FUN_000b75bc(param_2 + 4,0x35,&DAT_000b5180);
      iVar1 = param_2 + 4 + iVar1;
      FUN_000d0888(iVar1,0,3);
      FUN_000d0888(iVar1 + 3,0,3);
      FUN_000d0888(iVar1 + 6,1,2);
      FUN_000d0888(iVar1 + 8,0,2);
      FUN_000d0888(iVar1 + 10,0,2);
      FUN_000d0888(iVar1 + 0xc,0,4);
      FUN_000d0888(iVar1 + 0x10,1,2);
      FUN_000d0888(iVar1 + 0x12,8,2);
      FUN_000d0888(iVar1 + 0x14,0,2);
      FUN_000d0888(iVar1 + 0x16,0,2);
      FUN_000d0888(iVar1 + 0x18,0x1f40000,4);
      param_2 = FUN_000b75bc(iVar1 + 0x1c,0x11,&DAT_000b5188);
      param_2 = iVar1 + 0x1c + param_2;
      FUN_000db3f0(param_2,&DAT_000b5178,4);
      *(undefined1 *)(param_2 + 4) = 0;
      FUN_000d0888(param_2 + 5,2,2);
      *(undefined1 *)(param_2 + 7) = 0;
      *(undefined1 *)(param_2 + 8) = 1;
      param_2 = param_2 + 9;
    }
    if (param_1[1] == '\x05') {
      FUN_000d0888(param_2,1,4);
      uVar7 = 0x4b;
      if (*(int *)(param_1 + 0x528) == 2) {
        uVar7 = 0x53;
      }
      iVar1 = FUN_000b75bc(param_2 + 4,uVar7,&DAT_000b5190);
      iVar1 = param_2 + 4 + iVar1;
      FUN_000d0888(iVar1,0,3);
      FUN_000d0888(iVar1 + 3,0,3);
      FUN_000d0888(iVar1 + 6,1,2);
      FUN_000d0888(iVar1 + 8,0,2);
      FUN_000d0888(iVar1 + 10,0,2);
      FUN_000d0888(iVar1 + 0xc,0,4);
      FUN_000d0888(iVar1 + 0x10,param_1[0x36],2);
      FUN_000d0888(iVar1 + 0x12,param_1[0x37],2);
      FUN_000d0888(iVar1 + 0x14,0,2);
      FUN_000d0888(iVar1 + 0x16,0,2);
      puVar5 = (undefined *)(uint)*(ushort *)(param_1 + 0x34);
      bVar14 = SBORROW4((int)puVar5,0x4000);
      puVar12 = puVar5 + -0x4000;
      bVar13 = puVar12 == (undefined *)0x0;
      puVar8 = puVar12;
      if ((undefined *)0x3fff < puVar5) {
        bVar14 = SBORROW4((int)puVar12,0x1dc0);
        puVar8 = puVar5 + -24000;
        bVar13 = puVar12 == (undefined *)0x1dc0;
      }
      if (bVar13) {
        uVar7 = DAT_000b5598;
      }
      else {
        uVar7 = DAT_000b5594;
        if ((int)puVar8 < 0 == bVar14) {
          if (puVar5 == (undefined *)0x7d00) {
            uVar7 = 0x7d000000;
          }
          else if ((puVar5 != (undefined *)0xac44) && (puVar5 == &DAT_0000bb80)) {
            uVar7 = DAT_000b55a4;
          }
        }
        else if (puVar5 == (undefined *)0x2ee0) {
          uVar7 = DAT_000b559c;
        }
        else if (puVar5 == (undefined *)0x3e80) {
          uVar7 = 0x3e800000;
        }
        else if (puVar5 == (undefined *)0x5622) {
          uVar7 = DAT_000b55a0;
        }
      }
      FUN_000d0888(iVar1 + 0x18,uVar7);
      iVar2 = FUN_000b75bc(iVar1 + 0x1c,0x27,&DAT_000b515c);
      iVar2 = iVar1 + 0x1c + iVar2;
      FUN_000d0888(iVar2,0,4);
      FUN_000d0888(iVar2 + 4,DAT_000b55a8,2);
      FUN_000d0888(iVar2 + 6,0,3);
      FUN_000d0888(iVar2 + 9,DAT_000b55ac,2);
      FUN_000d0888(iVar2 + 0xb,DAT_000b55b0,2);
      FUN_000d0888(iVar2 + 0xd,0x1800,3);
      FUN_000d0888(iVar2 + 0x10,0,4);
      FUN_000d0888(iVar2 + 0x14,0,4);
      FUN_000d0888(iVar2 + 0x18,0x502);
      puVar5 = (undefined *)(uint)*(ushort *)(param_1 + 0x34);
      bVar14 = SBORROW4((int)puVar5,0x4000);
      puVar12 = puVar5 + -0x4000;
      bVar13 = puVar12 == (undefined *)0x0;
      puVar8 = puVar12;
      if ((undefined *)0x3fff < puVar5) {
        bVar14 = SBORROW4((int)puVar12,0x1dc0);
        puVar8 = puVar5 + -24000;
        bVar13 = puVar12 == (undefined *)0x1dc0;
      }
      if (bVar13) {
        iVar1 = DAT_000b55b4 + 0x108;
      }
      else {
        iVar1 = DAT_000b55b4;
        if ((int)puVar8 < 0 == bVar14) {
          if (puVar5 == (undefined *)0x7d00) {
            iVar1 = DAT_000b55c4;
          }
          else if ((puVar5 != (undefined *)0xac44) && (puVar5 == &DAT_0000bb80)) {
            iVar1 = DAT_000b55c8;
          }
        }
        else if (puVar5 == (undefined *)0x2ee0) {
          iVar1 = DAT_000b55b8;
        }
        else if (puVar5 == (undefined *)0x3e80) {
          iVar1 = DAT_000b55bc;
        }
        else if (puVar5 == (undefined *)0x5622) {
          iVar1 = DAT_000b55c0;
        }
      }
      FUN_000d0888(iVar2 + 0x1a,iVar1);
      FUN_000d0888(iVar2 + 0x1c,DAT_000b55cc,3);
      param_2 = iVar2 + 0x1f;
      if (*(int *)(param_1 + 0x528) == 2) {
        FUN_000d0888(param_2,8,4);
        FUN_000d0888(iVar2 + 0x23,0,4);
        param_2 = iVar2 + 0x27;
      }
    }
    if (param_1[1] != '\x01') {
      return iVar10;
    }
    FUN_000d0888(param_2,1,4);
    uVar7 = 0x24;
    if (*(int *)(param_1 + 0x528) == 2) {
      uVar7 = 0x2c;
    }
    iVar1 = FUN_000b75bc(param_2 + 4,uVar7,&DAT_000b55d0);
    iVar1 = param_2 + 4 + iVar1;
    FUN_000d0888(iVar1,0,3);
    FUN_000d0888(iVar1 + 3,0,3);
    FUN_000d0888(iVar1 + 6,1,2);
    FUN_000d0888(iVar1 + 8,0,2);
    FUN_000d0888(iVar1 + 10,0,2);
    FUN_000d0888(iVar1 + 0xc,0,4);
    FUN_000d0888(iVar1 + 0x10,param_1[0x36],2);
    FUN_000d0888(iVar1 + 0x12,param_1[0x37],2);
    FUN_000d0888(iVar1 + 0x14,0,2);
    FUN_000d0888(iVar1 + 0x16,0,2);
    FUN_000d0888(iVar1 + 0x18,(uint)*(ushort *)(param_1 + 0x34) << 0x10,4);
    if (*(int *)(param_1 + 0x528) == 2) {
      FUN_000d0888(iVar1 + 0x1c,8,4);
      FUN_000d0888(iVar1 + 0x20,0,4);
      return iVar10;
    }
    return iVar10;
  }
  switch(*param_1) {
  case '\0':
    break;
  case '\x01':
    iVar10 = *(int *)(param_1 + 0x18);
    iVar1 = param_2;
    if (iVar10 != 0) {
      iVar1 = *(int *)(param_1 + 0x1c);
    }
    if (iVar10 == 0 || iVar1 == 0) goto LAB_000b495c;
    goto LAB_000b4954;
  case '\x02':
    break;
  case '\x03':
    iVar10 = 0x66;
    break;
  case '\x04':
    iVar10 = 0x75;
    break;
  case '\x05':
    break;
  case '\x06':
    goto LAB_000b4928;
  case '\a':
    break;
  case '\b':
LAB_000b4928:
    iVar10 = *(int *)(param_1 + 0x18);
    iVar1 = param_2;
    if (iVar10 != 0) {
      iVar1 = *(int *)(param_1 + 0x1c);
    }
    if (iVar10 == 0 || iVar1 == 0) {
LAB_000b495c:
      iVar10 = 0x9f;
    }
    else {
LAB_000b4954:
      iVar10 = iVar10 + 0x8b;
    }
  }
  iVar1 = FUN_000b75e8(param_2,iVar10,&DAT_000b4c8c,0,0,param_4);
  FUN_000d0888(param_2 + iVar1,1,4);
  iVar1 = param_2 + iVar1 + 4;
  switch(*param_1) {
  case '\0':
    break;
  case '\x01':
    iVar3 = *(int *)(param_1 + 0x18);
    iVar2 = extraout_r1;
    if (iVar3 != 0) {
      iVar2 = *(int *)(param_1 + 0x1c);
    }
    if (iVar3 != 0 && iVar2 != 0) {
      iVar3 = iVar3 + 0x7b;
      goto LAB_000b4a34;
    }
    goto LAB_000b4a18;
  case '\x02':
    break;
  case '\x03':
    iVar3 = 0x56;
    goto LAB_000b4a34;
  case '\x04':
    iVar3 = 0x65;
    goto LAB_000b4a34;
  case '\x05':
    break;
  case '\x06':
    goto LAB_000b49d4;
  case '\a':
    break;
  case '\b':
LAB_000b49d4:
    iVar3 = *(int *)(param_1 + 0x18);
    iVar2 = extraout_r1;
    if (iVar3 != 0) {
      iVar2 = *(int *)(param_1 + 0x1c);
    }
    if (iVar3 != 0 && iVar2 != 0) {
      iVar3 = iVar3 + 0x7b;
    }
    else {
LAB_000b4a18:
      iVar3 = 0x8f;
    }
LAB_000b4a34:
    iVar2 = FUN_000b75bc(iVar1,iVar3);
    goto LAB_000b4a44;
  }
  iVar2 = 0;
LAB_000b4a44:
  iVar1 = iVar1 + iVar2;
  FUN_000d0888(iVar1,0,3);
  FUN_000d0888(iVar1 + 3,0,3);
  FUN_000d0888(iVar1 + 6,1,2);
  FUN_000d0888(iVar1 + 8,0,4);
  FUN_000d0888(iVar1 + 0xc,DAT_000b4cb4,4);
  if (*(int *)(param_1 + 0x528) == 2) {
    FUN_000d0888(iVar1 + 0x10,0x200,4);
    uVar7 = 0x200;
  }
  else {
    FUN_000d0888(iVar1 + 0x10,0,4);
    uVar7 = 0;
  }
  FUN_000d0888(iVar1 + 0x14,uVar7,4);
  FUN_000d0888(iVar1 + 0x18,*(undefined4 *)(param_1 + 4),2);
  FUN_000d0888(iVar1 + 0x1a,*(undefined4 *)(param_1 + 8),2);
  FUN_000d0888(iVar1 + 0x1c,0x480000,4);
  FUN_000d0888(iVar1 + 0x20,0x480000,4);
  FUN_000d0888(iVar1 + 0x24,0,4);
  FUN_000d0888(iVar1 + 0x28,1,2);
  uVar11 = 0;
  iVar1 = iVar1 + 0x2a;
  do {
    iVar2 = iVar1;
    FUN_000d0888(iVar2,0,4);
    uVar11 = uVar11 + 1;
    iVar1 = iVar2 + 4;
  } while (uVar11 < 8);
  FUN_000d0888(iVar2 + 4,0x18,2);
  FUN_000d0888(iVar2 + 6,DAT_000b4cb8,2);
  cVar6 = *param_1;
  iVar2 = iVar2 + 8;
  if (cVar6 == '\x06' || cVar6 == '\b') {
    iVar3 = *(int *)(param_1 + 0x18);
    iVar1 = extraout_r1_00;
    if (iVar3 != 0) {
      iVar1 = *(int *)(param_1 + 0x1c);
    }
    if (iVar3 != 0 && iVar1 != 0) {
      iVar3 = iVar3 + 0x25;
    }
    else {
      iVar3 = 0x39;
    }
    iVar1 = FUN_000b75bc(iVar2,iVar3,&DAT_000b4cbc);
    puVar4 = (undefined1 *)(iVar2 + iVar1);
    *puVar4 = 1;
    puVar4[1] = 0x42;
    puVar4[2] = 0x80;
    puVar4[3] = 0x1e;
    puVar4[4] = 0xff;
    puVar4[5] = 0xe1;
    puVar4 = puVar4 + 6;
    uVar11 = *(uint *)(param_1 + 0x18);
    if (uVar11 != 0) {
      iVar2 = *(int *)(param_1 + 0x1c);
    }
    if (uVar11 != 0 && iVar2 != 0) {
      uVar11 = uVar11 & 0xffff;
      do {
        while (iVar1 = FUN_000d08f4(iVar2,4), iVar1 == 1) {
          uVar11 = uVar11 - 4 & 0xffff;
          uVar9 = 0;
          iVar2 = iVar2 + 4;
          iVar1 = iVar2;
          if (uVar11 < 5) {
            uVar9 = uVar11;
          }
          else {
            while ((uVar9 < uVar11 && (iVar3 = FUN_000d08f4(iVar1,4), iVar3 != 1))) {
              uVar9 = uVar9 + 1;
              iVar1 = iVar1 + 1;
            }
            uVar9 = uVar9 & 0xffff;
          }
          FUN_000d0888(puVar4,uVar9,2);
          puVar4 = puVar4 + 2;
          FUN_00000340(puVar4,iVar2,uVar9);
          iVar2 = iVar2 + uVar9;
          uVar11 = uVar11 - uVar9 & 0xffff;
          if (uVar11 < 5) {
            return iVar10;
          }
          puVar4[uVar9] = 1;
          puVar4 = puVar4 + uVar9 + 1;
        }
        uVar11 = uVar11 - 1 & 0xffff;
        iVar2 = iVar2 + 1;
      } while (4 < uVar11);
    }
  }
  else if (cVar6 == '\x01') {
    iVar3 = *(int *)(param_1 + 0x18);
    iVar1 = extraout_r1_00;
    if (iVar3 != 0) {
      iVar1 = *(int *)(param_1 + 0x1c);
    }
    if (iVar3 != 0 && iVar1 != 0) {
      iVar3 = iVar3 + 0x25;
    }
    else {
      iVar3 = 0x39;
    }
    puVar8 = &DAT_000b515c;
    iVar1 = FUN_000b75e8(iVar2,iVar3,&DAT_000b515c,0,0);
    puVar4 = (undefined1 *)(iVar2 + iVar1);
    *puVar4 = 3;
    iVar1 = *(int *)(param_1 + 0x18);
    if (iVar1 != 0) {
      puVar8 = *(undefined **)(param_1 + 0x1c);
    }
    if (iVar1 != 0 && puVar8 != (undefined *)0x0) {
      cVar6 = (char)iVar1 + '\x17';
    }
    else {
      cVar6 = '+';
    }
    puVar4[1] = cVar6;
    iVar1 = 2;
    FUN_000d0888(puVar4 + 2,1);
    puVar4[4] = 0x1f;
    puVar4[5] = 4;
    iVar2 = *(int *)(param_1 + 0x18);
    if (iVar2 != 0) {
      iVar1 = *(int *)(param_1 + 0x1c);
    }
    if (iVar2 != 0 && iVar1 != 0) {
      cVar6 = (char)iVar2 + '\x0f';
    }
    else {
      cVar6 = '#';
    }
    puVar4[6] = cVar6;
    puVar4[7] = 0x20;
    puVar4[8] = 0x11;
    FUN_000d0888(puVar4 + 9,DAT_000b5164,3);
    FUN_000d0888(puVar4 + 0xc,DAT_000b5168,4);
    iVar1 = 4;
    FUN_000d0888(puVar4 + 0x10,DAT_000b516c);
    puVar4[0x14] = 5;
    iVar2 = *(int *)(param_1 + 0x18);
    if (iVar2 != 0) {
      iVar1 = *(int *)(param_1 + 0x1c);
    }
    if (iVar2 == 0 || iVar1 == 0) {
      puVar4[0x15] = 0x14;
      iVar1 = FUN_000b4764(puVar4 + 0x16,param_1);
    }
    else {
      puVar4[0x15] = (char)iVar2;
      FUN_00000340(puVar4 + 0x16,*(undefined4 *)(param_1 + 0x1c),*(undefined4 *)(param_1 + 0x18));
      iVar1 = *(int *)(param_1 + 0x18);
    }
    puVar4 = puVar4 + iVar1 + 0x16;
    *puVar4 = 6;
    puVar4[1] = 1;
    puVar4[2] = 2;
  }
  else if (cVar6 == '\x04') {
    iVar1 = FUN_000b75bc(iVar2,0xf,&DAT_000b5170);
    iVar2 = iVar2 + iVar1;
    FUN_000db3f0(iVar2,&DAT_000b5178,4);
    *(undefined1 *)(iVar2 + 4) = 0;
    *(undefined1 *)(iVar2 + 5) = 10;
    *(undefined1 *)(iVar2 + 6) = 0;
  }
  return iVar10;
}


