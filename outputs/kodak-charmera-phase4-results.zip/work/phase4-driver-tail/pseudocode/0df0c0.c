/* Ghidra inferred pseudocode; file offset=0x0df0c0 */

undefined4 FUN_000deec0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  uint uVar2;
  undefined4 unaff_r4;
  undefined4 unaff_r5;
  undefined4 unaff_r6;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 in_lr;
  
  uVar1 = DAT_000defd4;
  uVar2 = DAT_000defd0;
  iVar3 = DAT_000defd0 - 0x100;
  iVar4 = DAT_000defd0 - 0x200;
  iVar5 = DAT_000defd0 - 0x300;
  if (*(int *)(DAT_000defcc + 0x74) == 0) {
    FUN_000a9d80(iVar5,DAT_000defdc,param_3,param_4,param_4);
    FUN_000a9d80(iVar4,DAT_000defdc);
    FUN_000a9d80(iVar3,DAT_000defdc);
    FUN_000a9d80(uVar2,DAT_000defdc);
    uVar2 = DAT_000defe4;
    uVar1 = DAT_000defe0;
  }
  else {
    switchD_000be904::default(DAT_000defd8,0);
    FUN_000a9d80(uVar2 - 0x304,4);
    FUN_000a9d80(uVar2 - 0x2fc,0);
    FUN_000a9d80(iVar5,uVar1);
    FUN_000a9d80(uVar2 - 0x204,4);
    FUN_000a9d80(uVar2 - 0x1fc,0);
    FUN_000a9d80(iVar4,uVar1);
    FUN_000a9d80(uVar2 - 0x104,4);
    FUN_000a9d80(uVar2 - 0xfc,0);
    FUN_000a9d80(iVar3,uVar1);
    FUN_000a9d80(uVar2 & 0xfffffffb);
    FUN_000a9d80(uVar2 + 4,0);
  }
  iVar3 = DAT_000a9078;
  FUN_0005ec44(*(undefined4 *)(DAT_000a9078 + 0xc));
  iVar4 = *(int *)(iVar3 + 8);
  if (iVar4 != 0) {
    if (*(uint *)(iVar4 + 0x4c) != 0) {
      uVar1 = (*(code *)(*(uint *)(iVar4 + 0x4c) & 0xfffffffc))(uVar2,uVar1);
      goto LAB_000a9df4;
    }
    FUN_000ad54c(4,0,DAT_000a90c4,DAT_000a9e54,s__s_____NO_write_reg___in_ssv_drv_000a9e20,
                 s_ssv6xxx_drv_write_reg_000a9e08,iVar4,iVar4,unaff_r4,unaff_r5,unaff_r6,in_lr);
  }
  uVar1 = 0;
LAB_000a9df4:
  FUN_0005eb68(*(undefined4 *)(iVar3 + 0xc));
  return uVar1;
}


