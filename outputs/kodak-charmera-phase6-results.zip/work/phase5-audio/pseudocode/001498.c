/* Phase 5 focused audio export; inferred decompiler output. */

uint FUN_00001298(int param_1)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  
  uVar3 = 0;
  do {
    if (*DAT_000014a0 <= uVar3) {
      return DAT_000014a4;
    }
    uVar2 = 0;
    do {
      cVar1 = *(char *)(*(int *)(DAT_000014a0 + 2) + uVar3 * 0x20 + uVar2);
      if (*(char *)(param_1 + uVar2) == '.') {
        param_1 = param_1 + 1;
      }
      if ((cVar1 == '\0') && (3 < uVar2)) {
        return uVar3;
      }
    } while ((cVar1 == *(char *)(param_1 + uVar2)) && (uVar2 = uVar2 + 1 & 0xfffeffff, uVar2 < 0x28)
            );
    uVar3 = uVar3 + 1 & 0xfffeffff;
  } while( true );
}


