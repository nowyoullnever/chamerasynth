/* Phase 5 focused audio export; inferred decompiler output. */

int FUN_0000173c(undefined4 param_1)

{
  int iVar1;
  
  FUN_000016e4(param_1,0,0);
  iVar1 = FUN_000016e4(param_1,0,2);
  FUN_000016e4(param_1,0,0);
  return iVar1 + 1;
}


