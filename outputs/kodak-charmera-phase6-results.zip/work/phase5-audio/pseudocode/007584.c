/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_00007384(void)

{
  char cVar1;
  bool bVar2;
  int iVar3;
  undefined *puVar4;
  undefined4 *puVar5;
  byte *pbVar6;
  short *psVar7;
  ushort uVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  uint uVar12;
  int iVar13;
  bool bVar14;
  
  iVar11 = DAT_00007be0;
  puVar4 = PTR_DAT_00007344;
  iVar3 = DAT_00007334;
  bVar2 = false;
  if (*(char *)(DAT_00007334 + 9) != '\0') {
    iVar13 = DAT_00007be0 + 0xc;
    for (uVar12 = 0; uVar12 < *(byte *)(iVar3 + 9); uVar12 = uVar12 + 1) {
      iVar9 = iVar11 + uVar12 * 0x10;
      if ((*(ushort *)(iVar9 + 10) & 0xf) == 0) {
        uVar10 = FUN_00030efc(*(ushort *)(iVar9 + 8) & 0xff);
      }
      else {
        uVar10 = FUN_00035ee0((int)*(short *)(iVar9 + 8));
      }
      if (((*(ushort *)(iVar9 + 10) & 0xf0) == 0) &&
         (bVar14 = 1 < uVar10, uVar10 = 1 - uVar10, bVar14)) {
        uVar10 = 0;
      }
      if (uVar10 == 0) {
        if (*(char *)(iVar9 + 0xe) == '\0') {
          if (2 < *(ushort *)(iVar9 + 0xc)) {
            if (puVar4[8] == '\0') {
              if (uVar12 == 0) {
                FUN_000072a0(iVar13);
              }
              else {
                (*(code *)(*(uint *)(iVar11 + uVar12 * 0x10) & 0xfffffffc))(iVar9 + 0xc);
              }
            }
            bVar2 = true;
          }
        }
        else {
          *(undefined1 *)(iVar9 + 0xe) = 0;
          *(undefined2 *)(iVar9 + 0xc) = 0;
        }
        *(undefined2 *)(iVar9 + 0xc) = 0;
        if (*(short *)(iVar9 + 8) == 0) {
          puVar4[8] = 0;
        }
        *(undefined1 *)(iVar9 + 0xf) = 0;
      }
      else {
        uVar8 = *(short *)(iVar9 + 0xc) + 1;
        *(ushort *)(iVar9 + 0xc) = uVar8;
        if (*(char *)(iVar9 + 0xe) == '\0') {
          bVar14 = uVar8 == 0x30;
          if (0x2f < uVar8) {
            *(undefined1 *)(iVar9 + 0xe) = 1;
            bVar14 = puVar4[8] == '\0';
          }
          if (bVar14) {
            if (uVar12 == 0) {
              FUN_000072a0(iVar13);
            }
            else {
              (*(code *)(*(uint *)(iVar11 + uVar12 * 0x10) & 0xfffffffc))(iVar9 + 0xc);
            }
          }
LAB_00007464:
          if (*(short *)(iVar9 + 0xc) == -1) {
            *(undefined2 *)(iVar9 + 0xc) = 0x10;
          }
        }
        else {
          if (*(char *)(iVar9 + 0xf) != '\0') goto LAB_00007464;
          *(undefined2 *)(iVar9 + 0xc) = 0;
        }
        *(undefined2 *)(iVar3 + 0x28) = 0;
        *(undefined4 *)(iVar3 + 0x70) = 0;
      }
    }
  }
  iVar11 = 0;
  if (*(char *)(iVar3 + 3) != *(char *)(iVar3 + 0x19)) {
    *(undefined4 *)(iVar3 + 0x70) = 0;
    *(char *)(iVar3 + 0x19) = *(char *)(iVar3 + 3);
  }
  iVar13 = FUN_0001f5b0();
  FUN_0001f2a0();
  pbVar6 = DAT_00007378;
  if (iVar13 != 0) {
    cVar1 = *(char *)(iVar3 + 3);
    bVar14 = cVar1 == '\0';
    if (bVar14) {
      cVar1 = *(char *)(iVar3 + 0xd);
    }
    if ((bVar14 && cVar1 == '\0') && (iVar9 = FUN_00007288(), iVar9 == 0)) {
      if (iVar13 == 1) {
        iVar13 = 3;
      }
      else if (iVar13 == 2) {
        iVar13 = 5;
      }
      uVar12 = *(int *)(iVar3 + 0x70) + 4;
      *(uint *)(iVar3 + 0x70) = uVar12;
      if ((uint)(iVar13 * 0x3c) < uVar12 >> 7) {
        *(undefined4 *)(iVar3 + 0x70) = 0;
        puVar5 = DAT_0000735c;
        if (*pbVar6 != 0) {
          *pbVar6 = 0;
          FUN_00025984(*puVar5,DAT_0000737c,0,0,0);
        }
        *puVar4 = 7;
        FUN_00025984(*puVar5,DAT_0000736c,0,0,0);
      }
      iVar11 = 1;
    }
  }
  uVar10 = FUN_0001f5d8();
  uVar12 = uVar10;
  if ((*pbVar6 == 0) && (uVar10 != 0)) {
    iVar13 = 0;
    if (iVar11 == 0) {
      iVar13 = *(int *)(iVar3 + 0x70);
    }
    uVar12 = uVar10 * 0xf;
    if (iVar11 == 0) {
      *(int *)(iVar3 + 0x70) = iVar13 + 4;
    }
    psVar7 = DAT_00007be4;
    if (uVar10 * 0x3c < *(uint *)(iVar3 + 0x70) >> 7) {
      *(undefined4 *)(iVar3 + 0x70) = 0;
      if ((*psVar7 == 0x10b) && (iVar13 = FUN_000130c0(), iVar13 != 3)) {
        FUN_00025984(*DAT_00007bec,DAT_00007be8,0,0,0);
      }
      FUN_00023148(0);
      uVar12 = FUN_00025984(*DAT_00007338,DAT_00007bf0,0,0,0);
    }
    iVar11 = iVar11 + 1;
  }
  if (bVar2) {
    uVar12 = (uint)*pbVar6;
  }
  if (bVar2 && uVar12 != 0) {
    *pbVar6 = 0;
    FUN_00023148(1);
  }
  if (iVar11 == 0) {
    *(undefined4 *)(iVar3 + 0x70) = 0;
  }
  return;
}


