/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_000129a4(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  puVar2 = DAT_00012e18;
  *DAT_00012e18 = param_1;
  piVar1 = DAT_00012e08;
  puVar2[2] = param_2;
  *(undefined1 *)(puVar2 + 1) = *(undefined1 *)(*piVar1 + 1);
  *DAT_00012e00 = (char)param_2;
  if (*DAT_00012e1c == '\0') {
    puVar3 = DAT_00012e24;
  }
  else {
    puVar3 = DAT_00012e28;
  }
  FUN_00025984(*puVar3,DAT_00012e20,puVar2,0xc,0);
  return;
}


