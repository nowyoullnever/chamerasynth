/* Phase 5 focused audio export; inferred decompiler output. */

undefined8 FUN_00012bd0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  int unaff_r5;
  uint uVar11;
  bool bVar12;
  undefined4 uStack_20;
  
  puVar2 = DAT_00012e04;
  uStack_20 = param_4;
  uVar3 = FUN_00080b6c(DAT_00012e04[1]);
  puVar2[5] = uVar3;
  if (puVar2[0xc] == 0) {
    unaff_r5 = FUN_000125ac(*puVar2,puVar2[6],uVar3,*puVar2,param_2,param_3);
  }
  iVar1 = DAT_00012e00;
  iVar4 = FUN_0008f560(*(undefined4 *)(DAT_00012e00 + 0x10),0,&uStack_20);
  if ((puVar2[0xc] == 0) && (iVar5 = FUN_000127a0(unaff_r5,puVar2 + 6,unaff_r5 == -4), iVar5 != 0))
  {
    uVar3 = 7;
    goto LAB_00012d38;
  }
  uVar7 = puVar2[9];
  uVar9 = puVar2[8];
  if (uVar7 < uVar9) {
    uVar10 = puVar2[6];
    uVar11 = puVar2[5];
    uVar6 = uVar10 - uVar11;
    if (uVar10 < uVar11) {
      uVar6 = uVar6 + 0x1000;
    }
    if (uVar9 - uVar7 < uVar6) {
      iVar5 = uVar10 - ((uVar6 - uVar9) + uVar7);
      if (iVar5 < 0) {
        iVar5 = iVar5 + 0x1000;
      }
      puVar2[6] = iVar5;
    }
    uVar3 = DAT_00012e38;
    if ((*(char *)(iVar1 + 6) == '\0') || (puVar2[6] != uVar11)) {
      iVar5 = FUN_00080b7c(puVar2[1],*(undefined4 *)(DAT_00012e40 + iVar4 * 4),puVar2[6]);
      if (iVar5 != -1) {
        uVar7 = FUN_00080b6c(puVar2[1]);
        puVar2[5] = uVar7;
        iVar8 = puVar2[9] + (uVar7 - uVar11);
        bVar12 = uVar7 < uVar11;
        if (bVar12) {
          uVar7 = iVar8 + 0x1000;
        }
        puVar2[9] = iVar8;
        if (bVar12) {
          puVar2[9] = uVar7;
        }
        if (0 < iVar5) goto LAB_00012db4;
        iVar5 = puVar2[10];
        puVar2[10] = iVar5 + -1;
        if (iVar5 + -1 != 0) {
          FUN_0008f73c(*(undefined4 *)(iVar1 + 0x10),iVar4);
          goto LAB_00012de0;
        }
      }
      uVar3 = 6;
      goto LAB_00012d38;
    }
    iVar5 = 0x80;
    if (*(char *)(iVar1 + 7) == '\0') {
      FUN_0008f67c(*DAT_00012e10,DAT_00012e3c);
      *(undefined1 *)(iVar1 + 7) = 1;
    }
    *(int *)(iVar1 + 0x30) = *(int *)(iVar1 + 0x30) + 0x80;
    uVar7 = (uint)*(byte *)(iVar1 + 4) * (uint)(*(byte *)(iVar1 + 8) >> 3) * 0x80;
    if (uVar7 <= (uint)puVar2[9]) {
      puVar2[9] = puVar2[9] - uVar7;
LAB_00012db4:
      uVar7 = FUN_00080c3c(puVar2[1]);
      *(uint *)(DAT_00012e44 + iVar4 * 4) = (uVar7 & 0xff) * iVar5;
      FUN_0008f67c(*DAT_00012e2c,iVar4);
      FUN_000129fc();
LAB_00012de0:
      param_2 = 0;
      FUN_00025984(*(undefined4 *)(iVar1 + 0xc),uVar3,0);
      uVar3 = 0;
      goto LAB_00012d38;
    }
  }
  else if (*(char *)(iVar1 + 1) != '\0') {
    FUN_0008f73c(*(undefined4 *)(iVar1 + 0x10),iVar4);
    FUN_000136b4();
  }
  uVar3 = 5;
LAB_00012d38:
  return CONCAT44(param_2,uVar3);
}


