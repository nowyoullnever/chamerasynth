/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_00012e48(void)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  
  while (iVar3 = FUN_00033f58(), piVar2 = DAT_00012e08, iVar1 = DAT_00012e04, iVar3 == 1) {
    FUN_000904e4(1);
  }
  if (*(char *)(*DAT_00012e08 + 1) == '\0') {
    if (-1 < *(short *)(DAT_00012e04 + 10)) {
      FUN_000e2c54();
    }
  }
  else if (*(char *)(*DAT_00012e08 + 1) == '\a') {
    FUN_000016e4((int)*(short *)(DAT_00012e04 + 10),0);
  }
  FUN_00033d60();
  FUN_00033f70();
  FUN_00000560(*(undefined4 *)(iVar1 + 4));
  *(undefined4 *)(iVar1 + 4) = 0;
  iVar3 = DAT_00012e40;
  iVar1 = DAT_00012e00;
  for (uVar4 = 0; uVar4 < *(uint *)(iVar1 + 0x1c); uVar4 = uVar4 + 1) {
    FUN_00000560(*(undefined4 *)(iVar3 + uVar4 * 4));
    *(undefined4 *)(iVar3 + uVar4 * 4) = 0;
  }
  *DAT_00013564 = *DAT_00013564 + 1;
  FUN_00033970(0);
  *(undefined1 *)*piVar2 = 3;
  return;
}


