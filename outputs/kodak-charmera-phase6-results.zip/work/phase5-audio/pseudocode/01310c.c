/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_00012f0c(int param_1)

{
  undefined1 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined1 *puVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  undefined4 in_lr;
  
  piVar2 = DAT_00012e08;
  if (*(char *)*DAT_00012e08 != '\x03') {
    FUN_00012e48();
  }
  FUN_00033970(1);
  puVar3 = DAT_00012e2c;
  puVar1 = DAT_00012e00;
  DAT_00012e00[1] = 1;
  FUN_0008f518(*puVar3);
  FUN_0008f518(*(undefined4 *)(puVar1 + 0x10));
  FUN_0008f518(*(undefined4 *)(puVar1 + 0x14));
  puVar3 = DAT_00012e10;
  FUN_0008f67c(*DAT_00012e10,DAT_00013568);
  uVar5 = *(uint *)(param_1 + 8);
  iVar8 = *piVar2;
  *(char *)(iVar8 + 1) = (char)uVar5;
  uVar7 = DAT_0001356c;
  iVar9 = DAT_00012e04;
  if ((uVar5 & 0xff) == 0) {
    iVar8 = FUN_000128ec((int)*(short *)(param_1 + 2),iVar8,DAT_00012e04);
    if (iVar8 != 0) {
      iVar9 = 2;
      goto FUN_000129a4;
    }
  }
  else {
    *(undefined4 *)(iVar8 + 4) = *(undefined4 *)(param_1 + 0xc);
    uVar7 = DAT_0001356c;
    *(undefined4 *)(iVar9 + 0x20) = *(undefined4 *)(param_1 + 0x10);
    *(undefined2 *)(iVar9 + 10) = *(undefined2 *)(param_1 + 2);
  }
  puVar6 = (undefined1 *)*piVar2;
  *puVar6 = 1;
  *(undefined4 *)(iVar9 + 0x10) = 0x1000;
  *(undefined1 *)(iVar9 + 8) = 0;
  *(undefined4 *)(puVar1 + 0x1c) = 6;
  if (*(int *)(puVar6 + 4) == 0) {
    *(undefined4 *)(puVar6 + 8) = DAT_0001357c;
    *(undefined4 *)(puVar6 + 0xc) = DAT_00013580;
    *(undefined4 *)(iVar9 + 0x10) = 0x1000;
    *(undefined4 *)(iVar9 + 0xc) = 0x800;
    *(undefined4 *)(puVar1 + 0x1c) = 4;
    puVar1[6] = 0;
    puVar1[7] = 0;
    *(undefined4 *)(puVar1 + 0x30) = 0;
    FUN_0008f67c(*puVar3,DAT_00012e0c);
  }
  else {
    if (*(int *)(puVar6 + 4) != 1) {
      iVar9 = 2;
      uVar7 = DAT_00013570;
      goto FUN_000129a4;
    }
    *(undefined4 *)(puVar6 + 8) = DAT_00013574;
    *(undefined4 *)(puVar6 + 0xc) = DAT_00013578;
    *(undefined4 *)(iVar9 + 0xc) = 0x480;
  }
  iVar9 = FUN_000133f0(*(undefined4 *)(*piVar2 + 4),iVar9,DAT_00012e40);
  if (iVar9 == 0) {
    iVar9 = (*(code *)(*(uint *)(*piVar2 + 8) & 0xfffffffc))();
    if (iVar9 == 0) {
      FUN_0008f67c(*puVar3,DAT_00013584);
      FUN_00025984(*(undefined4 *)(puVar1 + 0xc),DAT_00012e38,0,0,0);
    }
    else {
      FUN_00012e48();
    }
  }
  else {
    iVar9 = 9;
  }
FUN_000129a4:
  puVar3 = DAT_00012e18;
  *DAT_00012e18 = uVar7;
  piVar2 = DAT_00012e08;
  puVar3[2] = iVar9;
  *(undefined1 *)(puVar3 + 1) = *(undefined1 *)(*piVar2 + 1);
  *DAT_00012e00 = (char)iVar9;
  if (*DAT_00012e1c == '\0') {
    puVar4 = DAT_00012e24;
  }
  else {
    puVar4 = DAT_00012e28;
  }
  FUN_00025984(*puVar4,DAT_00012e20,puVar3,0xc,0,in_lr);
  return;
}


