/* Phase 5 focused audio export; inferred decompiler output. */

undefined1 FUN_000130c0(void)

{
  return *(undefined1 *)*DAT_00012e08;
}


