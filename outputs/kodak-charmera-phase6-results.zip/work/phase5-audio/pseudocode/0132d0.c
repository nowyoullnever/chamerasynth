/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_000130d0(void)

{
  int iVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_0002584c(0x40,0x40,0x1c);
  iVar1 = DAT_00012e00;
  *(undefined4 *)(DAT_00012e00 + 0xc) = uVar2;
  uVar2 = FUN_0008f310(DAT_00013588,6);
  *(undefined4 *)(iVar1 + 0x10) = uVar2;
  uVar2 = FUN_0008f310(DAT_0001358c,1);
  *(undefined4 *)(iVar1 + 0x14) = uVar2;
  return;
}


