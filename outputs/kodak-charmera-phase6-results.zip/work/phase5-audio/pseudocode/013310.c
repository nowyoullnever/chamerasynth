/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_00013110(void)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  byte bVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  bool bVar10;
  bool bVar11;
  int local_40;
  char local_3c;
  byte local_3b;
  
  FUN_000130d0();
  iVar6 = FUN_00000544(0x1000);
  piVar1 = DAT_00012e04;
  *DAT_00012e04 = iVar6;
  if (iVar6 == 0) {
    iVar6 = FUN_00000544(0x1000);
    *piVar1 = iVar6;
  }
  piVar1[4] = 0x1000;
  piVar1[6] = 0;
  puVar2 = DAT_00012e08;
  piVar1[5] = 0;
  iVar6 = DAT_00012e00;
  *(undefined1 *)*puVar2 = 3;
  *(undefined1 *)(iVar6 + 1) = 1;
  uVar4 = DAT_00013594;
  uVar3 = DAT_00013590;
  *(undefined4 *)(iVar6 + 0x24) = 0;
switchD_000131b0_default:
  while( true ) {
    FUN_00025a38(*(undefined4 *)(iVar6 + 0xc),&local_40,&local_3c,0x1c);
    bVar11 = SCARRY4(local_40,-0x10000000);
    iVar8 = local_40 + -0x10000000;
    bVar10 = iVar8 == 0;
    iVar9 = iVar8;
    if (0xfffffff < local_40) {
      bVar11 = SBORROW4(iVar8,0x108);
      iVar9 = local_40 + -0x10000108;
      bVar10 = iVar8 == 0x108;
    }
    if (bVar10) break;
    if (iVar9 < 0 != bVar11) goto code_r0x000131a4;
    bVar11 = SBORROW4(local_40,0x10000001);
    iVar8 = local_40 + -0x10000001;
    bVar10 = iVar8 == 0;
    iVar9 = iVar8;
    if (0x10000000 < local_40) {
      bVar11 = SBORROW4(iVar8,0x118);
      iVar9 = local_40 + -0x10000119;
      bVar10 = iVar8 == 0x118;
    }
    if (bVar10) {
      *(undefined1 *)(iVar6 + 5) = 0;
    }
    else if (iVar9 < 0 == bVar11) {
      if (local_40 == 0x1000011b) {
        FUN_000135bc(&local_3c);
      }
      else if (local_40 == 0x1000011c) {
        FUN_00013638(&local_3c);
      }
    }
    else if (local_40 == 0x10000109) {
      if ((*(char *)*puVar2 == '\x01') &&
         (iVar9 = (*(code *)(*(uint *)((char *)*puVar2 + 0xc) & 0xfffffffc))(), iVar9 != 0)) {
        FUN_00012e48();
        FUN_000129a4(DAT_0001356c,iVar9);
        if (*(uint *)(iVar6 + 0x24) != 0) {
          (*(code *)(*(uint *)(iVar6 + 0x24) & 0xfffffffc))(1);
        }
      }
    }
    else if (local_40 == 0x10000118) {
      *(undefined1 *)(iVar6 + 5) = 1;
    }
  }
  if (local_3b < 0x40) {
    FUN_00033d74(local_3b);
    *(uint *)(iVar6 + 0x34) = (uint)local_3b;
  }
  uVar7 = DAT_000135a0;
  goto LAB_00013310;
code_r0x000131a4:
  switch(local_40) {
  case 0x10000100:
    goto LAB_00013228;
  case 0x10000101:
LAB_00013228:
    FUN_00012f0c(&local_3c);
    goto switchD_000131b0_default;
  case 0x10000102:
    goto switchD_000131b0_default;
  case 0x10000103:
    if (*(char *)*puVar2 != '\x01') goto switchD_000131b0_default;
    FUN_0008f67c(*DAT_00012e10,uVar3);
    while (iVar9 = FUN_00033f58(), iVar9 == 1) {
      FUN_000904e4(1);
    }
    *(undefined1 *)(iVar6 + 1) = 1;
    FUN_00033f70();
    FUN_00033970(0);
    *(undefined1 *)*puVar2 = 2;
    uVar7 = uVar4;
    break;
  case 0x10000104:
    if (*(char *)*puVar2 != '\x03' && *(char *)*puVar2 != '\0') {
      FUN_00012e48();
    }
    uVar7 = DAT_00013598;
    break;
  case 0x10000105:
    FUN_0001372c(&local_3c);
    goto switchD_000131b0_default;
  case 0x10000106:
    goto switchD_000131b0_default;
  case 0x10000107:
    if (local_3c == '\x01') {
      bVar5 = 0;
    }
    else {
      bVar5 = local_3b;
    }
    FUN_00033d74(bVar5);
    uVar7 = DAT_0001359c;
    break;
  default:
    goto switchD_000131b0_default;
  }
LAB_00013310:
  FUN_000129a4(uVar7,0);
  goto switchD_000131b0_default;
}


