/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_000135bc(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  if (*(char *)*DAT_00012e08 != '\x01') {
    return;
  }
  if (*(int *)(param_1 + 0x18) == 1) {
    *(undefined1 *)(DAT_00012e00 + 6) = 1;
  }
  else {
    *(undefined1 *)(DAT_00012e00 + 6) = 0;
  }
  iVar1 = DAT_00012e04;
  if (*(int *)(param_1 + 0xc) == 1) {
    if (*(int *)(DAT_00012e04 + 0x18) != *(int *)(DAT_00012e04 + 0x14)) {
      iVar2 = *(int *)(DAT_00012e04 + 0x18) - *(int *)(DAT_00012e04 + 0x14);
      if (iVar2 < 0) {
        iVar2 = *(int *)(DAT_00012e04 + 0x10) + iVar2;
      }
      FUN_000e30f4((int)*(short *)(DAT_00012e04 + 10),-iVar2,1,param_4,param_4);
      *(undefined4 *)(iVar1 + 0x18) = 0;
    }
  }
  return;
}


