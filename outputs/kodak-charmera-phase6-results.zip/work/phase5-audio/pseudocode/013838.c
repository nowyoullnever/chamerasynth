/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_00013638(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  undefined1 uVar4;
  
  iVar1 = DAT_00012e00;
  iVar3 = *(int *)(param_1 + 0x14);
  if (*(int *)(param_1 + 0xc) == 0) {
    if (iVar3 == 2 || iVar3 == 4) {
      uVar2 = 0;
    }
    else {
      if (iVar3 != 1) {
        return;
      }
      uVar2 = *(uint *)(DAT_00012e00 + 0x34) & 0xff;
    }
    FUN_00033d74(uVar2);
    FUN_00033d20(iVar3 * *(int *)(iVar1 + 0x28));
  }
  else if (*(int *)(param_1 + 0xc) == 1) {
    uVar4 = 0;
    if (((iVar3 != 1) && (uVar4 = iVar3 == 2, !(bool)uVar4)) && (iVar3 == 4)) {
      uVar4 = 2;
    }
    *(undefined1 *)(DAT_00012e00 + 3) = uVar4;
  }
  return;
}


