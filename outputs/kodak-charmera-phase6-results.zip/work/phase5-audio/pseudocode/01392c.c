/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001372c(void)

{
  int iVar1;
  undefined4 *puVar2;
  
  puVar2 = DAT_00012e08;
  iVar1 = DAT_00012e00;
  if (*(char *)*DAT_00012e08 == '\x02') {
    if (*(char *)(DAT_00012e00 + 4) == '\x01') {
      FUN_00033cc0();
    }
    else {
      FUN_00033ce0();
    }
    FUN_00033970(1);
    *(undefined1 *)*puVar2 = 1;
    if (*(char *)(DAT_00012e04 + 8) != '\0') {
      FUN_000127a0(0xfffffffc,DAT_00012e04 + 0x18);
    }
    FUN_00025984(*(undefined4 *)(iVar1 + 0xc),DAT_00012e38,0,0,0);
    FUN_000129a4(DAT_000137b8,0);
  }
  return;
}


