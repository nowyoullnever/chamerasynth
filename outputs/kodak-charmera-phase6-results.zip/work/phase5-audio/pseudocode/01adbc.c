/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001abbc(void)

{
  byte bVar1;
  int iVar2;
  undefined1 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined1 uVar6;
  int iVar7;
  char cVar8;
  undefined4 in_r3;
  undefined4 unaff_r4;
  undefined4 in_lr;
  
  *(undefined2 *)(DAT_0001a548 + 4) = 0;
  iVar7 = FUN_00020054();
  iVar5 = DAT_0001e290;
  iVar2 = DAT_0001e28c;
  *(int *)(DAT_0001e290 + 0x1c) = iVar7;
  if (*(int *)(iVar2 + 0x24) <= iVar7) {
    *(undefined4 *)(iVar5 + 0x1c) = 0;
  }
  puVar4 = DAT_0001e288;
  puVar3 = DAT_0001e280;
  *DAT_0001e280 = 0;
  FUN_00025984(*puVar4,DAT_0001e47c,0,0,0);
  uVar6 = FUN_0001f588();
  puVar3[2] = uVar6;
  uVar6 = FUN_000200a8();
  puVar3[3] = uVar6;
  iVar2 = DAT_0001e27c;
  bVar1 = puVar3[2];
  if (8 < bVar1) {
    return;
  }
  if (bVar1 == 0) {
    cVar8 = '\0';
  }
  else {
    cVar8 = bVar1 * '\b' + -1;
  }
  *(char *)(DAT_0001e27c + 1) = cVar8;
  DAT_0001e280[2] = bVar1;
  FUN_0001f594();
  FUN_00025984(*DAT_0001e288,DAT_0001e284,iVar2,0x1c,0,in_r3,unaff_r4,in_lr);
  return;
}


