/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001e18c(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  int iVar2;
  char cVar3;
  
  iVar2 = DAT_0001e27c;
  if (8 < param_1) {
    return;
  }
  cVar1 = (char)param_1;
  if (param_1 == 0) {
    cVar3 = '\0';
    cVar1 = '\0';
  }
  else {
    cVar3 = cVar1 * '\b' + -1;
  }
  *(char *)(DAT_0001e27c + 1) = cVar3;
  *(char *)(DAT_0001e280 + 2) = cVar1;
  FUN_0001f594();
  FUN_00025984(*DAT_0001e288,DAT_0001e284,iVar2,0x1c,0,param_4);
  return;
}


