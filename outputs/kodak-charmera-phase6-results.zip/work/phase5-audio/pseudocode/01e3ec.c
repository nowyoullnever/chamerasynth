/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001e1ec(void)

{
  byte bVar1;
  int iVar2;
  undefined1 *puVar3;
  int iVar4;
  undefined1 uVar5;
  int iVar6;
  char cVar7;
  undefined4 uVar8;
  undefined4 unaff_r4;
  undefined4 in_lr;
  
  iVar6 = FUN_00020054();
  iVar4 = DAT_0001e290;
  iVar2 = DAT_0001e28c;
  *(int *)(DAT_0001e290 + 0x1c) = iVar6;
  puVar3 = DAT_0001e280;
  uVar8 = 0;
  if (*(int *)(iVar2 + 0x24) <= iVar6) {
    *(undefined4 *)(iVar4 + 0x1c) = 0;
  }
  *puVar3 = 0;
  uVar5 = FUN_0001f588();
  puVar3[2] = uVar5;
  uVar5 = FUN_000200a8();
  puVar3[3] = uVar5;
  iVar2 = DAT_0001e27c;
  bVar1 = puVar3[2];
  if (8 < bVar1) {
    return;
  }
  if (bVar1 == 0) {
    cVar7 = '\0';
  }
  else {
    cVar7 = bVar1 * '\b' + -1;
  }
  *(char *)(DAT_0001e27c + 1) = cVar7;
  DAT_0001e280[2] = bVar1;
  FUN_0001f594();
  FUN_00025984(*DAT_0001e288,DAT_0001e284,iVar2,0x1c,0,uVar8,unaff_r4,in_lr);
  return;
}


