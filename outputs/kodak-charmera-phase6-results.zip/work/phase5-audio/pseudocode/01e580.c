/* Phase 5 focused audio export; inferred decompiler output. */

int FUN_0001e380(undefined4 param_1,undefined2 *param_2)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  undefined1 auStack_38 [25];
  undefined1 auStack_1f [15];
  
  uVar1 = DAT_0001e28c;
  iVar2 = FUN_00005044(DAT_0001e28c,param_1);
  if (iVar2 == 0) {
    iVar2 = FUN_000e129c(uVar1,param_1,auStack_38);
    if (iVar2 != 0) {
      iVar3 = FUN_000e3310(iVar2);
      *param_2 = (short)iVar3;
      if ((-1 < iVar3) &&
         (iVar3 = FUN_000637ac(DAT_0001e490,0x120,s_storage_fopen_0001e480), iVar3 != 0)) {
        FUN_000e2ee4(iVar2,iVar3);
        FUN_00000488(param_2 + 1,0,0x100);
        FUN_00000340(param_2 + 1,iVar3 + 0x12,0x100);
        FUN_00000488(param_2 + 0x81,0,4);
        FUN_00000270(param_2 + 0x81,auStack_1f);
        *(undefined4 *)(param_2 + 0x84) = *(undefined4 *)(iVar3 + 8);
        param_2[0x86] = *(undefined2 *)(iVar3 + 2);
        param_2[0x87] = *(undefined2 *)(iVar3 + 4);
        FUN_00000560(iVar3);
        return 0;
      }
    }
    iVar2 = -1;
  }
  return iVar2;
}


