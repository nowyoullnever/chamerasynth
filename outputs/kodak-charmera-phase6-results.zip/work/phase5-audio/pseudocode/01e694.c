/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001e494(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 *puVar1;
  undefined2 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 uVar8;
  
  iVar7 = DAT_0001e290;
  if (*(int *)(DAT_0001e28c + 0x24) == 0) {
    return;
  }
  iVar4 = FUN_0001e380(*(undefined4 *)(DAT_0001e290 + 0x1c),DAT_0001ec8c,param_3,param_4,param_4);
  uVar6 = DAT_0001ec94;
  puVar3 = DAT_0001ec90;
  puVar2 = DAT_0001ec8c;
  if (iVar4 == -2) {
    *(undefined4 *)(iVar7 + 0x1c) = 0;
    iVar4 = FUN_0001e380(0,puVar2);
    if (iVar4 == 0) {
LAB_0001e508:
      FUN_00020070(*(undefined4 *)(iVar7 + 0x1c));
      puVar1 = DAT_0001e280;
      iVar7 = DAT_0001e27c;
      *(undefined2 *)(DAT_0001e27c + 2) = *DAT_0001ec8c;
      *(undefined4 *)(iVar7 + 8) = 0;
      *puVar1 = 1;
      uVar5 = *DAT_0001e288;
      uVar8 = 0x1c;
      uVar6 = DAT_0001ec98;
      goto LAB_0001e548;
    }
  }
  else if (iVar4 != -1) goto LAB_0001e508;
  FUN_0001e340();
  uVar8 = 0;
  uVar5 = *puVar3;
  iVar7 = 0;
LAB_0001e548:
  FUN_00025984(uVar5,uVar6,iVar7,uVar8,0);
  return;
}


