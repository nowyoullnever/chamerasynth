/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001e714(int param_1)

{
  undefined1 *puVar1;
  
  puVar1 = DAT_0001e27c;
  if (param_1 == 1) {
    *DAT_0001e27c = 1;
  }
  else {
    if (*(char *)(DAT_0001e280 + 2) == '\0') {
      DAT_0001e27c[1] = 0;
    }
    else {
      DAT_0001e27c[1] = *(char *)(DAT_0001e280 + 2) * '\b' + -1;
    }
    *puVar1 = 0;
  }
  FUN_00025984(*DAT_0001e288,DAT_0001eca8,puVar1,0x1c,0);
  return;
}


