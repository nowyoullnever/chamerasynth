/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001e76c(void)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_r3;
  
  uVar3 = FUN_0001f588();
  iVar2 = DAT_0001e280;
  *(char *)(DAT_0001e280 + 2) = (char)uVar3;
  if (uVar3 < 8) {
    cVar1 = (char)uVar3 + '\x01';
    *(char *)(iVar2 + 2) = cVar1;
    iVar2 = DAT_0001e27c;
    *(char *)(DAT_0001e27c + 1) = cVar1 * '\b' + -1;
    FUN_0001f594();
    FUN_00025984(*DAT_0001e288,DAT_0001e284,iVar2,0x1c,0,in_r3);
  }
  return;
}


