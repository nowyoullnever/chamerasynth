/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001e7c8(void)

{
  int iVar1;
  int iVar2;
  char cVar3;
  undefined4 in_r3;
  
  iVar2 = FUN_0001f588();
  iVar1 = DAT_0001e280;
  *(char *)(DAT_0001e280 + 2) = (char)iVar2;
  if (iVar2 != 0) {
    cVar3 = (char)(iVar2 - 1U);
    *(char *)(iVar1 + 2) = cVar3;
    iVar1 = DAT_0001e27c;
    if ((iVar2 - 1U & 0xff) == 0) {
      cVar3 = '\0';
    }
    else {
      cVar3 = cVar3 * '\b' + -1;
    }
    *(char *)(DAT_0001e27c + 1) = cVar3;
    FUN_0001f594();
    FUN_00025984(*DAT_0001e288,DAT_0001e284,iVar1,0x1c,0,in_r3);
  }
  return;
}


