/* Phase 5 focused audio export; inferred decompiler output. */

undefined4 FUN_0001e844(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined2 uVar3;
  
  iVar1 = FUN_0001f560();
  if (iVar1 == 0) {
LAB_0001e920:
    uVar2 = 0xffffffff;
  }
  else {
    iVar1 = FUN_000130c0();
    if (iVar1 == 3) {
      FUN_0001f560();
      FUN_0001e18c();
      iVar1 = DAT_0001e27c;
      if (param_1 == 0) {
        uVar3 = *(undefined2 *)(DAT_0001e290 + 4);
      }
      else if (param_1 == 1) {
        uVar3 = *(undefined2 *)(DAT_0001e290 + 2);
      }
      else if (param_1 == 2) {
        uVar3 = *(undefined2 *)(DAT_0001e290 + 6);
      }
      else if (param_1 == 3) {
        uVar3 = *(undefined2 *)(DAT_0001e290 + 8);
      }
      else if (param_1 == 4) {
        uVar3 = *(undefined2 *)(DAT_0001e290 + 10);
      }
      else if (param_1 == 5) {
        uVar3 = *(undefined2 *)(DAT_0001e290 + 0xc);
      }
      else if (param_1 == 6) {
        uVar3 = *(undefined2 *)(DAT_0001e290 + 0xe);
      }
      else if (param_1 == 7) {
        uVar3 = *(undefined2 *)(DAT_0001e290 + 0x10);
      }
      else if (param_1 == 8) {
        uVar3 = *(undefined2 *)(DAT_0001e290 + 0x12);
      }
      else if (param_1 == 9) {
        uVar3 = *(undefined2 *)(DAT_0001e290 + 0x14);
      }
      else if (param_1 == 10) {
        uVar3 = *(undefined2 *)(DAT_0001e290 + 0x16);
      }
      else {
        if (param_1 != 0xb) goto LAB_0001e920;
        uVar3 = *(undefined2 *)(DAT_0001e290 + 0x18);
      }
      *(undefined2 *)(DAT_0001e27c + 2) = uVar3;
      if (*(short *)(iVar1 + 2) == -1) goto LAB_0001e920;
      *(undefined4 *)(iVar1 + 8) = 7;
      *(undefined4 *)(iVar1 + 0xc) = 0;
      uVar2 = FUN_0000173c((int)*(short *)(iVar1 + 2));
      *(undefined4 *)(iVar1 + 0x10) = uVar2;
      *DAT_0001e280 = 1;
      FUN_00025984(*DAT_0001e288,DAT_0001ec98,iVar1,0x1c,0);
    }
    uVar2 = 0;
  }
  return uVar2;
}


