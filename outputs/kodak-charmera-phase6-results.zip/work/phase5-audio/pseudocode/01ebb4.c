/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001e9b4(void)

{
  if (*(int *)(DAT_0001e28c + 0x24) == 0) {
    return;
  }
  if (*DAT_0001e280 == '\x01') {
    *DAT_0001e280 = '\x02';
    FUN_00025984(*DAT_0001ec90,DAT_0001ec94,0,0,0);
    FUN_00025984(*DAT_0001e288,DAT_0001eca4,0,0,0);
    return;
  }
  return;
}


