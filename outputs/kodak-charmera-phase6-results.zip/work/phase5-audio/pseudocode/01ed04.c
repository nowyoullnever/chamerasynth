/* Phase 5 focused audio export; inferred decompiler output. */

undefined1 FUN_0001eb04(void)

{
  return *DAT_0001e280;
}


