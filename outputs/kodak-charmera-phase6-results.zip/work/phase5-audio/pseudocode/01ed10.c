/* Phase 5 focused audio export; inferred decompiler output. */

/* WARNING: Removing unreachable block (ram,0x0001ebb0) */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_0001eb10(int param_1)

{
  char *pcVar1;
  int iVar2;
  int iVar3;
  uint in_lr;
  
  pcVar1 = DAT_0001e290;
  iVar2 = DAT_0001e28c;
  if (param_1 != 0) {
    if (param_1 == 2) {
LAB_0001eb98:
      if (*DAT_0001e290 != '\0') {
        if (*(int *)(DAT_0001e28c + 0x24) != 0) {
          if (*DAT_0001e280 != '\x01' && *DAT_0001e280 != '\x02') {
            *DAT_0001e290 = '\x01';
            iVar2 = *(int *)(pcVar1 + 0x1c);
            *(int *)(pcVar1 + 0x1c) = iVar2 + -1;
            if (iVar2 + -1 < 0) {
              *(int *)(pcVar1 + 0x1c) = *(int *)(DAT_0001e28c + 0x24) + -1;
            }
            return;
          }
          FUN_0001ee50();
          FUN_0001e340();
          pcVar1 = DAT_0001e290;
          pcVar1[0x20] = '\x01';
          pcVar1[0x21] = '\0';
          pcVar1[0x22] = '\0';
          pcVar1[0x23] = '\0';
        }
        return;
      }
      if (*(int *)(DAT_0001e28c + 0x24) != 0) {
        if (*DAT_0001e280 != '\x01' && *DAT_0001e280 != '\x02') {
          *DAT_0001e290 = '\0';
          iVar3 = *(int *)(iVar2 + 0x24);
          iVar2 = *(int *)(pcVar1 + 0x1c);
          *(int *)(pcVar1 + 0x1c) = iVar2 + 1;
          if (iVar3 == iVar2 + 1) {
            pcVar1[0x1c] = '\0';
            pcVar1[0x1d] = '\0';
            pcVar1[0x1e] = '\0';
            pcVar1[0x1f] = '\0';
          }
                    /* WARNING: Could not recover jumptable at 0x0001ee4c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)(in_lr & 0xfffffffc))();
          return;
        }
        FUN_0001ee24();
        FUN_0001e340();
        pcVar1 = DAT_0001e290;
        pcVar1[0x20] = '\x01';
        pcVar1[0x21] = '\0';
        pcVar1[0x22] = '\0';
        pcVar1[0x23] = '\0';
      }
      return;
    }
    if (param_1 == 5) {
      if (DAT_0001e280[3] == '\0') {
        *DAT_0001e290 = '\0';
        FUN_0001e68c();
      }
      else {
        if (DAT_0001e280[3] != '\x01') {
          return;
        }
        FUN_0001e494();
      }
      FUN_0001f9c4();
    }
    else {
      if ((param_1 == 6) || (param_1 != 7)) goto LAB_0001eb98;
      FUN_0001e340();
      FUN_00025984(*DAT_0001ec90,DAT_0001ec94,0);
    }
  }
  return;
}


