/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001ecac(undefined2 param_1)

{
  int iVar1;
  undefined1 *puVar2;
  
  puVar2 = DAT_0001e280;
  iVar1 = DAT_0001e27c;
  *(undefined2 *)(DAT_0001e27c + 2) = param_1;
  *(undefined4 *)(iVar1 + 8) = 0;
  *puVar2 = 1;
  FUN_00025984(*DAT_0001e288,DAT_0001ec98,iVar1,0x1c,0);
  return;
}


