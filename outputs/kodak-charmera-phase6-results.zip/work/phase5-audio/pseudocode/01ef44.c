/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001ed44(void)

{
  if (*DAT_0001e280 == '\x02') {
    *DAT_0001e280 = '\x01';
    FUN_00025984(*DAT_0001ec90,DAT_0001ec9c,0,0,0);
    FUN_00025984(*DAT_0001e288,DAT_0001eca0,0,0,0);
    return;
  }
  return;
}


