/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001ed9c(void)

{
  *DAT_0001e280 = 0;
  FUN_00025984(*DAT_0001e288,DAT_0001e47c,0,0,0);
  return;
}


