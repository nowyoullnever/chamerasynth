/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001edcc(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = DAT_0001e27c;
  *(undefined4 *)(DAT_0001e27c + 0x18) = param_1;
  FUN_00025984(*DAT_0001e288,DAT_0001ee80,iVar1,0x1c,0);
  return;
}


