/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001ee24(void)

{
  undefined1 *puVar1;
  int iVar2;
  int iVar3;
  uint in_lr;
  
  puVar1 = DAT_0001e290;
  iVar2 = DAT_0001e28c;
  *DAT_0001e290 = 0;
  iVar3 = *(int *)(iVar2 + 0x24);
  iVar2 = *(int *)(puVar1 + 0x1c);
  *(int *)(puVar1 + 0x1c) = iVar2 + 1;
  if (iVar3 == iVar2 + 1) {
    *(undefined4 *)(puVar1 + 0x1c) = 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001ee4c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(in_lr & 0xfffffffc))();
  return;
}


