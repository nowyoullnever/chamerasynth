/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_0001ee50(void)

{
  undefined1 *puVar1;
  int iVar2;
  
  puVar1 = DAT_0001e290;
  *DAT_0001e290 = 1;
  iVar2 = *(int *)(puVar1 + 0x1c);
  *(int *)(puVar1 + 0x1c) = iVar2 + -1;
  if (iVar2 + -1 < 0) {
    *(int *)(puVar1 + 0x1c) = *(int *)(DAT_0001e28c + 0x24) + -1;
  }
  return;
}


