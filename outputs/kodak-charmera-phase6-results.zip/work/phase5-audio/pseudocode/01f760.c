/* Phase 5 focused audio export; inferred decompiler output. */

undefined1 FUN_0001f560(void)

{
  return *(undefined1 *)(DAT_0001f890 + 0x19);
}


