/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_00033970(int param_1)

{
  uint *puVar1;
  uint uVar2;
  
  puVar1 = DAT_00033f8c;
  if (param_1 == 1) {
    *DAT_00033f8c = *DAT_00033f8c | 0x2000;
    puVar1[8] = puVar1[8] | 0x2000;
    uVar2 = *puVar1 & 0xffffffcf;
  }
  else {
    *DAT_00033f8c = *DAT_00033f8c & 0xffffdfff;
    puVar1[8] = puVar1[8] & 0xffffdfff;
    uVar2 = *puVar1 | 0x30;
  }
  *puVar1 = uVar2;
  return;
}


