/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_00033d74(uint param_1)

{
  int iVar1;
  
  iVar1 = DAT_00033f8c;
  *(uint *)(DAT_00033f8c + 0x2c) = *(uint *)(DAT_00033f8c + 0x2c) & 0xffffffc0;
  *(uint *)(iVar1 + 0x2c) = *(uint *)(iVar1 + 0x2c) | param_1;
  return;
}


