/* Phase 5 focused audio export; inferred decompiler output. */

uint FUN_00033f58(void)

{
  char cVar1;
  uint uVar2;
  
  cVar1 = *(char *)(DAT_00033f9c + 0xe);
  if (cVar1 == -1) {
    return 0xffffffff;
  }
  if (cVar1 == '\0') {
    uVar2 = *DAT_000347fc;
  }
  else if (cVar1 == '\x01') {
    uVar2 = DAT_000347fc[0x10];
  }
  else if (cVar1 == '\x02') {
    uVar2 = DAT_000347fc[0x20];
  }
  else if (cVar1 == '\x03') {
    uVar2 = DAT_000347fc[0x30];
  }
  else if (cVar1 == '\x04') {
    uVar2 = DAT_000347fc[0x80];
  }
  else if (cVar1 == '\x05') {
    uVar2 = DAT_000347fc[0x90];
  }
  else if (cVar1 == '\x06') {
    uVar2 = DAT_000347fc[0xa0];
  }
  else if (cVar1 == '\a') {
    uVar2 = DAT_000347fc[0xb0];
  }
  else {
    uVar2 = 0;
  }
  return (uint)((uVar2 & 2) != 0);
}


