/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_00033f70(void)

{
  int iVar1;
  
  iVar1 = DAT_00033f9c;
  FUN_000353f4(DAT_00033f9c);
  *(undefined1 *)(iVar1 + 0xe) = 0xff;
  return;
}


