/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_000763b0(uint param_1)

{
  int iVar1;
  undefined1 auStack_18 [16];
  
  FUN_000db3f0(auStack_18,DAT_00076c14,0x10);
  iVar1 = DAT_00076c18;
  if (0xf < param_1) {
    param_1 = 0xf;
  }
  *(undefined1 *)(DAT_00076c18 + 1) = auStack_18[param_1];
  FUN_00025984(*DAT_00076c20,DAT_00076c1c,iVar1,0x1c,0);
  return;
}


