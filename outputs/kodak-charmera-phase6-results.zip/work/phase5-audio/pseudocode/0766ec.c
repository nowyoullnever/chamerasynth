/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_000764ec(void)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  bool bVar4;
  int local_1c [3];
  int local_10;
  
  iVar1 = DAT_00076c10;
  if (*(int *)(DAT_00076c10 + 0x58) == 0 || *(int *)(DAT_00076c10 + 0x58) == 3) {
    FUN_00025984(*DAT_00076c20,DAT_00076c48,DAT_00076c24,0x1c,0);
    puVar2 = DAT_00076c4c;
    while( true ) {
      FUN_00025a38(*puVar2,&local_10,local_1c,0xc);
      iVar3 = local_10 + -0x7042;
      bVar4 = iVar3 == 0;
      if (bVar4) {
        iVar3 = local_1c[0] + -0x10000001;
      }
      if (bVar4 && iVar3 == 0x10c) break;
      FUN_000904e4(2);
    }
  }
  *(undefined4 *)(iVar1 + 0x58) = 1;
  return;
}


