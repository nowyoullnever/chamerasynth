/* Phase 5 focused audio export; inferred decompiler output. */

void FUN_000765e4(void)

{
  int iVar1;
  undefined4 *puVar2;
  int local_1c [3];
  int local_10;
  
  iVar1 = DAT_00076c10;
  if (*(int *)(DAT_00076c10 + 0x58) != 0) {
    return;
  }
  FUN_00025984(*DAT_00076c20,DAT_00076c54,DAT_00076c24,0x1c,0);
  puVar2 = DAT_00076c4c;
  do {
    FUN_00025a38(*puVar2,&local_10,local_1c,0xc);
    if (local_10 == 0x7042) {
      if (local_1c[0] == 0x1000010e) {
        *(undefined4 *)(iVar1 + 0x58) = 3;
        return;
      }
      if (local_1c[0] == 0x1000010d) {
        FUN_00076598();
        return;
      }
    }
    FUN_000904e4(2);
  } while( true );
}


