/* Phase 5 focused audio export; inferred decompiler output. */

uint FUN_00076854(undefined4 param_1,undefined4 param_2,char param_3,short param_4,
                 undefined4 param_5,undefined4 param_6,char param_7)

{
  int iVar1;
  undefined1 *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  bool bVar8;
  undefined1 auStack_60 [8];
  undefined4 local_58;
  undefined4 uStack_54;
  int local_38 [2];
  int local_30;
  int local_2c;
  undefined1 local_e;
  undefined1 local_d;
  
  puVar2 = DAT_00076c24;
  iVar1 = DAT_00076c10;
  if (*(uint *)(DAT_00076c10 + 0x58) == 1) {
    local_e = (undefined1)((uint)param_1 >> 0x10);
    *DAT_00076c24 = local_e;
    local_d = (undefined1)((uint)param_1 >> 0x18);
    puVar2[1] = local_d;
    *(short *)(puVar2 + 2) = param_4;
    *(undefined4 *)(puVar2 + 4) = 0;
    if (param_3 == '\0') {
      *(undefined4 *)(puVar2 + 8) = 0;
      FUN_000e3338((int)param_4,auStack_60);
      *(undefined4 *)(puVar2 + 0x10) = local_58;
      *(undefined4 *)(iVar1 + 100) = 0;
      param_2 = uStack_54;
    }
    if (param_7 == '\x02') {
      uVar6 = 6;
    }
    else {
      if (param_7 == '\x03') {
        *(undefined4 *)(puVar2 + 0xc) = 1;
      }
      else if (param_7 == '\x04') {
        *(undefined4 *)(puVar2 + 0xc) = 0;
      }
      puVar3 = DAT_00076c4c;
      FUN_00025910(*DAT_00076c4c,param_2);
      puVar5 = DAT_00076c6c;
      uVar4 = DAT_00076c68;
      *(undefined4 *)(iVar1 + 0x58) = 0;
      *puVar5 = uVar4;
      FUN_00025984(*DAT_00076c20,DAT_00076c70,puVar2,0x1c,0);
      while( true ) {
        FUN_00025a38(*puVar3,&local_2c,local_38,0xc);
        iVar7 = local_2c + -0x7042;
        bVar8 = iVar7 == 0;
        if (bVar8) {
          iVar7 = local_38[0] + -0x10000003;
        }
        if (bVar8 && iVar7 == 0x108) break;
        FUN_000904e4(2);
      }
      if (local_30 == 0) {
        if ((byte)puVar2[1] < 0x40) {
          FUN_00033d74();
        }
        uVar6 = 0;
      }
      else {
        uVar6 = 1;
        *(undefined4 *)(iVar1 + 0x58) = 1;
      }
    }
  }
  else {
    uVar6 = *(uint *)(DAT_00076c10 + 0x58) & 0xff;
  }
  return uVar6;
}


