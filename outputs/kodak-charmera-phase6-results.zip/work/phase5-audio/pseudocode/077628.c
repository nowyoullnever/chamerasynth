/* Phase 5 focused audio export; inferred decompiler output. */

undefined8 FUN_00077428(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short *psVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  short *psVar8;
  int iVar9;
  undefined4 uStack_18;
  
  uStack_18 = param_4;
  iVar3 = FUN_0008f560(*DAT_00077548,0,&uStack_18,param_4,param_2,param_3);
  iVar9 = DAT_00077534;
  iVar4 = (*(code *)(*(uint *)(DAT_00076c10 + 0x18) & 0xfffffffc))
                    (*(undefined4 *)(DAT_00076c10 + 0x1c),*(undefined4 *)(DAT_00077534 + iVar3 * 4),
                     0x480);
  iVar2 = DAT_00077550;
  psVar1 = DAT_0007754c;
  if (iVar4 < 1) {
    uVar5 = 5;
  }
  else {
    if (*DAT_0007754c == 0) {
      psVar8 = *(short **)(iVar9 + iVar3 * 4);
      uVar6 = 0;
      do {
        *(undefined4 *)(iVar2 + uVar6 * 4) = 0;
        uVar7 = 0;
        do {
          iVar9 = (int)*psVar8;
          if (iVar9 < 0) {
            iVar9 = 0x7fff - (iVar9 + 0x8000);
          }
          uVar7 = uVar7 + 1 & 0xfffeffff;
          *(int *)(iVar2 + uVar6 * 4) = *(int *)(iVar2 + uVar6 * 4) + iVar9;
          psVar8 = psVar8 + 1;
        } while (uVar7 < 0x10);
        uVar6 = uVar6 + 1 & 0xfffeffff;
      } while (uVar6 < 6);
      *psVar1 = 1;
    }
    *(int *)(DAT_00077554 + iVar3 * 4) = iVar4;
    FUN_0008f67c(*DAT_00077558,iVar3);
    FUN_000129fc();
    param_2 = 0;
    FUN_00025984(*DAT_00076c20,DAT_0007755c,0);
    uVar5 = 0;
  }
  return CONCAT44(param_2,uVar5);
}


