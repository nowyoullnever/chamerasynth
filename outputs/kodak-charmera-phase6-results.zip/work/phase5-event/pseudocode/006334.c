/* requested VA 0x00006134, containing VA 0x00006134 */

void FUN_00006134(void)

{
  undefined4 uVar1;
  char *pcVar2;
  undefined4 *puVar3;
  byte bVar4;
  undefined2 uVar5;
  undefined2 uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined4 uVar11;
  undefined1 auStack_44 [4];
  int local_40;
  int iStack_3c;
  undefined1 local_38;
  undefined1 local_36;
  undefined1 local_35;
  undefined2 local_34;
  undefined2 local_32;
  undefined2 local_30;
  undefined2 local_2e;
  undefined4 local_2c;
  undefined4 local_28;
  
  uVar5 = FUN_000f0d98();
  uVar6 = FUN_000f0dd4();
  pcVar2 = DAT_0000633c;
  puVar10 = (undefined4 *)0x0;
  for (bVar4 = 0; (*pcVar2 == '\0' && (bVar4 < 0x32)); bVar4 = bVar4 + 1) {
    FUN_000904e4(5);
  }
  FUN_0007a818(0x3a,0x14);
  FUN_000060a8();
  FUN_0001f588();
  FUN_0001e18c();
  FUN_00035f04(0x5f,0);
  iVar8 = DAT_00006340;
  if ((*(char *)(DAT_00006340 + 1) == '\0') && (iVar7 = FUN_0001e844(2), iVar7 != 0)) {
    *(char *)(iVar8 + 1) = *(char *)(iVar8 + 1) + '\x01';
  }
  FUN_00060e54();
  iVar8 = FUN_00001310(s_POWER_ON_LOGO_JPG_00006344);
  uVar1 = DAT_00006090;
  if (iVar8 != 0xffff) {
    iVar7 = FUN_0000173c();
    if ((iVar7 != 0) &&
       (iVar9 = FUN_000637ac(DAT_0000636c,iVar7,s_state_startup_init_00006358), iVar9 != 0)) {
      iVar8 = FUN_00001520((int)(short)iVar8,iVar9,iVar7);
      if ((iVar8 == 0) &&
         (puVar10 = (undefined4 *)FUN_00014498(uVar1), puVar10 != (undefined4 *)0x0)) {
        puVar10[1] = 0;
        uVar11 = *puVar10;
        local_38 = 1;
        local_40 = iVar9;
        iStack_3c = iVar7;
        iVar8 = FUN_000f0e10();
        if (iVar8 == 1) {
          local_36 = 4;
        }
        else {
          iVar8 = FUN_000f0e10();
          if (iVar8 == 0) {
            local_36 = 6;
          }
          else {
            local_36 = 0;
          }
        }
        puVar3 = DAT_00006374;
        local_35 = 0;
        local_2c = DAT_00006370;
        local_28 = *DAT_00006374;
        local_34 = uVar5;
        local_32 = uVar6;
        local_30 = uVar5;
        local_2e = uVar6;
        iVar8 = FUN_000228ec(auStack_44);
        if (iVar8 != -1) {
          FUN_00000360(uVar11,*puVar3,0x6400);
          FUN_0008f67c(*DAT_000060a4,(uint)puVar10 | 0x1000000);
          puVar10 = (undefined4 *)0x0;
        }
      }
      FUN_00000560(iVar9);
      FUN_000904e4(5);
    }
  }
  if (puVar10 != (undefined4 *)0x0) {
    FUN_000f03e0(uVar1,puVar10);
  }
  FUN_00082bfc(1);
  FUN_000284a8(1);
  FUN_00035f04(0x26,1);
  FUN_000609f8(0);
  return;
}


