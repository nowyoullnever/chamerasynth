/* requested VA 0x00006378, containing VA 0x00006378 */

void seed_6578(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0008f67c(*DAT_00006518,DAT_00006514,param_3,param_4,param_4);
  FUN_00025984(*DAT_00006520,DAT_0000651c,0,0,0);
  return;
}


