/* requested VA 0x0000cc2c, containing VA 0x0000cc2c */

undefined4 FUN_0000cc2c(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 in_r3;
  
  FUN_0000bae0();
  FUN_0006f65c(2);
  FUN_0000f38c(0xc);
  FUN_0000c66c();
  FUN_0000c68c();
  puVar3 = (undefined4 *)*DAT_0000d020;
  puVar3[0xc] = *DAT_0000d01c;
  puVar3[0xd] = 0x2200000;
  *(undefined1 *)(puVar3 + 0xe) = 1;
  puVar3[9] = 8;
  iVar1 = FUN_0008c4a4(puVar3[9] & 0xff,*puVar3,puVar3[10],puVar3[0xb],puVar3[0xc],puVar3[0xd],
                       *(undefined1 *)(puVar3 + 0xe),in_r3);
  if (iVar1 < 0) {
    uVar2 = 0xffffffff;
  }
  else {
    FUN_0008c604(*puVar3,1);
    FUN_0008c3dc(*puVar3,DAT_0000bfd4);
    uVar2 = 0;
  }
  return uVar2;
}


