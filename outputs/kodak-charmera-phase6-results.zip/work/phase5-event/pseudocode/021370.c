/* requested VA 0x00021170, containing VA 0x00021170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void seed_21370(void)

{
  bool bVar1;
  char *pcVar2;
  byte bVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  uint unaff_r9;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  int local_7c;
  uint local_78;
  undefined4 local_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined1 auStack_68 [44];
  int local_3c;
  undefined1 auStack_38 [4];
  uint local_34;
  undefined4 local_30;
  int local_28;
  
  bVar3 = 0;
  FUN_000db3f0(auStack_68,DAT_0002152c,0x29);
  local_74 = 0;
  uStack_70 = 0;
  uStack_6c = 0;
  FUN_00030b54(0);
  FUN_000e2b40(&DAT_00021530);
  iVar5 = DAT_00021534;
  thunk_FUN_000db94c(&local_74,DAT_00021534 + 0x26,8);
  iVar4 = FUN_00020ffc(&local_74);
  local_3c = FUN_000e31bc(iVar5 + 0x12,0);
  if (local_3c < 0) {
LAB_000211e8:
    FUN_00030ce8(0);
    return;
  }
  iVar5 = FUN_000e2dc8(local_3c,auStack_38);
  if ((iVar5 != 0) ||
     (local_28 = FUN_00000544(0x10000,local_30), pcVar2 = DAT_00020c60, local_28 == 0)) {
    FUN_000e2c54(local_3c);
    goto LAB_000211e8;
  }
  *DAT_00020c60 = '\0';
  bVar1 = true;
  uVar9 = 0;
  do {
    if (local_34 <= uVar9) break;
    uVar10 = local_34 - uVar9;
    if (0xffff < uVar10) {
      uVar10 = 0x10000;
    }
    uVar10 = FUN_000e321c(local_3c,local_28,uVar10);
    for (uVar11 = 0; uVar11 < uVar10; uVar11 = uVar11 + 1) {
      *(uint *)(pcVar2 + 8) = (uint)*(byte *)(local_28 + uVar11) + *(int *)(pcVar2 + 8);
      if ((bVar1) && (2 < uVar11)) {
        bVar1 = false;
      }
    }
    uVar9 = uVar9 + uVar10;
  } while (*pcVar2 == '\0');
  if (*(int *)(pcVar2 + 8) != iVar4) {
    if (*pcVar2 != '\0') goto LAB_000212f4;
    *pcVar2 = '\x01';
    FUN_000e2c54(local_3c);
  }
  if (*pcVar2 == '\0') {
    FUN_000e30f4(local_3c,0);
  }
LAB_000212f4:
  iVar5 = FUN_00000544(0x100);
  if (iVar5 == 0) {
    FUN_000e2c54(local_3c);
    return;
  }
  FUN_0008fff4(0x34);
  FUN_0008fff4(0x32);
  FUN_0008fff4(0x30);
  FUN_0008fff4(0x35);
  FUN_0008fff4(7);
  FUN_000208e4(0,0);
  FUN_0002ff7c(DAT_00021538);
  uVar10 = 0;
  _DAT_c0000114 = _DAT_c0000114 | 0x208;
  uVar9 = local_34;
  if (*pcVar2 != '\0') {
    FUN_000904e4(200);
    do {
      FUN_00030df4(0,2);
      FUN_000284a8(0);
      FUN_00030ce8(0);
    } while( true );
  }
  do {
    if ((local_34 <= uVar10) || (iVar4 = FUN_000e321c(local_3c,local_28,0x10000), iVar4 < 1)) break;
    local_78 = (local_34 - uVar10) + 0xffff & 0xffff0000;
    if (0x10000 < local_78) {
      local_78 = 0x10000;
    }
    bVar3 = 0;
    while (local_78 != 0 && bVar3 < 0x14) {
      uVar11 = uVar10 & 0xffff0000;
      iVar4 = seed_1d20(uVar11);
      uVar10 = uVar11;
      if (iVar4 == 0) {
        unaff_r9 = 0x10000;
        do {
          iVar4 = FUN_00001aec(uVar10,local_28 + (uVar10 & 0xfffc));
          if (iVar4 != 0) {
            if (unaff_r9 != 0) goto LAB_00021544;
            break;
          }
          uVar10 = uVar10 + 0x100;
          if (local_34 <= uVar10) {
            unaff_r9 = 0;
            break;
          }
          unaff_r9 = unaff_r9 - 0x100;
        } while (unaff_r9 != 0);
        if (0 < (int)uVar9) {
          unaff_r9 = 0x10000;
          uVar10 = uVar11;
          do {
            uVar11 = 0;
            do {
              iVar4 = FUN_0000119c(uVar10,iVar5);
              if (iVar4 != 0) {
                uVar11 = uVar11 + 1;
              }
            } while (iVar4 != 0 && uVar11 < 5);
            iVar8 = local_28 + (uVar10 & 0xfffc);
            iVar4 = thunk_FUN_000db248(iVar5,iVar8,0x100);
            if (iVar4 != 0) {
              local_7c = -1;
              iVar4 = 5;
              do {
                uVar11 = 0;
                do {
                  if (*(char *)(iVar5 + uVar11) != -1) goto LAB_00021544;
                  uVar11 = uVar11 + 1;
                } while (uVar11 < 0x100);
                iVar6 = FUN_00001aec(uVar10,iVar8);
                if (iVar6 != 0) goto LAB_00021544;
                FUN_0000119c(uVar10,iVar5);
                iVar6 = FUN_000004cc(iVar5,iVar8,0x100);
                if (iVar6 == 0) {
                  local_7c = 0;
                  break;
                }
                iVar4 = iVar4 + -1;
              } while (iVar4 != 0);
              if (local_7c != 0) break;
            }
            uVar10 = uVar10 + 0x100;
            if ((local_34 <= uVar10) || (uVar9 = uVar9 - 0x100, (int)uVar9 < 1)) {
              unaff_r9 = 0;
              break;
            }
            unaff_r9 = unaff_r9 - 0x100;
          } while (unaff_r9 != 0);
        }
LAB_00021544:
        if (unaff_r9 != 0) goto LAB_0002158c;
        local_78 = local_78 - 0x10000;
        if (uVar10 < local_34) {
          unaff_r9 = FUN_000db608(local_34,uVar10 * 100);
        }
        else {
          unaff_r9 = 99;
        }
        FUN_000208e4(0,unaff_r9 & 0xff);
      }
      else {
LAB_0002158c:
        bVar3 = bVar3 + 1;
      }
    }
  } while (bVar3 != 0x14);
  seed_1d20(uVar10 + 0x10000);
  FUN_000904e4(5);
  if (bVar3 == 0x14) {
    uVar7 = 2;
  }
  else {
    uVar7 = 1;
  }
  FUN_000208e4(uVar7,unaff_r9 & 0xff);
  uVar9 = 0;
  do {
    iVar5 = FUN_00030efc(0);
    if (iVar5 == 0) {
      uVar9 = 0;
    }
    else {
      uVar9 = uVar9 + 1;
      if (0x13 < uVar9) {
        FUN_000284a8(0);
        FUN_00030ce8(0);
      }
    }
    FUN_000904e4(5);
  } while( true );
}


