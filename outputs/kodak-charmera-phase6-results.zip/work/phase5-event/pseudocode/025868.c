/* requested VA 0x00025668, containing VA 0x00025668 */

void FUN_00025668(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4)

{
  int iVar1;
  uint uVar2;
  uint local_2c;
  undefined4 local_28;
  
  local_2c = param_3;
  local_28 = param_4;
  FUN_00024d7c();
  iVar1 = DAT_00025028;
  FUN_0008f67c(*(undefined4 *)(DAT_00025028 + 0x10),0x100);
  uVar2 = 0;
switchD_000256dc_default:
  do {
    do {
      local_2c = uVar2;
      uVar2 = FUN_0008f560(*(undefined4 *)(iVar1 + 0x10),0,&local_28);
    } while (uVar2 == 0);
  } while ((char)local_28 != '\0');
  *DAT_00025824 = (short)(uVar2 & 0x1ff);
  switch(uVar2 & 0x1ff) {
  case 0x100:
    *(undefined4 *)(iVar1 + 0x14) = 0x100;
    *(undefined4 *)(iVar1 + 4) = 0;
    seed_65b0(&local_2c);
    goto switchD_000256dc_default;
  case 0x101:
    *(undefined4 *)(iVar1 + 0x14) = DAT_00025638;
    *(undefined4 *)(iVar1 + 4) = 0;
    FUN_0001c444(&local_2c);
    goto switchD_000256dc_default;
  case 0x102:
    *(undefined4 *)(iVar1 + 0x14) = DAT_00025634;
    *(undefined4 *)(iVar1 + 4) = 2;
    FUN_0001d4fc(&local_2c);
    goto switchD_000256dc_default;
  case 0x103:
    goto switchD_000256dc_default;
  case 0x104:
    *(undefined4 *)(iVar1 + 0x14) = 0x104;
    *(undefined4 *)(iVar1 + 4) = 1;
    FUN_0000ad80(&local_2c,uVar2 >> 0x10);
    uVar2 = uVar2 & 0xffff;
    goto switchD_000256dc_default;
  case 0x105:
    *(undefined4 *)(iVar1 + 0x14) = DAT_0002563c;
    (*(code *)(*(uint *)(DAT_00025828 + 4) & 0xfffffffc))(&local_2c);
    break;
  case 0x106:
    goto switchD_000256dc_default;
  case 0x107:
    goto switchD_000256dc_default;
  case 0x108:
    *(undefined4 *)(iVar1 + 4) = 3;
    *(undefined4 *)(iVar1 + 0x14) = 0x108;
    seed_21370();
    goto switchD_000256dc_default;
  case 0x109:
    *(undefined4 *)(iVar1 + 0x14) = 0x109;
    break;
  case 0x10a:
    *(undefined4 *)(iVar1 + 0x14) = 0x10a;
    break;
  case 0x10b:
    *(undefined1 *)(iVar1 + 1) = 0;
    goto switchD_000256dc_default;
  case 0x10c:
    goto switchD_000256dc_default;
  case 0x10d:
    *(undefined4 *)(iVar1 + 4) = 1;
    *(undefined4 *)(iVar1 + 0x14) = 0x10d;
    FUN_0002506c(&local_2c);
  default:
    goto switchD_000256dc_default;
  }
  *(undefined4 *)(iVar1 + 4) = 1;
  goto switchD_000256dc_default;
}


