/* requested VA 0x00025984, containing VA 0x00025984 */

undefined4 FUN_00025984(undefined4 *param_1,int param_2,int param_3,uint param_4,int param_5)

{
  int *piVar1;
  undefined4 uVar2;
  int extraout_r1;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  
  uVar5 = param_1[1];
  piVar4 = (int *)param_1[4];
  piVar6 = (int *)*param_1;
  if (param_4 <= uVar5) {
    FUN_0008d5c8();
    piVar1 = (int *)0x0;
    iVar3 = extraout_r1;
    while ((piVar1 < piVar6 && (iVar3 = 0, *piVar4 != 0))) {
      iVar3 = (int)piVar4 + uVar5;
      piVar1 = (int *)((int)piVar1 + 1);
      piVar4 = (int *)(iVar3 + 4);
    }
    if (piVar1 != piVar6) {
      if (param_4 != 0) {
        piVar1 = piVar4 + 1;
        iVar3 = param_3;
      }
      *piVar4 = param_2;
      if (param_4 != 0) {
        FUN_00000340(piVar1,iVar3);
      }
      if (param_5 == 0) {
        uVar2 = FUN_0008f67c();
      }
      else {
        uVar2 = FUN_0008f73c(param_1[2],piVar4);
      }
      FUN_0008d5f8();
      return uVar2;
    }
    FUN_0008d5f8();
  }
  return 0xffffffff;
}


