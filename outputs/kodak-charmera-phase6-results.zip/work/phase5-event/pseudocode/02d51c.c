/* requested VA 0x0002d31c, containing VA 0x0002d31c */

void FUN_0002d31c(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  
  FUN_0002d048();
  FUN_0002d00c(DAT_0002d450);
  iVar1 = FUN_0002d034(0);
  if (iVar1 == 0) {
    return;
  }
  (*(code *)(*(uint *)(iVar1 + 4) & 0xfffffffc))();
                    /* WARNING: Could not recover jumptable at 0x0002d364. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(*(uint *)(iVar1 + 0xc) & 0xfffffffc))(0,param_1,param_2);
  return;
}


