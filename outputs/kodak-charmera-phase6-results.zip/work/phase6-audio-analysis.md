# Phase 6 archived-audio review

Scope: retained Phase 5 Ghidra export only. The stock image and Ghidra project
are absent locally, so this adds no new disassembly or runtime observation.
`file offset = VA + 0x200` remains a hypothesis.

## VERIFIED from the retained pseudocode/export

| Edge or state | Evidence |
| --- | --- |
| Runtime audio task receives `0x10000100` and `0x10000101` | `work/phase5-audio/pseudocode/013310.c`: `FUN_00013110` receives a 0x1c message via `0x25a38`, then calls `FUN_00012f0c(&local_3c)` for both codes. |
| `0x12f0c` is a request consumer/state setup routine | VA `0x12f0c`, file `0x1310c`; `audio_handle_graph.json` records incoming edge `0x1322c->0x12f0c` and direct calls including `0x12f24->0x12e48`, `0x12f2c->0x33970`, `0x1305c->0x133f0`, and `0x130ac->0x25984`. |
| Request fields affect setup | `01310c.c` reads request offsets `+2`, `+8`, `+0xc`, and `+0x10`. It writes mode/state fields, sets size candidates `0x1000`, `0x800`, or `0x480`, then publishes a status message through `0x25984`. Their source-level types are not recovered. |
| Playback stop/cleanup exists in this service | `FUN_00012e48` waits on `0x33f58`, calls `0x33d60`, `0x33f70`, frees a primary pointer and an array of buffer pointers, clears a state byte, and returns to state `3`. This is lifecycle evidence, not a hardware-driver identity. |
| A 0x1000-byte circular-buffer-like worker exists | `FUN_00012bd0` uses modulo-style `0x1000` arithmetic, queue/event functions `0x8f560`, `0x8f67c`, `0x8f73c`, and posts through `0x25984`. Its exact relationship to a physical output device is not established by the export. |

## STRONGLY INFERRED

`0x12f0c` configures a playback-service state object and starts an abstracted
backend: it chooses one of two pairs of unknown callback values at object
offsets `+8` and `+0xc`, calls `0x133f0(state+4, serviceState, bufferTable)`,
and, on success, invokes the function pointer at `state+8`. This is the
lowest reachable dispatch point in the retained export. The representation is
from Ghidra pseudocode and does not establish ABI, callback target, or device.

## UNRESOLVED blocker

The focused Phase 5 archive has no pseudocode/body/xref export for VA
`0x133f0`, the values installed at the callback fields, or their indirect
targets. It also has no downstream DMA/DAC/PWM/MMIO evidence. Resolving those
targets requires an authorized local stock image plus the prior Ghidra project
or a fresh read-only import. Until then the reusable interface is only a
resource/request service, not a verified PCM or streaming driver API.
