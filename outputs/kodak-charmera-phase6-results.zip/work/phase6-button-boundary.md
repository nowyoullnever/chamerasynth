# Phase 6 Test B — button-triggered playback boundary

Scope: retained Phase 4/5 Ghidra exports only. The original firmware and full
Ghidra project are absent. No button mapping, patch, package, or hardware
operation was performed. File offsets are the `VA + 0x200` hypothesis.

## Verified static evidence

| Edge | Evidence | Confidence |
| --- | --- | --- |
| Request selector enters playback service | `VA 0x1e844`, file `0x1ea44`; complete pseudocode selects a 16-bit handle from `DAT_0001e290 + offset`, builds a 0x1c request, then `0x1e970 -> 0x25984` | VERIFIED static control flow |
| Stock startup uses selector `2` | `VA 0x6134`, file `0x6334`; `FUN_0001e844(2)` after startup checks | VERIFIED static call, not a button event |
| State machine uses selector `0` | `VA 0x1c9c4`, file `0x1cbc4`; paths handling inner values in the `0x7000` family call `FUN_0001e844(0)` at retained pseudocode locations near `0x1cb6c`, `0x1cc??`, and `0x1c??` | VERIFIED calls; physical input mapping unresolved |
| Existing audio request API rejects unsupported state | `0x1e844` first calls `0x1f560` and requires `0x130c0() == 3` before request construction | VERIFIED guard; ABI/state meaning unresolved |
| Other callers exist | audio graph records direct incoming call sites including `0x61bc`, `0x1cad4`, `0x1cb4c`, `0x1cc00`, `0x22e4c`, `0x23684`, `0x2369c`, and several UI/state regions | VERIFIED caller list; purpose not established |

The selector mapping is incomplete. `0x1e844(0)` reads the handle at table offset `+4`; `0x1e844(2)` reads offset `+6`. The retained resource initializer proves the table contains WAV handles, but it does not prove which selector is BEEP versus CLICK at every call site.

## Conclusion

No defensible physical-button-to-playback patch point is available. `0x1c9c4` is an internal state/event consumer, not a recovered GPIO/button driver. The `0x7000` event family and a call to selector `0` are insufficient to identify a physical control or modify it safely. Calling `0x1e844` from a custom payload is also unsupported: its preconditions, queue ownership, selector mapping, and callers' stack/global contract are not recovered.

## Deployment prerequisites for Test B

1. Re-import the authorized stock image and trace the physical button driver/ISR through debounce, event publication, and the specific `0x700x` consumer.
2. Recover the selector-to-resource table with each handle's resource name, lifetime, and failure behavior.
3. Prove one existing UI action invokes `0x1e844` under the required service state without changing update/event behavior.
4. Establish a safe hook and executable placement plus the required caller ABI before any patched-image experiment.
5. Define an external recovery method. A stock restore file alone does not establish recovery from a failed boot; no practical external SPI path is currently demonstrated.

Sources: `work/phase5-audio/audio_handle_graph.json`, `work/phase5-audio/pseudocode/01ea44.c`, `work/phase5-event/pseudocode/006334.c`, and `work/phase5-event/pseudocode/01cbc4.c`.
