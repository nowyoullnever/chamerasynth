# Phase 6 archive-only event investigation

Scope: Phase 4/5 compact graph and pseudocode exports restored from the result archives. The stock binary, Ghidra project, and runtime are absent. File offsets below are `VA + 0x200` hypotheses.

## Confirmed consumer/relay path

| Edge | VA / file | Evidence | Confidence |
| --- | --- | --- | --- |
| outer event `0x100` to handler | `0x2572c` / `0x2592c`, bytes `1f83ffeb` | direct call to `0x63b0` in `phase5_event_graph.json` | VERIFIED static edge |
| handler receives inner message | `0x63f8` / `0x65f8` | direct call to `0x25a38`; pseudocode passes `*DAT_00006524`, `&local_24`, `DAT_00006528`, `0x28` | VERIFIED static call; queue identity unresolved |
| queue record layout | `0x25984`, file `0x25b84`; `0x25a38`, file `0x25c38` | sender writes `param_2` as first word then copies payload; receiver returns first word to `param_2` and copies following payload | STRONGLY INFERRED from decompiler |
| `0x5025` relay | `0x6438` / `0x6638`, bytes `421fa0e3`; `0x6440` / `0x6640`, bytes `8d2402eb` | `0x63b0` compares received first word to `0x5025`, sets `r1=0x108`, calls `0x8f67c(*DAT_00006518, 0x108)` | VERIFIED static edge |
| updater dispatch | `0x257b8` / `0x259b8`, bytes `6ceeffeb` | outer loop calls `0x21170` for `0x108` | VERIFIED static edge |

`0x63b0` then calls `0x7d10` and `0x6378` before returning. `0x6378` itself calls `0x8f67c(*DAT_00006518,DAT_00006514,...)` and `0x25984(*DAT_00006520,DAT_0000651c,0,0,0)`. Neither message code nor queue ownership is resolved.

## Second consumer

`0x1c9c4` (file `0x1cbc4`) receives a 0x28-byte message through `0x25a38(*DAT_0001c988, &uStack00000010, DAT_0001c984, 0x28)`. Its `0x5025` comparison branches to `0x1cafc`, sets `uVar4=0x108`, then calls `0x8f67c(*unaff_r8,uVar4)`, stores a state byte, and calls `0x1c428` before return. This is a second consumer/relay, not a producer.

## Producer result

UNRESOLVED. The exported call graph lists many direct callers of `0x25984`, but the archive lacks the caller argument/dataflow needed to tie any sender's `param_2` to `0x5025` and its `param_1` to `DAT_00006524` or `DAT_0001c988`. The raw image and live Ghidra database needed to recover immediate construction, tables, computed/indirect dispatch, and queue creation were deleted locally. The current evidence cannot distinguish boot, SD discovery, menu, task transition, or power origin.

## Application boundary result

`0x6134` (file `0x6334`) is mixed startup code: it waits on `DAT_0000633c`, calls audio request `0x1e844(2)`, opens `POWER_ON_LOGO.JPG`, and posts an event through `0x8f67c(*DAT_000060a4, (uint)puVar10 | 0x1000000)`. It is not an isolated camera-menu callback. `0x2d31c` resolves an object then calls two unresolved function pointers at object offsets `+4` and `+0xc`; redirecting either is unsupported without target/ABI evidence. No safe Design A/B hook is established; Design C is rejected because the inner-message ownership and return/cleanup protocol are incomplete.

Sources: `work/phase5-event/phase5_event_graph.json`; `work/phase5-event/pseudocode/0065b0.c`, `01cbc4.c`, `006578.c`, `025b84.c`, `025c38.c`, `006334.c`, `02d51c.c`; `docs/phase5_event_lifecycle.md`.
