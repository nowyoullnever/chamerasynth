# Phase 6 Test A — stock WAV resource replacement boundary

Scope: retained Phase 5 Ghidra pseudocode and graph only. The proprietary
stock image, resource bytes, and Ghidra project were deleted locally. No
resource replacement, modified firmware, package, or device operation exists.
Logical VA/file offsets use the unverified `file = VA + 0x200` hypothesis.

## What the retained evidence establishes

| Item | Evidence | Confidence |
| --- | --- | --- |
| Resource names are looked up at startup | `0x1e234`/file `0x1e434` calls `0x1310` for `CLICK.WAV`, `POWERON_AUDIO.WAV`, `POWEROFF_AUDIO.WAV`, `BEEP.WAV`, `IMG.WAV` | VERIFIED static call |
| Result type is a small resource-table index/handle candidate | `0x1310` calls `0x1298`; on success it clears field `+0x18` in an entry at `*(DAT_000014a0+4) + index*0x20`; it returns the index or fallback `DAT_000014a4` | STRONGLY INFERRED from decompiler |
| Name lookup compares strings to a table | `0x1298` scans up to `*DAT_000014a0` entries at `*(DAT_000014a0+2) + index*0x20`, with a maximum comparison length `0x28` | STRONGLY INFERRED; table base/layout unresolved |
| Five results are stored as 16-bit values | `0x1e234` stores at table literal `0x1e290` -> value `0x110284`, offsets `+4,+6,+8,+0xc,+0xe`; graph records corresponding read/write xrefs | VERIFIED static stores; runtime address/mapping unproved |
| Existing playback selects a stored handle | `0x1e844` reads from the same table then builds a 0x1c request for `0x25984` | VERIFIED static path; not a container decoder proof |

## What is not recovered

The retained export does **not** include the `DAT_000014a0` table contents,
resource payload offset/length fields, RIFF/WAV bytes, container header,
allocation limit, alignment rule, checksum, resource index serializer, or a
post-replacement validator. The 0x20 entry stride and the cleared `+0x18`
field do not identify any of those fields. `BEEP.WAV` is therefore a lookup
name, not a demonstrated byte range that can be replaced safely.

## Test A deployment gate

Before producing even an offline replacement candidate, an authorized source
image must establish all of the following from actual dataflow:

1. Table `DAT_000014a0` object address, entry fields, name index, payload
   offset, stored length, and ownership.
2. Exact `BEEP.WAV` byte interval and whether it is raw RIFF/WAV or a wrapped
   resource, including alignment/padding and every pointer/length table.
3. Any hash, checksum, compressed-resource, directory, image-length, or
   signature validation that covers the changed bytes.
4. A copy-only prototype that checks the stock SHA-256, requires the original
   resource bytes, changes only the proven payload and metadata fields, emits a
   byte-level diff, and restores byte-for-byte to the source. It must remain
   non-flash-ready.
5. Independent updater image-length/erase and recovery evidence. A stock
   restore file alone does not establish recovery from an unbootable image;
   without a confirmed external recovery path, a failed boot can permanently
   prevent use of the SD updater.

Until all five gates are satisfied, Test A is not approved. It is still the
simplest *candidate* first hardware experiment because it would retain the
existing control flow and use a stock resource, but that is a design ranking,
not evidence that a replacement is safe.

Sources: `work/phase5-audio/pseudocode/01e434.c`, `001510.c`, `001498.c`,
`01ea44.c`; `work/phase5-audio/audio_handle_graph.json`.
